<?php
declare(strict_types=1);

namespace PrestaShop\Module\CargoStockManager\Controller\Admin;

require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerI18n.php';
require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerLicense.php';

use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Contracts\Translation\TranslatorInterface;
use Twig\Markup;

abstract class AbstractInventoryController extends FrameworkBundleAdminController
{
    private TranslatorInterface $translator;

    public function __construct(TranslatorInterface $translator)
    {
        $this->translator = $translator;
    }

    protected function buildHeaderTabContent(string $currentRoute): array|string
    {
        $tabsMarkup = $this->renderView('@Modules/prestashopinventory/views/templates/admin-modern/_head_tabs.html.twig', [
            'currentRoute' => $currentRoute,
            'inventoryTexts' => \CargoStockManagerI18n::all($this->translator),
            'inventoryModuleUrl' => $this->generateUrl('cargo_stock_manager_products'),
            'inventoryConfigUrl' => $this->generateUrl('cargo_stock_manager_settings'),
            'inventorySuppliersUrl' => $this->generateUrl('cargo_stock_manager_suppliers'),
            'inventoryPurchaseOrdersUrl' => $this->generateUrl('cargo_stock_manager_purchase_orders'),
        ]);

        if (version_compare(_PS_VERSION_, '9.0.0', '>=')) {
            return [new Markup($tabsMarkup, 'UTF-8')];
        }

        return $tabsMarkup;
    }

    protected function translate(string $key, array $params = []): string
    {
        return \CargoStockManagerI18n::translate($this->translator, $key, $params);
    }

    protected function inventoryTexts(): array
    {
        return \CargoStockManagerI18n::all($this->translator);
    }

    protected function assertModuleLicenseValid(): void
    {
        $module = \Module::getInstanceByName('prestashopinventory');
        $context = \Context::getContext();

        if (!$module instanceof \Module || !$context instanceof \Context) {
            throw new AccessDeniedHttpException($this->translate('license_missing_message'));
        }

        $licenseService = new \CargoStockManagerLicense($module->getLocalPath(), $context, $module);
        $status = $licenseService->getStatus();
        if (!($status['valid'] ?? false)) {
            throw new AccessDeniedHttpException((string) ($status['message'] ?? $this->translate('license_missing_message')));
        }
    }

    protected function renderInventoryPage(string $template, string $currentRoute, string $sectionLabelKey, array $extra = [])
    {
        $module = \Module::getInstanceByName('prestashopinventory');

        return $this->render($template, array_merge($extra, [
            'layoutTitle' => $this->translate('inventory_report'),
            'headerTabContent' => $this->buildHeaderTabContent($currentRoute),
            'inventoryCurrentSectionLabel' => $this->translate($sectionLabelKey),
            'inventoryReportLabel' => $this->translate('inventory_report'),
            'inventoryHomeUrl' => $this->generateUrl('cargo_stock_manager_products'),
            'moduleVersion' => $module instanceof \Module ? (string) $module->version : '0.0.0',
            'inventoryTexts' => $this->inventoryTexts(),
        ]));
    }
}
