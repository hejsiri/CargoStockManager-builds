Hotfix kompatybilności aktualizacji: paczka znów używa technicznej nazwy modułu `prestashopinventory`, aby aktualizacja z BO nie kończyła się błędem 500.
Zachowany branding `CargoStock Manager` w interfejsie oraz migracja danych do nowych tabel `cargostockmanager_*`.
Poprawione ścieżki uploadów plików zamówień, aby działały poprawnie po aktualizacji kompatybilnej.
