<?php
/**
 * CargoStock Manager module.
 *
 * @author    hejsiri
 * @copyright 2026 hejsiri
 * @license   Commercial
 */

if (!defined('_PS_VERSION_')) {
    exit;
}
