<?php
/**
 * CargoStock Manager module.
 *
 * @author    hejsiri
 * @copyright 2026 hejsiri
 * @license   Commercial
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_7_246(Module $module): bool
{
    $table = _DB_PREFIX_ . 'cargostockmanager_purchase_order';
    $columnExists = (bool) Db::getInstance()->getValue(
        'SELECT COUNT(*)
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = \'' . pSQL($table) . '\'
          AND COLUMN_NAME = \'stock_received_at\''
    );

    if (!$columnExists) {
        return (bool) Db::getInstance()->execute(
            'ALTER TABLE `' . pSQL($table) . '`
            ADD COLUMN `stock_received_at` DATETIME NULL DEFAULT NULL AFTER `carrier_name`'
        );
    }

    return true;
}
