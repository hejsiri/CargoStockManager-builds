<?php
/**
 * CargoStock Manager module.
 *
 * @author    hejsiri
 * @copyright 2026 hejsiri
 * @license   Commercial
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_5_83(Module $module): bool
{
    return true;
}
