<?php
/**
 * CargoStock Manager module.
 *
 * @author    hejsiri
 * @copyright 2026 hejsiri
 * @license   Commercial
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_7_75($module)
{
    return is_object($module);
}
