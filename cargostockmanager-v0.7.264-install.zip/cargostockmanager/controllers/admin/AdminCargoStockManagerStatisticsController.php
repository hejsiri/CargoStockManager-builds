<?php
/**
 * CargoStock Manager module.
 *
 * @author    hejsiri
 * @copyright 2026 hejsiri
 * @license   Commercial
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__DIR__, 2) . '/classes/CargoStockManagerService.php';
require_once dirname(__DIR__, 2) . '/classes/CargoStockManagerI18n.php';
require_once dirname(__DIR__, 2) . '/classes/CargoStockManagerLicense.php';

class AdminCargoStockManagerStatisticsController extends ModuleAdminController
{
    private CargoStockManagerService $inventoryService;
    private CargoStockManagerLicense $licenseService;

    public function __construct()
    {
        $this->bootstrap = true;

        parent::__construct();

        $this->inventoryService = new CargoStockManagerService($this->module->getLocalPath(), $this->context, $this->module);
        $this->licenseService = new CargoStockManagerLicense($this->module->getLocalPath(), $this->context, $this->module);
    }

    public function initContent(): void
    {
        if ($this->shouldUseModernAdminNavigation()) {
            Tools::redirectAdmin($this->getModuleRouteUrl('cargo_stock_manager_statistics'));
        }

        if ($this->module instanceof cargostockmanager) {
            $this->module->ensureTabsAvailable();
        }

        $translations = $this->inventoryService->getTranslations();
        $licenseStatus = $this->licenseService->getStatus();
        $assetsVersion = $this->module instanceof cargostockmanager
            ? $this->module->getAssetVersion('views/js/chart.umd.min.js')
            : (string) $this->module->version;

        $this->context->smarty->assign([
            'inventoryModuleUrl' => $this->context->link->getAdminLink('AdminCargoStockManagerProducts', true),
            'inventoryStatisticsUrl' => $this->context->link->getAdminLink('AdminCargoStockManagerStatistics', true),
            'inventorySuppliersUrl' => $this->context->link->getAdminLink('AdminCargoStockManagerSuppliers', true),
            'inventoryPurchaseOrdersUrl' => $this->context->link->getAdminLink('AdminCargoStockManagerPurchaseOrders', true),
            'inventoryConfigUrl' => $this->context->link->getAdminLink('AdminModules', true, [], [
                'configure' => $this->module->name,
                'module_name' => $this->module->name,
                'tab_module' => $this->module->tab,
            ]),
            'inventoryHelpUrl' => $this->context->link->getAdminLink('AdminCargoStockManagerHelp', true),
            'inventoryAjaxUrl' => $this->context->link->getAdminLink('AdminCargoStockManager', true, [], [
                'ajax' => 1,
            ]),
            'inventoryModuleBaseUrl' => $this->module->getPathUri(),
            'inventoryLanguageIso' => (string) $this->context->language->iso_code,
            'inventoryTranslations' => $translations,
            'inventoryTranslationsJson' => json_encode($translations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'inventoryModuleVersion' => (string) $this->module->version,
            'inventoryAssetsVersion' => $assetsVersion,
            'inventoryLicenseStatus' => $licenseStatus,
        ]);

        $this->content = $this->module->display(
            $this->module->getLocalPath() . $this->module->name . '.php',
            'views/templates/admin/statistics.tpl'
        );

        parent::initContent();
    }

    private function getModuleRouteUrl(string $routeName): string
    {
        $router = \PrestaShop\PrestaShop\Adapter\SymfonyContainer::getInstance()->get('router');

        return $router->generate($routeName);
    }

    private function shouldUseModernAdminNavigation(): bool
    {
        return version_compare(_PS_VERSION_, '9.0.0', '>=');
    }
}
