# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Ujednolicenie kart i motywu zakładki Ustawienia z pozostałymi zakładkami modułu.
