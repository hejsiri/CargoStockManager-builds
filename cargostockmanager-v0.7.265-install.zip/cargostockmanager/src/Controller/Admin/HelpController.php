<?php
/**
 * CargoStock Manager module.
 *
 * @author    hejsiri
 * @copyright 2026 hejsiri
 * @license   Commercial
 */
declare(strict_types=1);

namespace PrestaShop\Module\CargoStockManager\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerService.php';
require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerLicense.php';

if (!class_exists('PrestaShopBundle\\Security\\Attribute\\AdminSecurity')) {
    $legacySecurityClass = 'PrestaShopBundle\\Security\\Annotation\\Admin' . 'Security';
    if (class_exists($legacySecurityClass)) {
        class_alias($legacySecurityClass, 'PrestaShopBundle\\Security\\Attribute\\AdminSecurity');
    }
}

use PrestaShopBundle\Security\Attribute\AdminSecurity;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class HelpController extends AbstractInventoryController
{
    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function indexAction(Request $request): Response
    {
        $module = $this->getModuleInstance();
        $context = $this->getLegacyContext();

        if ($module instanceof \cargostockmanager) {
            $module->ensureTabsAvailable();
        }

        $adminEmail = '';
        if (is_object($context) && isset($context->employee) && $context->employee instanceof \Employee) {
            $adminEmail = (string) $context->employee->email;
        }

        $ajaxUrl = '';
        if (is_object($context) && isset($context->link) && $context->link instanceof \Link) {
            $ajaxUrl = $context->link->getAdminLink('AdminCargoStockManager', true, [], ['ajax' => 1]);
        }

        return $this->renderInventoryPage(
            '@Modules/cargostockmanager/views/templates/admin-modern/help.html.twig',
            'cargo_stock_manager_help',
            'help_tab',
            [
                'adminEmail' => $adminEmail,
                'ajaxUrl' => $ajaxUrl,
            ]
        );
    }
}
