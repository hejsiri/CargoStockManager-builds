<?php
/**
 * CargoStock Manager module.
 *
 * @author    hejsiri
 * @copyright 2026 hejsiri
 * @license   Commercial
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_7_168($module)
{
    if (!is_object($module)) {
        return false;
    }

    $ok = true;
    if (
        method_exists($module, 'registerHook')
        && (!method_exists($module, 'isRegisteredInHook') || !$module->isRegisteredInHook('displayBackOfficeHeader'))
    ) {
        $ok = (bool) $module->registerHook('displayBackOfficeHeader');
    }

    if (method_exists($module, 'ensureTabsAvailable')) {
        $module->ensureTabsAvailable();
    }

    if (method_exists($module, 'ensureModuleRuntimeReady')) {
        $module->ensureModuleRuntimeReady();
    }

    return $ok;
}
