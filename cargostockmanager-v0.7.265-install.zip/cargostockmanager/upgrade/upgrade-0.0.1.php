<?php
/**
 * Generic upgrade stub — PrestaShop requires at least one upgrade script
 * in the upgrade/ directory to update the module version in ps_module.
 * This file covers upgrades from any version to the current one.
 *
 * @author    hejsiri
 * @copyright 2026 hejsiri
 * @license   Commercial
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_0_1(Module $module): bool
{
    return true;
}
