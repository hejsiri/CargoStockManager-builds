{*
 * CargoStock Manager module.
 *
 * @author    Prestino
 * @copyright 2026 Prestino
 * @license   Commercial
 *}
<div class="inventory-module-content{if !empty($inventoryEmbeddedInModernLayout)} inventory-module-content--embedded{/if}">
{if empty($inventoryEmbeddedInModernLayout)}
<div id="csmgr-statistics-head-tabs-source" class="page-head-tabs inventory-panel-tabs" role="tablist" aria-label="{$inventoryTranslations.module_navigation|escape:'html':'UTF-8'}">
  <ul class="nav nav-pills">
    <li class="nav-item">
      <a href="{$inventoryModuleUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">category</span><span>{$inventoryTranslations.products_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
    <li class="nav-item">
      <a href="{$inventoryStatisticsUrl|escape:'html':'UTF-8'}" class="router-link-active router-link-exact-active nav-link active" aria-current="page" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">query_stats</span><span>{$inventoryTranslations.statistics_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
    <li class="nav-item">
      <a href="{$inventorySuppliersUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">factory</span><span>{$inventoryTranslations.suppliers_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
    <li class="nav-item">
      <a href="{$inventoryPurchaseOrdersUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">inventory_2</span><span>{$inventoryTranslations.purchase_orders_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
    <li class="nav-item">
      <a href="{$inventoryConfigUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">settings</span><span>{$inventoryTranslations.settings_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
    <li class="nav-item">
      <a href="{$inventoryHelpUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">help_outline</span><span>{$inventoryTranslations.help_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
  </ul>
</div>
{/if}

{if !$inventoryLicenseStatus.valid}
  <div class="alert alert-danger inventory-license-alert" role="alert">
    <strong>{$inventoryTranslations.license_required_title|escape:'html':'UTF-8'}:</strong>
    <span>{$inventoryLicenseStatus.message|escape:'html':'UTF-8'}</span>
  </div>
{/if}

{if $inventoryLicenseStatus.valid}
<div class="card js-grid-panel inventory-section-card cargo-stock-manager csmgr-statistics-page">
  <div class="card-header js-grid-header">
    <h3 class="d-inline-block card-header-title">{$inventoryTranslations.statistics_tab|escape:'html':'UTF-8'}</h3>
  </div>
  <div class="card-body">
    <div class="inventory-selected-report">
      <div class="inventory-selected-report-head">
        <div>
          <div class="inventory-selected-report-title">Raport sprzedaży wybranych produktów</div>
          <div id="inventorySelectedReportMeta" class="inventory-selected-report-meta"></div>
        </div>
        <div class="inventory-selected-report-actions">
          <button type="button" class="btn btn-outline-danger btn-sm inventory-selected-report-clear">Wyczyść</button>
        </div>
      </div>
      <div id="inventorySelectedReportState" class="inventory-sales-modal-state"></div>
      <div id="inventorySelectedReportContent" class="inventory-selected-report-content"></div>
    </div>
    <div id="inventoryStatisticsState" class="inventory-sales-modal-state is-visible">{$inventoryTranslations.sales_stats_loading|escape:'html':'UTF-8'}</div>
    <div id="inventoryStatisticsContent" class="inventory-sales-modal-content"></div>
  </div>
</div>
{/if}
</div>

<style>
  .csmgr-statistics-page .inventory-sales-modal-state {
    display: none;
    margin: 0 0 1.25rem;
    padding: 24px;
    border-radius: 8px;
    background: #f4f7fa;
    color: #51606d;
    text-align: center;
    font-size: 15px;
    font-weight: 600;
  }

  .csmgr-statistics-page .inventory-sales-modal-state.is-visible,
  .csmgr-statistics-page .inventory-sales-modal-content.is-visible {
    display: block;
  }

  .csmgr-statistics-page .inventory-sales-modal-content {
    display: none;
    padding: 0;
  }

  .csmgr-statistics-page .inventory-selected-report {
    margin-bottom: 1.25rem;
    padding-bottom: 1.25rem;
    border-bottom: 1px solid #dce7ef;
  }

  .csmgr-statistics-page .inventory-selected-report-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 1rem;
    margin-bottom: 0.85rem;
  }

  .csmgr-statistics-page .inventory-selected-report-title {
    color: #263238;
    font-size: 1.05rem;
    font-weight: 700;
  }

  .csmgr-statistics-page .inventory-selected-report-meta {
    margin-top: 0.18rem;
    color: #6b7d8b;
    font-size: 0.86rem;
    font-weight: 500;
  }

  .csmgr-statistics-page .inventory-selected-report-actions {
    display: flex;
    align-items: center;
    gap: 0.45rem;
    flex-wrap: wrap;
    justify-content: flex-end;
  }

  .csmgr-statistics-page .inventory-selected-report-content {
    display: none;
  }

  .csmgr-statistics-page .inventory-selected-report-content.is-visible {
    display: block;
  }

  .csmgr-statistics-page .inventory-selected-report-box {
    padding: 1.05rem 1.15rem 1rem;
    border: 1px solid #dce7ef;
    border-top: 3px solid #3eb77d;
    border-radius: 8px;
    background: #ffffff;
    box-shadow: 0 10px 24px rgba(17, 33, 45, 0.08);
  }

  .csmgr-statistics-page .inventory-selected-report-table-wrap {
    overflow: visible;
    margin-top: 0.75rem;
  }

  .csmgr-statistics-page .inventory-selected-report-table {
    width: 100%;
    min-width: 820px;
    margin: 0;
    border-collapse: collapse;
    font-size: 0.84rem;
    table-layout: fixed;
  }

  .csmgr-statistics-page .inventory-selected-report-table th,
  .csmgr-statistics-page .inventory-selected-report-table td {
    padding: 0.56rem 0.55rem;
    border-top: 1px solid #edf2f6;
    text-align: right;
    vertical-align: top;
  }

  .csmgr-statistics-page .inventory-selected-report-table th:first-child,
  .csmgr-statistics-page .inventory-selected-report-table td:first-child {
    width: 46%;
    text-align: left;
  }

  .csmgr-statistics-page .inventory-selected-report-table th:not(:first-child),
  .csmgr-statistics-page .inventory-selected-report-table td:not(:first-child) {
    width: 18%;
  }

  .csmgr-statistics-page .inventory-selected-report-table thead th {
    border-top: 0;
    color: #465968;
    font-size: 0.78rem;
    font-weight: 800;
    text-transform: uppercase;
  }

  .csmgr-statistics-page .inventory-selected-report-sort {
    display: inline-flex;
    align-items: center;
    justify-content: flex-end;
    gap: 0.25rem;
    width: 100%;
    padding: 0;
    border: 0;
    background: transparent;
    color: inherit;
    font: inherit;
    text-align: right;
    text-transform: inherit;
    cursor: pointer;
  }

  .csmgr-statistics-page .inventory-selected-report-sort:hover,
  .csmgr-statistics-page .inventory-selected-report-sort:focus {
    color: #25b9d7;
    outline: none;
  }

  .csmgr-statistics-page .inventory-selected-report-sort.is-active {
    color: #263238;
  }

  .csmgr-statistics-page .inventory-selected-report-sort-indicator {
    color: #3eb77d;
    font-size: 0.88rem;
    line-height: 1;
  }

  .csmgr-statistics-page .inventory-selected-report-product {
    display: flex;
    gap: 0.55rem;
    align-items: center;
    min-width: 0;
  }

  .csmgr-statistics-page .inventory-selected-report-preview {
    position: relative;
    display: inline-flex;
    align-items: center;
    flex: 0 0 auto;
    outline: none;
  }

  .csmgr-statistics-page .inventory-selected-report-thumb {
    display: block;
    width: 45px;
    height: 45px;
    min-width: 45px;
    min-height: 45px;
    flex: 0 0 45px;
    object-fit: cover;
    border: 1px solid #ddd;
    border-radius: 8px;
    background: #fff;
    padding: 2px;
  }

  .csmgr-statistics-page .inventory-selected-report-preview-card {
    position: absolute;
    z-index: 99999;
    left: calc(100% + 12px);
    top: 50%;
    display: none;
    min-width: 260px;
    padding: 14px 16px;
    background-color: #fff;
    color: #111;
    border-radius: 14px;
    box-shadow: 0 12px 28px rgba(0, 0, 0, 0.18), 0 4px 10px rgba(0, 0, 0, 0.12);
    white-space: normal;
    pointer-events: none;
    transform: translateY(-50%);
  }

  .csmgr-statistics-page .inventory-selected-report-preview:hover .inventory-selected-report-preview-card,
  .csmgr-statistics-page .inventory-selected-report-preview:focus .inventory-selected-report-preview-card,
  .csmgr-statistics-page .inventory-selected-report-preview:focus-within .inventory-selected-report-preview-card {
    display: block;
  }

  .csmgr-statistics-page .inventory-selected-report-preview-image {
    display: block;
    width: 240px;
    max-width: min(240px, 70vw);
    height: auto;
    border-radius: 10px;
  }

  .csmgr-statistics-page .inventory-selected-report-name {
    color: #263238;
    font-weight: 400;
    line-height: 1.25;
  }

  .csmgr-statistics-page .inventory-selected-report-variant {
    margin-top: 0.1rem;
    color: #7b8d9a;
    font-size: 0.76rem;
    line-height: 1.25;
  }

  .csmgr-statistics-page .inventory-selected-report-cell-main {
    color: #263238;
    font-weight: 800;
    line-height: 1.35;
    white-space: nowrap;
  }

  .csmgr-statistics-page .inventory-selected-report-cell-sub {
    margin-top: 0.14rem;
    color: #7b8d9a;
    font-size: 0.74rem;
    line-height: 1.35;
    white-space: nowrap;
  }

  .csmgr-statistics-page .inventory-selected-report-cell-prices {
    display: inline-flex;
    align-items: center;
    gap: 0.35rem;
  }

  .csmgr-statistics-page .inventory-selected-report-progress {
    width: min(130px, 100%);
    height: 7px;
    margin: 0.45rem 0 0 auto;
    overflow: hidden;
    border-radius: 999px;
    background: #e6edf3;
  }

  .csmgr-statistics-page .inventory-selected-report-progress-fill {
    display: block;
    height: 100%;
    min-width: 0;
    border-radius: inherit;
    background: linear-gradient(90deg, #3eb77d 0%, #42bfdc 100%);
  }

  .csmgr-statistics-page .inventory-selected-report-total td {
    background: #f5f8fb;
    color: #263238;
    font-weight: 800;
  }

  .csmgr-statistics-page .inventory-selected-report-total td:first-child {
    border-bottom-left-radius: 6px;
  }

  .csmgr-statistics-page .inventory-selected-report-total td:last-child {
    border-bottom-right-radius: 6px;
  }

  .csmgr-statistics-page .inventory-sales-month-tiles {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 1rem;
    margin-bottom: 1.25rem;
  }

  .csmgr-statistics-page .inventory-sales-month-tile {
    border-radius: 8px;
    padding: 1.05rem 1.15rem 1rem;
    background: linear-gradient(180deg, #363a41 0%, #2f3339 100%);
    border: 1px solid rgba(47, 51, 57, 0.95);
    border-top: 3px solid #23272d;
    box-shadow: 0 10px 24px rgba(17, 33, 45, 0.15);
    color: #f7fbfd;
  }

  .csmgr-statistics-page .inventory-sales-month-tile.is-previous-month {
    background: linear-gradient(180deg, #575e68 0%, #4d545e 100%);
    border-color: rgba(77, 84, 94, 0.95);
    border-top-color: #3f4650;
  }

  .csmgr-statistics-page .inventory-sales-month-tile.is-earlier-month {
    background: linear-gradient(180deg, #737b86 0%, #68717c 100%);
    border-color: rgba(104, 113, 124, 0.95);
    border-top-color: #5a6370;
  }

  .csmgr-statistics-page .inventory-sales-month-tile-label {
    font-size: 1.2rem;
    font-weight: 650;
    letter-spacing: 0;
    color: #ffffff;
    line-height: 1.2;
  }

  .csmgr-statistics-page .inventory-sales-month-tile-value {
    margin-top: 0.9rem;
    color: #f7fbfd;
    font-size: 1rem;
    line-height: 1.1;
    font-weight: 500;
  }

  .csmgr-statistics-page .inventory-sales-month-tile-row {
    display: flex;
    justify-content: space-between;
    gap: 0.75rem;
    padding: 0.62rem 0;
    border-bottom: 1px solid rgba(225, 241, 248, 0.18);
    color: rgba(247, 251, 253, 0.9);
    font-size: 0.88rem;
    font-weight: 500;
    line-height: 1.45;
  }

  .csmgr-statistics-page .inventory-sales-month-tile-row:first-of-type {
    border-top: 1px solid rgba(225, 241, 248, 0.18);
  }

  .csmgr-statistics-page .inventory-sales-month-tile-row-label {
    color: rgba(247, 251, 253, 0.72);
    font-weight: 500;
  }

  .csmgr-statistics-page .inventory-sales-month-tile-row-value {
    color: #ffffff;
    font-weight: 650;
    text-align: right;
  }

  .csmgr-statistics-page .inventory-sales-month-chart {
    position: relative;
    height: 184px;
    margin-top: 0.85rem;
    padding-top: 0.75rem;
    border-top: 1px solid rgba(225, 241, 248, 0.18);
  }

  .csmgr-statistics-page .inventory-sales-month-chart canvas {
    display: block;
    width: 100% !important;
    height: 100% !important;
  }

  .csmgr-statistics-page .inventory-sales-month-expand {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 34px;
    height: 24px;
    margin: 0.45rem auto 0;
    padding: 0;
    border: 0;
    border-radius: 999px;
    background: rgba(247, 251, 253, 0.1);
    color: rgba(247, 251, 253, 0.78);
    cursor: pointer;
    transition: background .14s ease, color .14s ease, transform .14s ease;
  }

  .csmgr-statistics-page .inventory-sales-month-expand:hover,
  .csmgr-statistics-page .inventory-sales-month-expand:focus {
    background: rgba(247, 251, 253, 0.18);
    color: #ffffff;
    outline: none;
  }

  .csmgr-statistics-page .inventory-sales-month-expand .material-icons {
    font-size: 22px;
    line-height: 1;
  }

  .csmgr-statistics-page .inventory-sales-month-tile.is-expanded .inventory-sales-month-expand .material-icons {
    transform: rotate(180deg);
  }

  .csmgr-statistics-page .inventory-sales-month-ranking {
    display: none;
    margin-top: 0.7rem;
    padding-top: 0.75rem;
    border-top: 1px solid rgba(225, 241, 248, 0.18);
  }

  .csmgr-statistics-page .inventory-sales-month-tile.is-expanded .inventory-sales-month-ranking {
    display: block;
  }

  .csmgr-statistics-page .inventory-sales-month-ranking-title {
    margin-bottom: 0.45rem;
    color: rgba(247, 251, 253, 0.92);
    font-size: 0.82rem;
    font-weight: 800;
  }

  .csmgr-statistics-page .inventory-sales-month-ranking-row {
    display: grid;
    grid-template-columns: 24px 34px minmax(0, 1fr) auto;
    align-items: center;
    gap: 0.55rem;
    min-height: 34px;
    padding: 0.32rem 0;
    border-top: 1px solid rgba(225, 241, 248, 0.1);
    color: rgba(247, 251, 253, 0.86);
    font-size: 0.78rem;
  }

  .csmgr-statistics-page .inventory-sales-month-ranking-row.is-hidden {
    display: none;
  }

  .csmgr-statistics-page .inventory-sales-month-ranking-position {
    display: flex;
    align-items: center;
    justify-content: center;
    color: rgba(247, 251, 253, 0.48);
    font-weight: 400;
    text-align: center;
  }

  .csmgr-statistics-page .inventory-sales-month-ranking-image {
    position: relative;
    width: 30px;
    height: 30px;
  }

  .csmgr-statistics-page .inventory-sales-month-ranking-thumb {
    display: block;
    width: 30px;
    height: 30px;
    border-radius: 5px;
    object-fit: cover;
    border: 1px solid rgba(247, 251, 253, 0.24);
    background: rgba(247, 251, 253, 0.1);
  }

  .csmgr-statistics-page .inventory-sales-month-ranking-preview {
    position: absolute;
    z-index: 8;
    left: 50%;
    bottom: 34px;
    width: 132px;
    height: 132px;
    border-radius: 8px;
    border: 1px solid rgba(194, 214, 229, 0.9);
    background: #ffffff;
    box-shadow: 0 14px 28px rgba(12, 32, 44, 0.28);
    object-fit: contain;
    opacity: 0;
    pointer-events: none;
    transform: translateX(-50%) translateY(6px);
    transition: opacity .12s ease, transform .12s ease;
  }

  .csmgr-statistics-page .inventory-sales-month-ranking-image:hover .inventory-sales-month-ranking-preview,
  .csmgr-statistics-page .inventory-sales-month-ranking-image:focus-within .inventory-sales-month-ranking-preview {
    opacity: 1;
    transform: translateX(-50%) translateY(0);
  }

  .csmgr-statistics-page .inventory-sales-month-ranking-name {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-weight: 400;
  }

  .csmgr-statistics-page .inventory-sales-month-ranking-qty {
    color: #ffffff;
    font-weight: 800;
    white-space: nowrap;
  }

  .csmgr-statistics-page .inventory-sales-month-ranking-empty {
    padding: 0.55rem 0;
    color: rgba(247, 251, 253, 0.58);
    font-size: 0.78rem;
    font-weight: 650;
  }

  .csmgr-statistics-page .inventory-sales-month-ranking-more {
    width: 100%;
    margin-top: 0.45rem;
    padding: 0.42rem 0.6rem;
    border: 1px solid rgba(247, 251, 253, 0.22);
    border-radius: 6px;
    background: rgba(247, 251, 253, 0.08);
    color: rgba(247, 251, 253, 0.88);
    font-size: 0.78rem;
    font-weight: 750;
    cursor: pointer;
  }

  .csmgr-statistics-page .inventory-sales-month-ranking-more:hover,
  .csmgr-statistics-page .inventory-sales-month-ranking-more:focus {
    background: rgba(247, 251, 253, 0.14);
    color: #ffffff;
    outline: none;
  }

  .csmgr-statistics-page .inventory-sales-month-tooltip {
    position: absolute;
    z-index: 5;
    left: 0;
    top: 0;
    min-width: 220px;
    padding: 0.72rem 0.9rem;
    border-radius: 8px;
    border: 1px solid rgba(194, 214, 229, 0.9);
    background: rgba(255, 255, 255, 0.98);
    box-shadow: 0 10px 20px rgba(12, 32, 44, 0.18);
    color: #35586b;
    pointer-events: none;
    transform: translate(-50%, -100%);
    opacity: 0;
    transition: opacity .12s ease;
    white-space: normal;
  }

  .csmgr-statistics-page .inventory-sales-month-tooltip.is-visible {
    opacity: 1;
  }

  .csmgr-statistics-page .inventory-sales-month-tooltip::after {
    content: '';
    position: absolute;
    left: 50%;
    bottom: -8px;
    width: 16px;
    height: 16px;
    background: rgba(255, 255, 255, 0.98);
    border-right: 1px solid rgba(194, 214, 229, 0.9);
    border-bottom: 1px solid rgba(194, 214, 229, 0.9);
    transform: translateX(-50%) rotate(45deg);
  }

  .csmgr-statistics-page .inventory-sales-month-tooltip-title {
    display: block;
    margin-bottom: 0.35rem;
    color: #1b3b4d;
    font-size: 0.92rem;
    font-weight: 800;
    line-height: 1.2;
  }

  .csmgr-statistics-page .inventory-sales-month-tooltip-body {
    display: grid;
    gap: 0.18rem;
    font-size: 0.86rem;
    font-weight: 500;
    line-height: 1.25;
  }

  .csmgr-statistics-page .inventory-sales-month-tooltip-row {
    display: flex;
    justify-content: space-between;
    gap: 1.1rem;
  }

  .csmgr-statistics-page .inventory-sales-month-tooltip-row span:first-child {
    color: #6b8190;
  }

  .csmgr-statistics-page .inventory-sales-month-tooltip-row span:last-child {
    color: #2c4f63;
    font-weight: 700;
    text-align: right;
  }

  .csmgr-statistics-page .inventory-sales-years-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 1rem;
    margin-bottom: 1.25rem;
  }

  .csmgr-statistics-page .inventory-sales-year-col {
    border-radius: 8px;
    padding: 1rem 1.1rem 0.75rem;
    border: 1px solid rgba(208, 222, 234, 0.7);
    box-shadow: 0 2px 10px rgba(17, 33, 45, 0.04);
  }

  .csmgr-statistics-page .inventory-sales-year-col.is-earliest {
    background: linear-gradient(180deg, rgba(224, 170, 40, 0.1) 0%, rgba(224, 170, 40, 0.03) 40%, #fff 100%);
    border-color: rgba(224, 170, 40, 0.22);
    border-top: 3px solid rgba(224, 170, 40, 0.96);
  }

  .csmgr-statistics-page .inventory-sales-year-col.is-previous {
    background: linear-gradient(180deg, rgba(66, 191, 220, 0.12) 0%, rgba(66, 191, 220, 0.03) 40%, #fff 100%);
    border-color: rgba(66, 191, 220, 0.25);
    border-top: 3px solid #42bfdc;
  }

  .csmgr-statistics-page .inventory-sales-year-col.is-current {
    background: linear-gradient(180deg, rgba(62, 183, 125, 0.12) 0%, rgba(62, 183, 125, 0.03) 40%, #fff 100%);
    border-color: rgba(62, 183, 125, 0.25);
    border-top: 3px solid #3eb77d;
  }

  .csmgr-statistics-page .inventory-sales-year-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0.18rem 0.7rem;
    border-radius: 999px;
    font-size: 0.78rem;
    font-weight: 800;
    letter-spacing: .06em;
    color: #fff;
    margin-bottom: 0.65rem;
  }

  .csmgr-statistics-page .inventory-sales-year-col.is-earliest .inventory-sales-year-badge,
  .csmgr-statistics-page .inventory-sales-year-badge.is-earliest {
    background: rgba(224, 170, 40, 0.96);
  }

  .csmgr-statistics-page .inventory-sales-year-col.is-previous .inventory-sales-year-badge,
  .csmgr-statistics-page .inventory-sales-year-badge.is-previous {
    background: #42bfdc;
  }

  .csmgr-statistics-page .inventory-sales-year-col.is-current .inventory-sales-year-badge,
  .csmgr-statistics-page .inventory-sales-year-badge.is-current {
    background: #3eb77d;
  }

  .csmgr-statistics-page .csmgr-cost-row {
    display: flex;
    justify-content: space-between;
    gap: 0.6rem;
    align-items: flex-start;
    flex-wrap: wrap;
    padding: 0.65rem 0;
    border-bottom: 1px solid rgba(208, 222, 234, 0.6);
  }

  .csmgr-statistics-page .csmgr-cost-row:first-of-type {
    border-top: 1px solid rgba(208, 222, 234, 0.6);
  }

  .csmgr-statistics-page .csmgr-cost-label {
    color: #6f8190;
    font-size: 0.8rem;
    font-weight: 700;
  }

  .csmgr-statistics-page .csmgr-cost-value {
    color: #19374a;
    font-size: 0.85rem;
    font-weight: 700;
    text-align: right;
  }

  .csmgr-statistics-page .inventory-sales-chart {
    border-radius: 8px;
    padding: 16px 18px 14px;
    background: #fff;
    border: 1px solid rgba(208, 222, 234, 0.7);
    box-shadow: 0 2px 10px rgba(17, 33, 45, 0.04);
    color: #19374a;
  }

  .csmgr-statistics-page .inventory-sales-chart-layout {
    display: grid;
    grid-template-columns: 36px minmax(0, 1fr) 36px;
    gap: 8px;
    align-items: center;
  }

  .csmgr-statistics-page .inventory-sales-chart-meta {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 8px;
  }

  .csmgr-statistics-page .inventory-sales-chart-range {
    font-size: 13px;
    text-transform: uppercase;
    letter-spacing: .12em;
    line-height: 1.3;
    color: rgba(56, 97, 121, 0.72);
  }

  .csmgr-statistics-page .inventory-sales-chart-year {
    display: flex;
    align-items: center;
    gap: 6px;
    line-height: 1;
  }

  .csmgr-statistics-page .inventory-sales-chart-surface {
    border-radius: 8px;
    background: linear-gradient(180deg, rgba(255, 255, 255, 0.98) 0%, rgba(244, 249, 253, 0.98) 100%);
    padding: 10px 10px 8px;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.92), 0 8px 18px rgba(27, 59, 77, 0.04);
    border: 1px solid rgba(194, 214, 229, 0.78);
  }

  .csmgr-statistics-page .inventory-sales-chart-canvas {
    width: 100%;
    height: 320px;
    position: relative;
  }

  .csmgr-statistics-page .inventory-sales-chart-canvas canvas {
    width: 100% !important;
    height: 100% !important;
    display: block;
  }

  .csmgr-statistics-page .inventory-sales-chart-footnote {
    color: rgba(56, 97, 121, 0.72);
    font-size: 12px;
    font-weight: 600;
    margin-top: 8px;
    text-align: right;
  }

  .csmgr-statistics-page .inventory-sales-nav {
    align-self: center;
    width: 48px;
    height: 48px;
    border: 0;
    border-radius: 999px;
    background: rgba(255, 255, 255, 0.94);
    color: #60798a;
    box-shadow: 0 12px 24px rgba(12, 32, 44, 0.18);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    font-weight: 600;
    line-height: 1;
    transition: transform .18s ease, box-shadow .18s ease, opacity .18s ease;
  }

  .csmgr-statistics-page .inventory-sales-nav span[aria-hidden="true"] {
    display: block;
    font-size: 36px;
    font-family: Arial, sans-serif;
    font-weight: 400;
    line-height: .7;
    transform: translateY(-1px);
    color: #60798a;
  }

  .csmgr-statistics-page .inventory-sales-nav:hover,
  .csmgr-statistics-page .inventory-sales-nav:focus {
    transform: translateY(-1px) scale(1.02);
    box-shadow: 0 16px 30px rgba(12, 32, 44, 0.22);
  }

  .csmgr-statistics-page .inventory-sales-nav.is-disabled {
    opacity: .35;
    pointer-events: none;
  }

  @media (max-width: 900px) {
    .csmgr-statistics-page .inventory-sales-month-tiles,
    .csmgr-statistics-page .inventory-sales-years-grid,
    .csmgr-statistics-page .inventory-sales-chart-layout {
      grid-template-columns: 1fr;
    }

    .csmgr-statistics-page .inventory-sales-chart-meta {
      align-items: flex-start;
      flex-direction: column;
    }

    .csmgr-statistics-page .inventory-sales-nav {
      width: 40px;
      height: 40px;
      justify-self: center;
    }
  }
</style>

<script src="{$inventoryModuleBaseUrl|escape:'html':'UTF-8'}views/js/chart.umd.min.js?v={$inventoryAssetsVersion|default:$inventoryModuleVersion|escape:'url'}"></script>
<script>
  {if empty($inventoryEmbeddedInModernLayout)}
  (function () {
    function mountBoTabs(sourceId, attempt) {
      var source = document.getElementById(sourceId);
      var pageHead = document.querySelector('.page-head');
      var pageHeadWrapper = pageHead ? pageHead.querySelector('.wrapper.clearfix') : null;
      var contentDiv = document.querySelector('#main-div > .content-div');

      if (!source || !pageHead) {
        if ((attempt || 0) < 100) {
          window.setTimeout(function () { mountBoTabs(sourceId, (attempt || 0) + 1); }, 100);
        }
        return false;
      }

      var mounted = document.getElementById('head_tabs');
      if (mounted && mounted !== source && mounted.parentNode) {
        mounted.parentNode.removeChild(mounted);
      }

      if (pageHeadWrapper) {
        pageHeadWrapper.insertAdjacentElement('afterend', source);
      } else {
        pageHead.appendChild(source);
      }

      if (contentDiv) {
        contentDiv.classList.add('with-tabs');
      }
      source.hidden = false;
      return false;
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function () { mountBoTabs('csmgr-statistics-head-tabs-source', 0); });
    } else {
      mountBoTabs('csmgr-statistics-head-tabs-source', 0);
    }
    window.addEventListener('load', function () { mountBoTabs('csmgr-statistics-head-tabs-source', 0); });
  })();
  {/if}

  window.cargoStockManagerStatisticsConfig = {
    ajaxUrl: '{$inventoryAjaxUrl|escape:'javascript':'UTF-8'}',
    languageIso: '{$inventoryLanguageIso|escape:'javascript':'UTF-8'}'
  };

  (function () {
    var sourceTranslations = JSON.parse('{$inventoryTranslationsJson|escape:'javascript':'UTF-8'}');
    var chartInstance = null;
    var monthChartInstances = [];
    var LS_SELECTED_SALES_REPORT_PRODUCTS = 'csmgr_selected_sales_report_products';
    var selectedReportSortField = 'current';
    var selectedReportSortDir = 'desc';
    var selectedReportLastReport = null;
    var state = {
      months: 12,
      offsetMonths: 0,
      selectedYear: 0,
      previousYear: 0,
      earliestYear: 0
    };

    function t(key) {
      return sourceTranslations[key] || key;
    }

    function escapeHtml(value) {
      return String(value == null ? '' : value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
    }

    function formatCurrencyAmount(value) {
      try {
        return new Intl.NumberFormat(window.cargoStockManagerStatisticsConfig.languageIso || 'pl-PL', {
          style: 'currency',
          currency: 'PLN',
          minimumFractionDigits: 0,
          maximumFractionDigits: 0
        }).format(Number(value || 0));
      } catch (error) {
        return Number(value || 0).toFixed(0) + ' PLN';
      }
    }

    function formatOrdersLabel(value) {
      var orderCount = Number(value || 0);
      var absCount = Math.abs(orderCount);
      var lastDigit = absCount % 10;
      var lastTwoDigits = absCount % 100;
      var label = absCount === 1
        ? 'zamówienie'
        : (lastDigit >= 2 && lastDigit <= 4 && (lastTwoDigits < 12 || lastTwoDigits > 14) ? 'zamówienia' : 'zamówień');

      return String(orderCount) + ' ' + label;
    }

    function formatSalesMonth(monthDate) {
      var date = new Date(monthDate + 'T00:00:00');
      try {
        return new Intl.DateTimeFormat(window.cargoStockManagerStatisticsConfig.languageIso || 'pl-PL', {
          month: 'short',
          year: 'numeric'
        }).format(date);
      } catch (error) {
        return monthDate;
      }
    }

    function formatSalesMonthLong(monthDate) {
      var date = new Date(monthDate + 'T00:00:00');
      try {
        var label = new Intl.DateTimeFormat(window.cargoStockManagerStatisticsConfig.languageIso || 'pl-PL', {
          month: 'long',
          year: 'numeric'
        }).format(date);

        return label.charAt(0).toUpperCase() + label.slice(1);
      } catch (error) {
        return monthDate;
      }
    }

    function formatSalesMonthShort(monthDate) {
      var date = new Date(monthDate + 'T00:00:00');
      try {
        return new Intl.DateTimeFormat(window.cargoStockManagerStatisticsConfig.languageIso || 'pl-PL', {
          month: 'short'
        }).format(date);
      } catch (error) {
        return monthDate;
      }
    }

    function setPageState(message, visible) {
      var stateEl = document.getElementById('inventoryStatisticsState');
      if (!stateEl) {
        return;
      }
      stateEl.textContent = message || '';
      stateEl.classList.toggle('is-visible', !!visible);
    }

    function setPageContent(html, visible) {
      var content = document.getElementById('inventoryStatisticsContent');
      if (!content) {
        return;
      }
      content.innerHTML = html || '';
      content.classList.toggle('is-visible', !!visible);
    }

    function getSelectedSalesReportProducts() {
      try {
        var parsed = JSON.parse(localStorage.getItem(LS_SELECTED_SALES_REPORT_PRODUCTS) || '[]');
        return Array.isArray(parsed) ? parsed.filter(function (item) {
          return item && Number(item.id_product || 0) > 0;
        }) : [];
      } catch (error) {
        return [];
      }
    }

    function saveSelectedSalesReportProducts(products) {
      localStorage.setItem(LS_SELECTED_SALES_REPORT_PRODUCTS, JSON.stringify(products.slice(0, 100)));
    }

    function setSelectedReportState(message, visible) {
      var stateEl = document.getElementById('inventorySelectedReportState');
      if (!stateEl) {
        return;
      }
      stateEl.textContent = message || '';
      stateEl.classList.toggle('is-visible', !!visible);
    }

    function setSelectedReportContent(html, visible) {
      var content = document.getElementById('inventorySelectedReportContent');
      if (!content) {
        return;
      }
      content.innerHTML = html || '';
      content.classList.toggle('is-visible', !!visible);
    }

    function updateSelectedReportMeta(report) {
      var meta = document.getElementById('inventorySelectedReportMeta');
      var summary = report && report.summary ? report.summary : {};
      var year = report && report.comparison ? Number(report.comparison.current_year || 0) : 0;
      if (meta) {
        meta.textContent = year
          ? String(summary.selected_count || 0) + ' produktów / ' + year + ' / ' + String(summary.total_quantity || 0) + ' ' + t('sales_units') + ' / ' + formatCurrencyAmount(summary.total_value_net || 0) + ' netto'
          : '';
      }
    }

    function getEmptySelectedReportStats() {
      return {
        quantity: 0,
        value: 0,
        valueNet: 0,
        orderCount: 0
      };
    }

    function addSelectedReportStats(target, source) {
      target.quantity += Number(source && source.quantity || 0);
      target.value += Number(source && source.value || 0);
      target.valueNet += Number(source && source.value_net != null ? source.value_net : (source && source.valueNet || 0));
      target.orderCount += Number(source && source.order_count != null ? source.order_count : (source && source.orderCount || 0));

      return target;
    }

    function getSelectedReportMonthStats(product, monthIndex) {
      var months = Array.isArray(product.months) ? product.months : [];

      return months[monthIndex] || {};
    }

    function getSelectedReportRangeStats(product, startIndex, endIndex) {
      var stats = getEmptySelectedReportStats();

      for (var index = startIndex; index <= endIndex; index += 1) {
        addSelectedReportStats(stats, getSelectedReportMonthStats(product, index));
      }

      return stats;
    }

    function renderSelectedReportValueCell(stats, maxQuantity) {
      var quantity = Number(stats && stats.quantity || 0);
      var percent = Number(maxQuantity || 0) > 0 ? Math.max(0, Math.min(100, (quantity / Number(maxQuantity || 0)) * 100)) : 0;

      return '<div class="inventory-selected-report-cell-main">' + escapeHtml(String(Math.round(quantity))) + ' ' + escapeHtml(t('sales_units')) + '</div>' +
        '<div class="inventory-selected-report-cell-sub inventory-selected-report-cell-prices">' +
          '<span>' + escapeHtml(formatCurrencyAmount(stats && stats.valueNet || 0)) + ' netto</span>' +
          '<span>/</span>' +
          '<span>' + escapeHtml(formatCurrencyAmount(stats && stats.value || 0)) + ' brutto</span>' +
        '</div>' +
        '<div class="inventory-selected-report-progress" aria-hidden="true"><span class="inventory-selected-report-progress-fill" style="width:' + escapeHtml(percent.toFixed(2)) + '%"></span></div>';
    }

    function renderSelectedReportTotalCell(stats) {
      var quantity = Number(stats && stats.quantity || 0);

      return '<div class="inventory-selected-report-cell-main">' + escapeHtml(String(Math.round(quantity))) + ' ' + escapeHtml(t('sales_units')) + '</div>' +
        '<div class="inventory-selected-report-cell-sub inventory-selected-report-cell-prices">' +
          '<span>' + escapeHtml(formatCurrencyAmount(stats && stats.valueNet || 0)) + ' netto</span>' +
          '<span>/</span>' +
          '<span>' + escapeHtml(formatCurrencyAmount(stats && stats.value || 0)) + ' brutto</span>' +
        '</div>';
    }

    function renderSelectedReportSortButton(field, label, subtitle) {
      var isActive = selectedReportSortField === field;
      var indicator = selectedReportSortDir === 'asc' ? '↑' : '↓';

      return '<button type="button" class="inventory-selected-report-sort' + (isActive ? ' is-active' : '') + '" data-sort-field="' + escapeHtml(field) + '">' +
        '<span>' + label + (subtitle ? '<div class="inventory-selected-report-cell-sub">' + subtitle + '</div>' : '') + '</span>' +
        (isActive ? '<span class="inventory-selected-report-sort-indicator" aria-hidden="true">' + indicator + '</span>' : '') +
      '</button>';
    }

    function getSelectedReportSortStats(row) {
      if (selectedReportSortField === 'range') {
        return row.rangeStats;
      }

      if (selectedReportSortField === 'year') {
        return row.yearStats;
      }

      return row.currentStats;
    }

    function renderSelectedReport(report) {
      var products = report && Array.isArray(report.products) ? report.products : [];
      var months = report && Array.isArray(report.months) ? report.months : [];
      var comparison = report && report.comparison ? report.comparison : {};
      var reportYear = Number(comparison.current_year || new Date().getFullYear());
      var today = new Date();
      var currentMonthIndex = today.getFullYear() === reportYear ? today.getMonth() : 11;
      var rangeStartIndex = Math.max(0, currentMonthIndex - 2);
      var rangeEndIndex = currentMonthIndex;
      var currentMonthDate = months[currentMonthIndex] || String(reportYear) + '-' + String(currentMonthIndex + 1).padStart(2, '0') + '-01';
      var rangeStartDate = months[rangeStartIndex] || String(reportYear) + '-' + String(rangeStartIndex + 1).padStart(2, '0') + '-01';
      var rangeEndDate = months[rangeEndIndex] || String(reportYear) + '-' + String(rangeEndIndex + 1).padStart(2, '0') + '-01';
      var currentMonthTotal = getEmptySelectedReportStats();
      var rangeTotal = getEmptySelectedReportStats();
      var yearTotal = getEmptySelectedReportStats();
      var maxCurrentQuantity = 0;
      var maxRangeQuantity = 0;
      var maxYearQuantity = 0;

      selectedReportLastReport = report;
      updateSelectedReportMeta(report);

      if (!products.length) {
        setSelectedReportState('Dodaj produkty do raportu na liście produktów przyciskiem playlist_add.', true);
        setSelectedReportContent('', false);
        return;
      }

      var header = '<tr>' +
        '<th>Produkt</th>' +
        '<th>' + renderSelectedReportSortButton('current', escapeHtml(formatSalesMonthLong(currentMonthDate)), '') + '</th>' +
        '<th>' + renderSelectedReportSortButton('range', 'Ostatnie 3 miesiące', escapeHtml(formatSalesMonthShort(rangeStartDate)) + ' - ' + escapeHtml(formatSalesMonthShort(rangeEndDate))) + '</th>' +
        '<th>' + renderSelectedReportSortButton('year', 'Bieżący rok', escapeHtml(String(reportYear))) + '</th>' +
      '</tr>';

      var reportRows = products.map(function (product) {
        var currentStats = getSelectedReportRangeStats(product, currentMonthIndex, currentMonthIndex);
        var rangeStats = getSelectedReportRangeStats(product, rangeStartIndex, rangeEndIndex);
        var productYearStats = {
          quantity: Number(product.total_quantity || 0),
          value: Number(product.total_value || 0),
          valueNet: Number(product.total_value_net || 0),
          orderCount: Number(product.order_count || 0)
        };
        var image = String(product.image_thumb_url || product.image_preview_url || '');
        var previewImage = String(product.image_preview_url || product.image_thumb_url || '');
        var imageHtml = image
          ? '<span class="inventory-selected-report-preview" tabindex="0">' +
              '<img class="inventory-selected-report-thumb" src="' + escapeHtml(image) + '" alt="">' +
              '<span class="inventory-selected-report-preview-card">' +
                '<img class="inventory-selected-report-preview-image" src="' + escapeHtml(previewImage) + '" alt="">' +
              '</span>' +
            '</span>'
          : '<span class="inventory-selected-report-preview"><span class="inventory-selected-report-thumb"></span></span>';

        addSelectedReportStats(currentMonthTotal, currentStats);
        addSelectedReportStats(rangeTotal, rangeStats);
        addSelectedReportStats(yearTotal, productYearStats);
        maxCurrentQuantity = Math.max(maxCurrentQuantity, Number(currentStats.quantity || 0));
        maxRangeQuantity = Math.max(maxRangeQuantity, Number(rangeStats.quantity || 0));
        maxYearQuantity = Math.max(maxYearQuantity, Number(productYearStats.quantity || 0));

        return {
          productName: String(product.product_name || ('Produkt #' + product.id_product)),
          currentStats: currentStats,
          rangeStats: rangeStats,
          yearStats: productYearStats,
          imageHtml: imageHtml,
          product: product
        };
      }).sort(function (a, b) {
        var statsA = getSelectedReportSortStats(a);
        var statsB = getSelectedReportSortStats(b);
        var direction = selectedReportSortDir === 'asc' ? 1 : -1;
        var quantityDiff = (Number(statsA.quantity || 0) - Number(statsB.quantity || 0)) * direction;
        if (quantityDiff !== 0) {
          return quantityDiff;
        }

        var valueDiff = (Number(statsA.valueNet || 0) - Number(statsB.valueNet || 0)) * direction;
        if (valueDiff !== 0) {
          return valueDiff;
        }

        return a.productName.localeCompare(b.productName, window.cargoStockManagerStatisticsConfig.languageIso || 'pl-PL');
      }).map(function (row) {
        var product = row.product || {};

        return {
          html: '<tr>' +
            '<td><div class="inventory-selected-report-product">' + row.imageHtml + '<div>' +
              '<div class="inventory-selected-report-name">' + escapeHtml(product.product_name || ('Produkt #' + product.id_product)) + '</div>' +
              (product.combination_name ? '<div class="inventory-selected-report-variant">' + escapeHtml(product.combination_name) + '</div>' : '') +
            '</div></div></td>' +
            '<td>' + renderSelectedReportValueCell(row.currentStats, maxCurrentQuantity) + '</td>' +
            '<td>' + renderSelectedReportValueCell(row.rangeStats, maxRangeQuantity) + '</td>' +
            '<td>' + renderSelectedReportValueCell(row.yearStats, maxYearQuantity) + '</td>' +
          '</tr>'
        };
      });

      var rows = reportRows.map(function (row) {
        return row.html;
      }).join('');

      var footer = '<tr class="inventory-selected-report-total">' +
        '<td>Razem</td>' +
        '<td>' + renderSelectedReportTotalCell(currentMonthTotal) + '</td>' +
        '<td>' + renderSelectedReportTotalCell(rangeTotal) + '</td>' +
        '<td>' + renderSelectedReportTotalCell(yearTotal) + '</td>' +
      '</tr>';

      setSelectedReportState('', false);
      setSelectedReportContent(
        '<div class="inventory-selected-report-box"><div class="inventory-selected-report-table-wrap"><table class="inventory-selected-report-table"><thead>' + header + '</thead><tbody>' + rows + footer + '</tbody></table></div></div>',
        true
      );
    }

    function fetchSelectedReport() {
      var products = getSelectedSalesReportProducts();
      if (!products.length) {
        updateSelectedReportMeta({ summary: { selected_count: 0 } });
        setSelectedReportState('Dodaj produkty do raportu na liście produktów przyciskiem playlist_add.', true);
        setSelectedReportContent('', false);
        return;
      }

      setSelectedReportState(t('sales_stats_loading'), true);
      setSelectedReportContent('', false);

      $.post(window.cargoStockManagerStatisticsConfig.ajaxUrl + '&action=GetSelectedProductsSalesReport', {
        products: JSON.stringify(products),
        offset_months: 0
      }, null, 'json').done(function (resp) {
        if (!resp || !resp.ok || !resp.report) {
          setSelectedReportState(resp && resp.error ? resp.error : t('error_sales_stats'), true);
          return;
        }
        renderSelectedReport(resp.report);
      }).fail(function (xhr) {
        var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('error_sales_stats');
        setSelectedReportState(error, true);
      });
    }

    function buildYearSummary(year, quantities, values, valuesNet) {
      var today = new Date();
      var currentYear = today.getFullYear();
      var currentMonthIndex = today.getMonth();
      var currentDay = today.getDate();
      var daysInCurrentMonth = new Date(currentYear, currentMonthIndex + 1, 0).getDate();
      var lastIncludedMonthIndex = year === currentYear ? Math.min(currentMonthIndex, quantities.length - 1) : (quantities.length - 1);
      var elapsedMonthUnits = quantities.length;
      var total = 0;
      var totalValue = 0;
      var totalValueNet = 0;
      var minValue = null;
      var maxValue = null;

      quantities.forEach(function (qty, index) {
        if (index > lastIncludedMonthIndex) {
          return;
        }
        var value = Number(qty || 0);
        total += value;
        totalValue += Number((values || [])[index] || 0);
        totalValueNet += Number((valuesNet || [])[index] || 0);
        minValue = minValue === null ? value : Math.min(minValue, value);
        maxValue = maxValue === null ? value : Math.max(maxValue, value);
      });

      if (year === currentYear) {
        elapsedMonthUnits = currentMonthIndex + (daysInCurrentMonth > 0 ? (currentDay / daysInCurrentMonth) : 0);
      }

      if (!isFinite(elapsedMonthUnits) || elapsedMonthUnits <= 0) {
        elapsedMonthUnits = Math.max(lastIncludedMonthIndex + 1, 1);
      }

      return {
        year: year,
        total: total,
        totalValue: totalValue,
        totalValueNet: totalValueNet,
        average: total / elapsedMonthUnits,
        averageValue: totalValue / elapsedMonthUnits,
        averageValueNet: totalValueNet / elapsedMonthUnits,
        minValue: minValue === null ? 0 : minValue,
        maxValue: maxValue === null ? 0 : maxValue
      };
    }

    function renderYearSummaryCard(summary, toneClass) {
      function row(label, value) {
        return '<div class="csmgr-cost-row">' +
          '<span class="csmgr-cost-label">' + escapeHtml(label) + '</span>' +
          '<span class="csmgr-cost-value">' + value + '</span>' +
          '</div>';
      }

      return '' +
        '<div class="inventory-sales-year-col ' + escapeHtml(toneClass || '') + '">' +
          '<div class="inventory-sales-year-badge">' + escapeHtml(String(summary.year)) + '</div>' +
          row('Łącznie', escapeHtml(String(summary.total)) + ' ' + escapeHtml(t('sales_units'))) +
          row('Wartość sprzedaży', escapeHtml(formatCurrencyAmount(summary.totalValueNet)) + ' <span style="color:#aab4bc">netto</span> &nbsp;/&nbsp; ' + escapeHtml(formatCurrencyAmount(summary.totalValue)) + ' <span style="color:#aab4bc">brutto</span>') +
          row('Miesięcznie', '<span style="white-space:nowrap"><span style="color:#aab4bc;font-size:.72rem;font-weight:700">MIN</span> <strong>' + escapeHtml(String(summary.minValue)) + ' ' + escapeHtml(t('sales_units')) + '</strong></span> &nbsp; <span style="white-space:nowrap"><span style="color:#aab4bc;font-size:.72rem;font-weight:700">MAX</span> <strong>' + escapeHtml(String(summary.maxValue)) + ' ' + escapeHtml(t('sales_units')) + '</strong></span> &nbsp; <span style="white-space:nowrap"><span style="color:#aab4bc;font-size:.72rem;font-weight:700">ŚR.</span> <strong>' + escapeHtml(Number(summary.average || 0).toFixed(1).replace(/\\.0$/, '')) + ' ' + escapeHtml(t('sales_units')) + '</strong></span>') +
          row('Wartość / mies.', escapeHtml(formatCurrencyAmount(summary.averageValueNet)) + ' <span style="color:#aab4bc">netto</span> &nbsp;/&nbsp; ' + escapeHtml(formatCurrencyAmount(summary.averageValue)) + ' <span style="color:#aab4bc">brutto</span>') +
        '</div>';
    }

    function getMonthStats(months, year, monthIndex) {
      var normalizedMonthIndex = monthIndex;
      var normalizedYear = year;

      while (normalizedMonthIndex < 0) {
        normalizedMonthIndex += 12;
        normalizedYear -= 1;
      }

      while (normalizedMonthIndex > 11) {
        normalizedMonthIndex -= 12;
        normalizedYear += 1;
      }

      var item = months[normalizedMonthIndex] || {};
      var isSelectedYear = normalizedYear === state.selectedYear;
      var isPreviousYear = normalizedYear === state.previousYear;
      var isEarliestYear = normalizedYear === state.earliestYear;

      return {
        year: normalizedYear,
        monthIndex: normalizedMonthIndex,
        quantity: isSelectedYear
          ? Number(item.quantity || 0)
          : (isPreviousYear ? Number(item.previous_quantity || 0) : (isEarliestYear ? Number(item.earliest_quantity || 0) : 0)),
        orderCount: isSelectedYear
          ? Number(item.order_count || 0)
          : (isPreviousYear ? Number(item.previous_order_count || 0) : (isEarliestYear ? Number(item.earliest_order_count || 0) : 0)),
        value: isSelectedYear
          ? Number(item.value || 0)
          : (isPreviousYear ? Number(item.previous_value || 0) : (isEarliestYear ? Number(item.earliest_value || 0) : 0)),
        valueNet: isSelectedYear
          ? Number(item.value_net || 0)
          : (isPreviousYear ? Number(item.previous_value_net || 0) : (isEarliestYear ? Number(item.earliest_value_net || 0) : 0)),
        dailySales: isSelectedYear
          ? (item.daily_sales || [])
          : (isPreviousYear ? (item.previous_daily_sales || []) : (isEarliestYear ? (item.earliest_daily_sales || []) : [])),
        productRanking: isSelectedYear
          ? (item.product_ranking || [])
          : (isPreviousYear ? (item.previous_product_ranking || []) : (isEarliestYear ? (item.earliest_product_ranking || []) : []))
      };
    }

    function getMonthChartId(stats) {
      return 'inventoryStatisticsMonthChart' + String(stats.year || 0) + String(Number(stats.monthIndex || 0) + 1).padStart(2, '0');
    }

    function formatWeekdayName(year, monthIndex, day) {
      var date = new Date(Number(year || 0), Number(monthIndex || 0), Number(day || 0));

      if (isNaN(date.getTime())) {
        return '';
      }

      try {
        return new Intl.DateTimeFormat('pl-PL', { weekday: 'long' }).format(date);
      } catch (error) {
        return ['niedziela', 'poniedziałek', 'wtorek', 'środa', 'czwartek', 'piątek', 'sobota'][date.getDay()] || '';
      }
    }

    function renderMonthRanking(stats) {
      var ranking = Array.isArray(stats.productRanking) ? stats.productRanking : [];

      if (!ranking.length) {
        return '' +
          '<div class="inventory-sales-month-ranking">' +
            '<div class="inventory-sales-month-ranking-title">Ranking produktów</div>' +
            '<div class="inventory-sales-month-ranking-empty">Brak sprzedaży produktów w tym miesiącu</div>' +
          '</div>';
      }

      return '' +
        '<div class="inventory-sales-month-ranking">' +
          '<div class="inventory-sales-month-ranking-title">Ranking produktów</div>' +
          ranking.map(function (item, index) {
            var thumbUrl = String(item.image_thumb_url || item.image_preview_url || '');
            var previewUrl = String(item.image_preview_url || item.image_thumb_url || '');
            var imageHtml = thumbUrl
              ? '<span class="inventory-sales-month-ranking-image" tabindex="0">' +
                  '<img class="inventory-sales-month-ranking-thumb" src="' + escapeHtml(thumbUrl) + '" alt="">' +
                  '<img class="inventory-sales-month-ranking-preview" src="' + escapeHtml(previewUrl) + '" alt="">' +
                '</span>'
              : '<span class="inventory-sales-month-ranking-image"><span class="inventory-sales-month-ranking-thumb"></span></span>';

            return '<div class="inventory-sales-month-ranking-row' + (index >= 10 ? ' is-hidden' : '') + '" data-rank-index="' + String(index) + '">' +
              '<span class="inventory-sales-month-ranking-position">' + escapeHtml(String(index + 1)) + '</span>' +
              imageHtml +
              '<span class="inventory-sales-month-ranking-name" title="' + escapeHtml(item.product_name || '') + '">' + escapeHtml(item.product_name || '') + '</span>' +
              '<span class="inventory-sales-month-ranking-qty">' + escapeHtml(String(item.quantity || 0)) + ' ' + escapeHtml(t('sales_units')) + '</span>' +
            '</div>';
          }).join('') +
          (ranking.length > 10
            ? '<button type="button" class="inventory-sales-month-ranking-more" data-visible-count="10">Pokaż kolejne 10</button>'
            : '') +
        '</div>';
    }

    function renderMonthStatTile(label, stats, extraClass) {
      function row(rowLabel, rowValue) {
        return '<div class="inventory-sales-month-tile-row">' +
          '<span class="inventory-sales-month-tile-row-label">' + escapeHtml(rowLabel) + '</span>' +
          '<span class="inventory-sales-month-tile-row-value">' + rowValue + '</span>' +
        '</div>';
      }

      return '' +
        '<div class="inventory-sales-month-tile ' + escapeHtml(extraClass || '') + '">' +
          '<div class="inventory-sales-month-tile-label">' + escapeHtml(label) + '</div>' +
          '<div class="inventory-sales-month-tile-value">' +
            row('Ilość zamówień', escapeHtml(String(stats.orderCount || 0))) +
            row('Sprzedane sztuki', escapeHtml(String(stats.quantity || 0)) + ' ' + escapeHtml(t('sales_units'))) +
            row('Wartość sprzedaży', escapeHtml(formatCurrencyAmount(stats.valueNet || 0)) + ' <span style="color:#aab4bc">netto</span> &nbsp;/&nbsp; ' + escapeHtml(formatCurrencyAmount(stats.value || 0)) + ' <span style="color:#aab4bc">brutto</span>') +
            '<div class="inventory-sales-month-chart"><canvas id="' + escapeHtml(getMonthChartId(stats)) + '"></canvas></div>' +
            '<button type="button" class="inventory-sales-month-expand" aria-expanded="false" aria-label="Rozwiń ranking produktów" title="Rozwiń ranking produktów"><span class="material-icons" aria-hidden="true">keyboard_arrow_down</span></button>' +
            renderMonthRanking(stats) +
          '</div>' +
        '</div>';
    }

    function destroyChart() {
      if (chartInstance && typeof chartInstance.destroy === 'function') {
        chartInstance.destroy();
      }
      chartInstance = null;
    }

    function destroyMonthCharts() {
      monthChartInstances.forEach(function (instance) {
        if (instance && typeof instance.destroy === 'function') {
          instance.destroy();
        }
      });
      monthChartInstances = [];
    }

    function buildMonthDailySeries(year, monthIndex, dailySales) {
      var daysInMonth = new Date(Number(year || 0), Number(monthIndex || 0) + 1, 0).getDate();
      var byDay = {};

      (dailySales || []).forEach(function (item) {
        byDay[Number(item.day || 0)] = item;
      });

      return Array.from({ length: daysInMonth }, function (_, index) {
        var day = index + 1;
        var item = byDay[day] || {};

        return {
          day: day,
          orderCount: Number(item.order_count || 0),
          quantity: Number(item.quantity || 0),
          value: Number(item.value || 0),
          valueNet: Number(item.value_net || 0)
        };
      });
    }

    function getMonthChartVisualValue(item) {
      var value = Number(item && item.value ? item.value : 0);

      return value > 0 ? Math.sqrt(value) : 0;
    }

    function renderMonthCharts(tiles) {
      if (typeof Chart === 'undefined') {
        return;
      }

      destroyMonthCharts();

      tiles.forEach(function (tile) {
        var canvas = document.getElementById(getMonthChartId(tile.stats));
        if (!canvas) {
          return;
        }

        var ctx = canvas.getContext('2d');
        var series = buildMonthDailySeries(tile.stats.year, tile.stats.monthIndex, tile.stats.dailySales);
        var gradient = ctx.createLinearGradient(0, 0, 0, canvas.height || 184);
        gradient.addColorStop(0, tile.colorTop);
        gradient.addColorStop(1, tile.colorBottom);

        monthChartInstances.push(new Chart(ctx, {
          type: 'bar',
          data: {
            labels: series.map(function (item) { return String(item.day); }),
            datasets: [{
              data: series.map(getMonthChartVisualValue),
              backgroundColor: gradient,
              borderColor: tile.borderColor,
              borderWidth: 1,
              borderRadius: 3,
              minBarLength: 4,
              maxBarThickness: 12
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            animation: { duration: 320, easing: 'easeOutCubic' },
            interaction: { mode: 'index', intersect: false, axis: 'x' },
            plugins: {
              legend: { display: false },
              tooltip: {
                enabled: false,
                external: function (context) {
                  var chart = context.chart;
                  var tooltip = context.tooltip;
                  var wrapper = chart.canvas.parentNode;
                  var tooltipEl = wrapper.querySelector('.inventory-sales-month-tooltip');

                  if (!tooltipEl) {
                    tooltipEl = document.createElement('div');
                    tooltipEl.className = 'inventory-sales-month-tooltip';
                    tooltipEl.innerHTML = '<span class="inventory-sales-month-tooltip-title"></span><span class="inventory-sales-month-tooltip-body"></span>';
                    wrapper.appendChild(tooltipEl);
                  }

                  if (!tooltip || tooltip.opacity === 0 || !tooltip.dataPoints || !tooltip.dataPoints.length) {
                    tooltipEl.classList.remove('is-visible');
                    return;
                  }

                  var dataIndex = tooltip.dataPoints[0].dataIndex;
                  var element = chart.getDatasetMeta(0).data[dataIndex];
                  var position = element && typeof element.getProps === 'function'
                    ? element.getProps(['x', 'y', 'base'], true)
                    : (element || { x: tooltip.caretX, y: tooltip.caretY, base: tooltip.caretY });
                  var barTop = Math.min(Number(position.y || 0), Number(position.base || position.y || 0));
                  var item = series[dataIndex] || {};
                  var dateLabel = String(item.day || '').padStart(2, '0') + '.' +
                    String(Number(tile.stats.monthIndex || 0) + 1).padStart(2, '0') + '.' +
                    String(tile.stats.year || '');
                  var weekdayLabel = formatWeekdayName(tile.stats.year, tile.stats.monthIndex, item.day);

                  tooltipEl.querySelector('.inventory-sales-month-tooltip-title').textContent =
                    dateLabel + (weekdayLabel ? ' ' + weekdayLabel : '');
                  tooltipEl.querySelector('.inventory-sales-month-tooltip-body').innerHTML =
                    '<span class="inventory-sales-month-tooltip-row"><span>Netto</span><span>' + escapeHtml(formatCurrencyAmount(item.valueNet)) + '</span></span>' +
                    '<span class="inventory-sales-month-tooltip-row"><span>Brutto</span><span>' + escapeHtml(formatCurrencyAmount(item.value)) + '</span></span>' +
                    '<span class="inventory-sales-month-tooltip-row"><span>Ilość</span><span>' + escapeHtml(String(item.quantity || 0) + ' ' + t('sales_units')) + '</span></span>' +
                    '<span class="inventory-sales-month-tooltip-row"><span>Zamówienia</span><span>' + escapeHtml(String(item.orderCount || 0)) + '</span></span>';
                  tooltipEl.style.left = String(Number(position.x || tooltip.caretX || 0)) + 'px';
                  tooltipEl.style.top = String(barTop - 8) + 'px';
                  tooltipEl.classList.add('is-visible');
                  }
              }
            },
            scales: {
              x: {
                grid: { display: false },
                border: { display: false },
                ticks: {
                  color: 'rgba(247, 251, 253, 0.54)',
                  maxRotation: 0,
                  autoSkip: true,
                  maxTicksLimit: 8,
                  font: { size: 9, weight: '600' }
                }
              },
              y: {
                beginAtZero: true,
                grace: '15%',
                border: { display: false },
                grid: { color: 'rgba(225, 241, 248, 0.12)', drawTicks: false },
                ticks: { display: false }
              }
            }
          }
        }));
      });
    }

    function renderChart(months) {
      var canvas = document.getElementById('inventoryStatisticsChartCanvas');
      if (!canvas || typeof Chart === 'undefined') {
        return;
      }

      destroyChart();

      var ctx = canvas.getContext('2d');
      var currentGradient = ctx.createLinearGradient(0, 0, 0, canvas.height || 320);
      currentGradient.addColorStop(0, 'rgba(62, 183, 125, 0.48)');
      currentGradient.addColorStop(0.5, 'rgba(62, 183, 125, 0.2)');
      currentGradient.addColorStop(1, 'rgba(62, 183, 125, 0.05)');
      var previousGradient = ctx.createLinearGradient(0, 0, 0, canvas.height || 320);
      previousGradient.addColorStop(0, 'rgba(66, 191, 220, 0.46)');
      previousGradient.addColorStop(0.5, 'rgba(66, 191, 220, 0.2)');
      previousGradient.addColorStop(1, 'rgba(66, 191, 220, 0.05)');
      var earliestGradient = ctx.createLinearGradient(0, 0, 0, canvas.height || 320);
      earliestGradient.addColorStop(0, 'rgba(224, 170, 40, 0.4)');
      earliestGradient.addColorStop(0.5, 'rgba(224, 170, 40, 0.16)');
      earliestGradient.addColorStop(1, 'rgba(224, 170, 40, 0.04)');

      chartInstance = new Chart(ctx, {
        type: 'line',
        data: {
          labels: months.map(function (item) { return formatSalesMonthShort(item.month_date || item.month); }),
          datasets: [{
            label: String(state.earliestYear || ''),
            data: months.map(function (item) { return Number(item.earliest_quantity || 0); }),
            borderColor: 'rgba(224, 170, 40, 0.96)',
            backgroundColor: earliestGradient,
            borderWidth: 2.25,
            fill: true,
            tension: 0.34,
            pointRadius: 2.75,
            pointHoverRadius: 4,
            pointBackgroundColor: '#ffffff',
            pointBorderColor: 'rgba(224, 170, 40, 0.96)',
            pointBorderWidth: 2.5
          }, {
            label: String(state.previousYear || ''),
            data: months.map(function (item) { return Number(item.previous_quantity || 0); }),
            borderColor: '#42bfdc',
            backgroundColor: previousGradient,
            borderWidth: 2.5,
            fill: true,
            tension: 0.34,
            pointRadius: 3,
            pointHoverRadius: 4,
            pointBackgroundColor: '#ffffff',
            pointBorderColor: '#42bfdc',
            pointBorderWidth: 3
          }, {
            label: String(state.selectedYear || ''),
            data: months.map(function (item) { return Number(item.quantity || 0); }),
            borderColor: '#3eb77d',
            backgroundColor: currentGradient,
            borderWidth: 3,
            fill: true,
            tension: 0.38,
            pointRadius: 3.5,
            pointHoverRadius: 4.5,
            pointBackgroundColor: '#ffffff',
            pointBorderColor: '#3eb77d',
            pointBorderWidth: 3
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          animation: { duration: 380, easing: 'easeOutCubic' },
          interaction: { mode: 'index', intersect: false },
          plugins: {
            legend: { display: false },
            tooltip: {
              displayColors: false,
              backgroundColor: 'rgba(255, 255, 255, 0.98)',
              titleColor: '#1b3b4d',
              bodyColor: '#35586b',
              borderColor: 'rgba(194, 214, 229, 0.9)',
              borderWidth: 1,
              padding: 12,
              callbacks: {
                title: function () { return ''; },
                labelTextColor: function (context) {
                  return context && context.dataset && context.dataset.borderColor ? context.dataset.borderColor : '#35586b';
                },
                label: function (context) {
                  var item = months[context.dataIndex] || {};
                  var datasetYear = context.datasetIndex === 0 ? state.earliestYear : (context.datasetIndex === 1 ? state.previousYear : state.selectedYear);
                  var monthDate = String(datasetYear || '') + '-' + String(context.dataIndex + 1).padStart(2, '0') + '-01';
                  var datasetValueGross = context.datasetIndex === 0 ? Number(item.earliest_value || 0) : (context.datasetIndex === 1 ? Number(item.previous_value || 0) : Number(item.value || 0));
                  var datasetValueNet = context.datasetIndex === 0 ? Number(item.earliest_value_net || 0) : (context.datasetIndex === 1 ? Number(item.previous_value_net || 0) : Number(item.value_net || 0));
                  var datasetOrderCount = context.datasetIndex === 0 ? Number(item.earliest_order_count || 0) : (context.datasetIndex === 1 ? Number(item.previous_order_count || 0) : Number(item.order_count || 0));
                  return formatSalesMonth(monthDate) + ': ' + String(context.parsed.y || 0) + ' ' + t('sales_units') + ' / ' + formatCurrencyAmount(datasetValueNet) + ' netto / ' + formatCurrencyAmount(datasetValueGross) + ' brutto / ' + formatOrdersLabel(datasetOrderCount);
                }
              }
            }
          },
          scales: {
            x: {
              grid: { color: 'rgba(188, 210, 225, 0.3)', drawTicks: false },
              border: { display: false },
              ticks: { color: 'rgba(70, 103, 123, 0.8)', maxRotation: 0, autoSkip: false, font: { size: 10, weight: '600' } }
            },
            y: {
              beginAtZero: true,
              grace: '10%',
              border: { display: false },
              grid: { color: 'rgba(188, 210, 225, 0.58)', drawTicks: false },
              ticks: { precision: 0, color: 'rgba(82, 113, 131, 0.78)', font: { size: 9, weight: '600' } }
            }
          }
        }
      });
    }

    function updateNav() {
      var prev = document.querySelector('.inventory-statistics-nav-prev');
      var next = document.querySelector('.inventory-statistics-nav-next');
      if (!prev || !next) {
        return;
      }
      prev.classList.toggle('is-disabled', false);
      next.classList.toggle('is-disabled', state.offsetMonths <= 0);
    }

    function renderStats(stats) {
      var months = stats && stats.months ? stats.months : [];
      var comparison = stats && stats.comparison ? stats.comparison : {};

      if (!months.length) {
        setPageState(t('sales_stats_empty'), true);
        setPageContent('', false);
        return;
      }

      state.selectedYear = Number(comparison.current_year || 0);
      state.previousYear = Number(comparison.previous_year || 0);
      state.earliestYear = Number(comparison.earliest_year || 0);

      var currentSummary = buildYearSummary(state.selectedYear, months.map(function (item) { return Number(item.quantity || 0); }), months.map(function (item) { return Number(item.value || 0); }), months.map(function (item) { return Number(item.value_net || 0); }));
      var previousSummary = buildYearSummary(state.previousYear, months.map(function (item) { return Number(item.previous_quantity || 0); }), months.map(function (item) { return Number(item.previous_value || 0); }), months.map(function (item) { return Number(item.previous_value_net || 0); }));
      var earliestSummary = buildYearSummary(state.earliestYear, months.map(function (item) { return Number(item.earliest_quantity || 0); }), months.map(function (item) { return Number(item.earliest_value || 0); }), months.map(function (item) { return Number(item.earliest_value_net || 0); }));
      var today = new Date();
      var selectedMonthIndex = today.getMonth();
      var currentMonthStats = getMonthStats(months, state.selectedYear, selectedMonthIndex);
      var previousMonthStats = getMonthStats(months, state.selectedYear, selectedMonthIndex - 1);
      var earlierMonthStats = getMonthStats(months, state.selectedYear, selectedMonthIndex - 2);
      var currentMonthDate = String(currentMonthStats.year || '') + '-' + String(Number(currentMonthStats.monthIndex || 0) + 1).padStart(2, '0') + '-01';
      var previousMonthDate = String(previousMonthStats.year || '') + '-' + String(Number(previousMonthStats.monthIndex || 0) + 1).padStart(2, '0') + '-01';
      var earlierMonthDate = String(earlierMonthStats.year || '') + '-' + String(Number(earlierMonthStats.monthIndex || 0) + 1).padStart(2, '0') + '-01';
      var monthTiles = [{
        label: formatSalesMonthLong(earlierMonthDate),
        stats: earlierMonthStats,
        className: 'is-earlier-month',
        colorTop: 'rgba(62, 183, 125, 0.95)',
        colorBottom: 'rgba(62, 183, 125, 0.34)',
        borderColor: 'rgba(139, 220, 178, 0.8)'
      }, {
        label: formatSalesMonthLong(previousMonthDate),
        stats: previousMonthStats,
        className: 'is-previous-month',
        colorTop: 'rgba(62, 183, 125, 0.95)',
        colorBottom: 'rgba(62, 183, 125, 0.32)',
        borderColor: 'rgba(139, 220, 178, 0.78)'
      }, {
        label: formatSalesMonthLong(currentMonthDate),
        stats: currentMonthStats,
        className: 'is-current-month',
        colorTop: 'rgba(62, 183, 125, 0.98)',
        colorBottom: 'rgba(62, 183, 125, 0.3)',
        borderColor: 'rgba(139, 220, 178, 0.74)'
      }];

      var html = '' +
        '<div class="inventory-sales-month-tiles">' +
          monthTiles.map(function (tile) {
            return renderMonthStatTile(tile.label, tile.stats, tile.className);
          }).join('') +
        '</div>' +
        '<div class="inventory-sales-years-grid">' +
          renderYearSummaryCard(earliestSummary, 'is-earliest') +
          renderYearSummaryCard(previousSummary, 'is-previous') +
          renderYearSummaryCard(currentSummary, 'is-current') +
        '</div>' +
        '<div class="inventory-sales-chart">' +
          '<div class="inventory-sales-chart-layout">' +
            '<button type="button" class="inventory-sales-nav inventory-statistics-nav-prev" aria-label="' + escapeHtml(t('previous_year')) + '" title="' + escapeHtml(t('previous_year')) + '"><span aria-hidden="true">&#8249;</span></button>' +
            '<div class="inventory-sales-chart-panel">' +
              '<div class="inventory-sales-chart-meta">' +
                '<div class="inventory-sales-chart-range">Porównanie roczne</div>' +
                '<div class="inventory-sales-chart-year">' +
                  '<span class="inventory-sales-year-badge is-earliest">' + escapeHtml(String(state.earliestYear || '')) + '</span>' +
                  '<span class="inventory-sales-year-badge is-previous">' + escapeHtml(String(state.previousYear || '')) + '</span>' +
                  '<span class="inventory-sales-year-badge is-current">' + escapeHtml(String(state.selectedYear || '')) + '</span>' +
                '</div>' +
              '</div>' +
              '<div class="inventory-sales-chart-surface">' +
                '<div class="inventory-sales-chart-canvas"><canvas id="inventoryStatisticsChartCanvas"></canvas></div>' +
                '<div class="inventory-sales-chart-footnote">Całkowita sprzedaż produktów</div>' +
              '</div>' +
            '</div>' +
            '<button type="button" class="inventory-sales-nav inventory-statistics-nav-next" aria-label="' + escapeHtml(t('next_year')) + '" title="' + escapeHtml(t('next_year')) + '"><span aria-hidden="true">&#8250;</span></button>' +
          '</div>' +
        '</div>';

      setPageState('', false);
      setPageContent(html, true);
      renderMonthCharts(monthTiles);
      renderChart(months);
      updateNav();
    }

    function fetchStats() {
      setPageState(t('sales_stats_loading'), true);
      setPageContent('', false);

      $.post(window.cargoStockManagerStatisticsConfig.ajaxUrl + '&action=GetGlobalSalesStats', {
        months: state.months,
        offset_months: state.offsetMonths
      }, null, 'json').done(function (resp) {
        if (!resp || !resp.ok || !resp.stats) {
          setPageState(resp && resp.error ? resp.error : t('error_sales_stats'), true);
          return;
        }
        renderStats(resp.stats);
      }).fail(function (xhr) {
        var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('error_sales_stats');
        setPageState(error, true);
      });
    }

    $(document).on('click', '.inventory-statistics-nav-prev', function () {
      state.offsetMonths += 12;
      fetchStats();
    });

    $(document).on('click', '.inventory-statistics-nav-next', function () {
      if (state.offsetMonths <= 0) {
        return;
      }
      state.offsetMonths = Math.max(0, state.offsetMonths - 12);
      fetchStats();
    });

    $(document).on('click', '.inventory-sales-month-expand', function () {
      var button = this;
      var tile = button.closest('.inventory-sales-month-tile');
      var expanded = tile && !tile.classList.contains('is-expanded');

      if (!tile) {
        return;
      }

      tile.classList.toggle('is-expanded', expanded);
      button.setAttribute('aria-expanded', expanded ? 'true' : 'false');
      button.setAttribute('aria-label', expanded ? 'Zwiń ranking produktów' : 'Rozwiń ranking produktów');
      button.setAttribute('title', expanded ? 'Zwiń ranking produktów' : 'Rozwiń ranking produktów');
    });

    $(document).on('click', '.inventory-sales-month-ranking-more', function () {
      var button = this;
      var panel = button.closest('.inventory-sales-month-ranking');
      var rows = panel ? Array.prototype.slice.call(panel.querySelectorAll('.inventory-sales-month-ranking-row')) : [];
      var visibleCount = Number(button.getAttribute('data-visible-count') || 10) + 10;

      rows.forEach(function (row, index) {
        row.classList.toggle('is-hidden', index >= visibleCount);
      });

      button.setAttribute('data-visible-count', String(visibleCount));
      if (visibleCount >= rows.length) {
        button.parentNode.removeChild(button);
      }
    });

    $(document).on('click', '.inventory-selected-report-sort', function () {
      var field = String(this.getAttribute('data-sort-field') || 'current');
      if (['current', 'range', 'year'].indexOf(field) === -1) {
        field = 'current';
      }

      if (selectedReportSortField === field) {
        selectedReportSortDir = selectedReportSortDir === 'asc' ? 'desc' : 'asc';
      } else {
        selectedReportSortField = field;
        selectedReportSortDir = 'desc';
      }
      if (selectedReportLastReport) {
        renderSelectedReport(selectedReportLastReport);
      }
    });

    $(document).on('click', '.inventory-selected-report-clear', function () {
      saveSelectedSalesReportProducts([]);
      selectedReportLastReport = null;
      selectedReportSortField = 'current';
      selectedReportSortDir = 'desc';
      fetchSelectedReport();
    });

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function () {
        fetchSelectedReport();
        fetchStats();
      });
    } else {
      fetchSelectedReport();
      fetchStats();
    }
  })();
</script>
