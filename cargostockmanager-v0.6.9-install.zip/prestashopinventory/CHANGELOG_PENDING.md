Włączone aktywne podmenu BO dla `Produkty`, `Dostawcy`, `Zamówienia`, `Ustawienia`, aby wpisy były widoczne w bocznym menu po aktualizacji.
