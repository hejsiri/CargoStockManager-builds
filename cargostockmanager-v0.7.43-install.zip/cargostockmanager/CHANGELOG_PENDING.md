# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Poprawa podglądu i pobierania plików PDF w zamówieniach po migracji ścieżek modułu.
