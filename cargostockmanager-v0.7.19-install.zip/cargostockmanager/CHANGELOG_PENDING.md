Ujednolicenie styli zakładek BO i spacingu Ustawień z pozostałymi sekcjami modułu.
Przeniesienie wspólnego stylu kart i tabów do nowoczesnego layoutu modułu.
