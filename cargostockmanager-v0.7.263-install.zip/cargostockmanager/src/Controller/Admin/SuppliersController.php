<?php
declare(strict_types=1);

namespace PrestaShop\Module\CargoStockManager\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerService.php';
require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerLicense.php';

if (!class_exists('PrestaShopBundle\\Security\\Attribute\\AdminSecurity')) {
    $legacySecurityClass = 'PrestaShopBundle\\Security\\Annotation\\Admin' . 'Security';
    if (class_exists($legacySecurityClass)) {
        class_alias($legacySecurityClass, 'PrestaShopBundle\\Security\\Attribute\\AdminSecurity');
    }
}

use PrestaShopBundle\Security\Attribute\AdminSecurity;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Response;

class SuppliersController extends AbstractInventoryController
{
    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function indexAction(Request $request): Response
    {
        $module = $this->getModuleInstance();
        $context = $this->getLegacyContext();
        $service = new \CargoStockManagerService($module->getLocalPath(), $context, $module);
        $texts = $this->inventoryTexts();
        $errors = [];
        $messages = [];
        $form = [];

        $licenseStatus = $this->getModuleLicenseStatus();

        if ($module instanceof \cargostockmanager) {
            $module->ensureTabsAvailable();
        }

        if (!($licenseStatus['valid'] ?? false) && $request->isMethod('POST')) {
            $errors[] = (string) ($licenseStatus['message'] ?? $this->translate('license_missing_message'));
        }

        if (($licenseStatus['valid'] ?? false) && $request->isMethod('POST') && \Tools::isSubmit('submitCargoStockManagerDeleteSupplier')) {
            try {
                $service->deleteSupplier((int) \Tools::getValue('id_supplier'));

                return $this->redirectToRoute('cargo_stock_manager_suppliers', [
                    'supplier_status' => 'deleted',
                ]);
            } catch (\Throwable $e) {
                $status = $e instanceof \InvalidArgumentException && $e->getMessage() === ($texts['supplier_delete_blocked'] ?? '')
                    ? 'delete_blocked'
                    : 'delete_error';

                return $this->redirectToRoute('cargo_stock_manager_suppliers', [
                    'supplier_status' => $status,
                ]);
            }
        }

        if (($licenseStatus['valid'] ?? false) && $request->isMethod('POST') && \Tools::isSubmit('submitCargoStockManagerSaveSupplier')) {
            $formData = [
                'id_supplier' => (int) \Tools::getValue('id_supplier'),
                'name' => (string) \Tools::getValue('supplier_name', ''),
                'description' => (string) \Tools::getValue('supplier_description', ''),
                'phone' => (string) \Tools::getValue('supplier_phone', ''),
                'email' => (string) \Tools::getValue('supplier_email', ''),
                'address1' => (string) \Tools::getValue('supplier_address1', ''),
                'address2' => (string) \Tools::getValue('supplier_address2', ''),
                'postcode' => (string) \Tools::getValue('supplier_postcode', ''),
                'city' => (string) \Tools::getValue('supplier_city', ''),
                'id_country' => (int) \Tools::getValue('supplier_id_country', 0),
            ];

            try {
                $savedSupplierId = $service->saveSupplier($formData);

                return $this->redirectToRoute('cargo_stock_manager_suppliers', [
                    'supplier_status' => $formData['id_supplier'] > 0 ? 'updated' : 'created',
                    'id_supplier' => $savedSupplierId,
                ]);
            } catch (\Throwable $e) {
                $errors[] = $texts['supplier_save_error'] ?? 'Could not save supplier.';
                if (\defined('_PS_MODE_DEV_') && _PS_MODE_DEV_) {
                    $errors[] = $e->getMessage();
                }

                $form = [
                    'show' => true,
                    'mode' => $formData['id_supplier'] > 0 ? 'edit' : 'create',
                    'title' => $formData['id_supplier'] > 0
                        ? ($texts['supplier_form_edit_title'] ?? 'Edit supplier')
                        : ($texts['supplier_form_new_title'] ?? 'New supplier'),
                    'data' => $formData,
                ];
            }
        }

        if (!$messages) {
            $status = (string) $request->query->get('supplier_status', '');
            if ($status === 'created') {
                $messages[] = $texts['supplier_created_message'] ?? 'Supplier created.';
            } elseif ($status === 'updated') {
                $messages[] = $texts['supplier_updated_message'] ?? 'Supplier updated.';
            } elseif ($status === 'deleted') {
                $messages[] = $texts['supplier_deleted_message'] ?? 'Supplier deleted.';
            } elseif ($status === 'delete_blocked') {
                $errors[] = $texts['supplier_delete_blocked'] ?? 'Cannot delete supplier assigned to orders.';
            } elseif ($status === 'delete_error') {
                $errors[] = $texts['supplier_delete_error'] ?? 'Could not delete supplier.';
            }
        }

        if (!$form) {
            if ($request->query->has('addSupplier')) {
                $form = [
                    'show' => true,
                    'mode' => 'create',
                    'title' => $texts['supplier_form_new_title'] ?? 'New supplier',
                    'data' => [
                        'id_supplier' => 0,
                        'name' => '',
                        'description' => '',
                        'id_address' => 0,
                        'phone' => '',
                        'email' => '',
                        'address1' => '',
                        'address2' => '',
                        'postcode' => '',
                        'city' => '',
                        'id_country' => (int) \Configuration::get('PS_COUNTRY_DEFAULT'),
                    ],
                ];
            } elseif (($licenseStatus['valid'] ?? false) && $request->query->has('editSupplier')) {
                $idSupplier = (int) $request->query->get('id_supplier', 0);

                try {
                    $form = [
                        'show' => true,
                        'mode' => 'edit',
                        'title' => $texts['supplier_form_edit_title'] ?? 'Edit supplier',
                        'data' => $service->getSupplierFormData($idSupplier),
                    ];
                } catch (\Throwable $e) {
                    $errors[] = $texts['supplier_not_found'] ?? 'Supplier not found.';
                }
            }
        }

        if (!$form) {
            $form = [
                'show' => false,
                'mode' => 'list',
                'title' => '',
                'data' => [
                    'id_supplier' => 0,
                    'name' => '',
                    'description' => '',
                    'id_address' => 0,
                    'phone' => '',
                    'email' => '',
                    'address1' => '',
                    'address2' => '',
                    'postcode' => '',
                    'city' => '',
                    'id_country' => (int) \Configuration::get('PS_COUNTRY_DEFAULT'),
                ],
            ];
        }

        $suppliers = [];
        if ($licenseStatus['valid'] ?? false) {
            $suppliers = array_map(function (array $supplier): array {
                $supplier['orders_url'] = $this->generateUrl('cargo_stock_manager_purchase_orders', [
                    'query' => (string) ($supplier['name'] ?? ''),
                ]);

                return $supplier;
            }, $service->getSuppliers());
        }

        return $this->renderInventoryPage(
            '@Modules/cargostockmanager/views/templates/admin-modern/suppliers.html.twig',
            'cargo_stock_manager_suppliers',
            'suppliers_tab',
            [
                'suppliers' => $suppliers,
                'supplierForm' => $form,
                'supplierMessages' => $messages,
                'supplierErrors' => $errors,
                'supplierCountries' => $service->getSupplierCountries(),
                'canManageSuppliers' => (bool) ($licenseStatus['valid'] ?? false),
                'supplierCreateUrl' => $this->generateUrl('cargo_stock_manager_suppliers', ['addSupplier' => 1]),
                'supplierListUrl' => $this->generateUrl('cargo_stock_manager_suppliers'),
                'licenseStatus' => $licenseStatus,
            ]
        );
    }
}
