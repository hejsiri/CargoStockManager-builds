<?php

require_once dirname(__DIR__, 2) . '/classes/CargoStockManagerService.php';
require_once dirname(__DIR__, 2) . '/classes/CargoStockManagerI18n.php';
require_once dirname(__DIR__, 2) . '/classes/CargoStockManagerLicense.php';
require_once dirname(__DIR__, 2) . '/classes/CargoStockManagerUpdater.php';

class AdminCargoStockManagerController extends ModuleAdminController
{
    private CargoStockManagerService $inventoryService;
    private CargoStockManagerLicense $licenseService;
    private CargoStockManagerUpdater $updaterService;

    public function __construct()
    {
        $this->bootstrap = true;

        parent::__construct();

        $this->inventoryService = new CargoStockManagerService($this->module->getLocalPath(), $this->context, $this->module);
        $this->licenseService = new CargoStockManagerLicense($this->module->getLocalPath(), $this->context, $this->module);
        $this->updaterService = new CargoStockManagerUpdater($this->module->getLocalPath(), $this->context, $this->module);
    }

    public function initContent(): void
    {
        $this->assertViewAccess();

        if ($this->shouldUseModernAdminNavigation() && !Tools::getIsset('ajax') && !Tools::getIsset('exportPdf')) {
            Tools::redirectAdmin($this->getModuleRouteUrl('cargo_stock_manager_products'));
        }

        if ($this->module instanceof CargoStockManager) {
            $this->module->ensureTabsAvailable();
        }

        $translations = $this->inventoryService->getTranslations();
        $licenseStatus = $this->licenseService->getStatus();
        $assetsVersion = $this->module instanceof CargoStockManager
            ? $this->module->getAssetVersion('views/js/chart.umd.min.js')
            : (string) $this->module->version;

        $this->context->smarty->assign([
            'inventoryCatalogUrl' => $this->context->link->getAdminLink('AdminProducts', true),
            'inventoryModuleUrl' => $this->context->link->getAdminLink('AdminCargoStockManager', true),
            'inventorySuppliersUrl' => $this->context->link->getAdminLink('AdminCargoStockManagerSuppliers', true),
            'inventoryPurchaseOrdersUrl' => $this->context->link->getAdminLink('AdminCargoStockManagerPurchaseOrders', true),
            'inventoryModuleBaseUrl' => $this->module->getPathUri(),
            'inventoryAjaxUrl' => $this->context->link->getAdminLink('AdminCargoStockManager', true, [], [
                'ajax' => 1,
            ]),
            'inventoryExportUrl' => $this->context->link->getAdminLink('AdminCargoStockManager', true, [], [
                'exportPdf' => 1,
            ]),
            'inventoryConfigUrl' => $this->context->link->getAdminLink('AdminModules', true, [], [
                'configure' => $this->module->name,
                'module_name' => $this->module->name,
                'tab_module' => $this->module->tab,
            ]),
            'inventoryLanguageIso' => (string) $this->context->language->iso_code,
            'inventoryCanEdit' => $this->access('edit'),
            'inventoryTranslations' => $translations,
            'inventoryTranslationsJson' => json_encode($translations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'inventoryModuleVersion' => (string) $this->module->version,
            'inventoryAssetsVersion' => $assetsVersion,
            'inventoryLicenseStatus' => $licenseStatus,
            'inventoryUpdateConfigured' => $this->updaterService->isConfigured(),
        ]);

        $this->content = $this->module->display(
            $this->module->getLocalPath() . $this->module->name . '.php',
            'views/templates/admin/app.tpl'
        );

        parent::initContent();
    }

    private function getModuleRouteUrl(string $routeName): string
    {
        $router = \PrestaShop\PrestaShop\Adapter\SymfonyContainer::getInstance()->get('router');

        return $router->generate($routeName);
    }

    private function shouldUseModernAdminNavigation(): bool
    {
        return version_compare(_PS_VERSION_, '9.0.0', '>=');
    }

    public function postProcess(): void
    {
        if (Tools::getIsset('exportPdf')) {
            $this->assertViewAccess();
            $this->assertLicenseValid();
            $this->inventoryService->outputPdfReport([
                'lang' => (string) Tools::getValue('lang', (string) $this->context->language->iso_code),
                'activeOnly' => (string) Tools::getValue('activeOnly', '0'),
                'onlyAvailable' => (string) Tools::getValue('onlyAvailable', '0'),
                'missingPurchasePriceOnly' => (string) Tools::getValue('missingPurchasePriceOnly', '0'),
                'missingWeightOnly' => (string) Tools::getValue('missingWeightOnly', '0'),
                'showWeight' => (string) Tools::getValue('showWeight', '1'),
                'showUnitVolume' => (string) Tools::getValue('showUnitVolume', '1'),
                'showUnitsPerCarton' => (string) Tools::getValue('showUnitsPerCarton', '1'),
                'showCartonDimensions' => (string) Tools::getValue('showCartonDimensions', '1'),
                'showCartonGrossWeight' => (string) Tools::getValue('showCartonGrossWeight', '1'),
                'showBrutto' => (string) Tools::getValue('showBrutto', '1'),
                'query' => (string) Tools::getValue('query', ''),
            ]);
        }

        parent::postProcess();
    }

    public function ajaxProcessFetchProducts(): void
    {
        header('Content-Type: application/json; charset=utf-8');

        try {
            $this->assertViewAccess();

            echo json_encode($this->inventoryService->renderProductsTable([
                'query' => (string) Tools::getValue('query', ''),
                'keywords' => Tools::getValue('keywords'),
                'activeOnly' => Tools::getValue('activeOnly'),
                'onlyAvailable' => Tools::getValue('onlyAvailable'),
                'missingPurchasePriceOnly' => Tools::getValue('missingPurchasePriceOnly'),
                'missingWeightOnly' => Tools::getValue('missingWeightOnly'),
                'showWeight' => Tools::getValue('showWeight', 1),
                'showUnitVolume' => Tools::getValue('showUnitVolume', 1),
                'showUnitsPerCarton' => Tools::getValue('showUnitsPerCarton', 1),
                'showCartonDimensions' => Tools::getValue('showCartonDimensions', 1),
                'showCartonGrossWeight' => Tools::getValue('showCartonGrossWeight', 1),
                'showMaterial' => Tools::getValue('showMaterial', 1),
                'showHsCode' => Tools::getValue('showHsCode', 1),
                'showCustomsDutyRate' => Tools::getValue('showCustomsDutyRate', 1),
                'showBrutto' => Tools::getValue('showBrutto', 1),
                'lang' => (string) Tools::getValue('lang', (string) $this->context->language->iso_code),
                'sort_field' => (string) Tools::getValue('sort_field', 'id_product'),
                'sort_dir' => (string) Tools::getValue('sort_dir', 'DESC'),
                'page' => (int) Tools::getValue('page', 1),
                'per_page' => (int) Tools::getValue('per_page', 20),
            ]));
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => _PS_MODE_DEV_
                    ? $e->getMessage()
                    : CargoStockManagerI18n::translate($this->module, 'load_error'),
            ]);
        }
        exit;
    }

    public function ajaxProcessSavePrice(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $price = $this->inventoryService->saveWholesalePrice(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('price', '')
            );

            echo json_encode([
                'ok' => true,
                'price' => $price,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => _PS_MODE_DEV_
                    ? CargoStockManagerI18n::translate($this->module, 'db_update_error') . ': ' . $e->getMessage()
                    : CargoStockManagerI18n::translate($this->module, 'db_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessSaveRetailPrice(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $price = $this->inventoryService->saveRetailGrossPrice(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('price', '')
            );

            echo json_encode([
                'ok' => true,
                'price' => $price,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => _PS_MODE_DEV_
                    ? CargoStockManagerI18n::translate($this->module, 'db_update_error') . ': ' . $e->getMessage()
                    : CargoStockManagerI18n::translate($this->module, 'db_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessToggleProductActive(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $isActive = $this->inventoryService->setProductActive(
                (int) Tools::getValue('id_product'),
                Tools::getValue('active')
            );

            echo json_encode([
                'ok' => true,
                'active' => $isActive ? 1 : 0,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessSaveQuantity(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $quantity = $this->inventoryService->saveQuantity(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('quantity', '')
            );

            echo json_encode([
                'ok' => true,
                'quantity' => $quantity,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'stock_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessSaveWeight(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $weight = $this->inventoryService->saveWeight(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('weight', '')
            );

            echo json_encode([
                'ok' => true,
                'weight' => $weight,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessSaveUnitVolume(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $volume = $this->inventoryService->saveUnitVolume(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('volume', '')
            );

            echo json_encode([
                'ok' => true,
                'volume' => $volume,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessSaveUnitsPerCarton(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $units = $this->inventoryService->saveUnitsPerCarton(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('units_per_carton', '')
            );

            echo json_encode([
                'ok' => true,
                'units_per_carton' => $units,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessSaveMaterial(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $value = $this->inventoryService->saveMaterial(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('material', '')
            );

            echo json_encode(['ok' => true, 'material' => $value]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode(['ok' => false, 'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error')]);
        }

        exit;
    }

    public function ajaxProcessSaveModuleModel(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $value = $this->inventoryService->saveModuleModel(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('module_model', '')
            );

            echo json_encode(['ok' => true, 'module_model' => $value]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode(['ok' => false, 'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error')]);
        }

        exit;
    }

    public function ajaxProcessSaveLogisticsDescription(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $value = $this->inventoryService->saveLogisticsDescription(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('description', '')
            );

            echo json_encode(['ok' => true, 'description' => $value]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode(['ok' => false, 'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error')]);
        }

        exit;
    }

    public function ajaxProcessSaveHsCode(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $value = $this->inventoryService->saveHsCode(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('hs_code', '')
            );

            echo json_encode(['ok' => true, 'hs_code' => $value]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode(['ok' => false, 'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error')]);
        }

        exit;
    }

    public function ajaxProcessSaveCustomsDutyRate(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $rate = $this->inventoryService->saveCustomsDutyRate(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('customs_duty_rate', '')
            );

            echo json_encode(['ok' => true, 'customs_duty_rate' => $rate]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode(['ok' => false, 'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error')]);
        }

        exit;
    }

    public function ajaxProcessSaveCartonDimensions(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $dimensions = $this->inventoryService->saveCartonDimensions(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('carton_dimensions', '')
            );

            echo json_encode([
                'ok' => true,
                'carton_dimensions' => $dimensions,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessSaveCartonGrossWeight(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $weight = $this->inventoryService->saveCartonGrossWeight(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('carton_gross_weight', '')
            );

            echo json_encode([
                'ok' => true,
                'carton_gross_weight' => $weight,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessGetSalesStats(): void
    {
        $this->assertViewAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $stats = $this->inventoryService->getMonthlySalesStats(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (int) Tools::getValue('months', 12),
                (int) Tools::getValue('offset_months', 0)
            );

            echo json_encode([
                'ok' => true,
                'stats' => $stats,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'error_sales_stats'),
            ]);
        }

        exit;
    }

    public function ajaxProcessGetPurchasePriceHistory(): void
    {
        $this->assertViewAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $history = $this->inventoryService->getPurchasePriceHistory(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute')
            );

            echo json_encode([
                'ok' => true,
                'history' => $history,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'error_sales_stats'),
            ]);
        }

        exit;
    }

    public function ajaxProcessHideProduct(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $result = $this->inventoryService->hideProduct(
                (int) Tools::getValue('id_product')
            );

            echo json_encode([
                'ok' => true,
                'id_product' => (int) $result['id_product'],
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'hide_product_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessFindProductByEan(): void
    {
        $this->assertViewAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $ean = trim((string) Tools::getValue('ean', ''));
            $lang = (string) Tools::getValue('lang', '');

            if ($ean === '') {
                throw new InvalidArgumentException('Brak kodu EAN.');
            }

            $product = $this->inventoryService->findProductByEan($ean, $lang);
            if ($product === null) {
                echo json_encode(['ok' => false, 'not_found' => true]);
                exit;
            }

            echo json_encode(['ok' => true, 'product' => $product]);
        } catch (Throwable $e) {
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        }

        exit;
    }

    public function ajaxProcessCheckForUpdates(): void
    {
        $this->assertViewAccess();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $status = $this->updaterService->checkForUpdates();
            echo json_encode([
                'ok' => true,
                'status' => $status,
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'update_check_error_message'),
            ]);
        }

        exit;
    }

    public function ajaxProcessInstallUpdate(): void
    {
        $this->assertEditAccess();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $result = $this->updaterService->installAvailableUpdate();
            echo json_encode([
                'ok' => true,
                'version' => (string) ($result['version'] ?? ''),
                'message' => CargoStockManagerI18n::translate($this->module, 'update_installed_message'),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'update_install_error_message'),
            ]);
        }

        exit;
    }

    public function ajaxProcessSaveCarrier(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();
        header('Content-Type: application/json; charset=utf-8');
        try {
            $result = $this->inventoryService->saveCarrier(
                (int) Tools::getValue('id', 0),
                (string) Tools::getValue('name', '')
            );
            echo json_encode(['ok' => true, 'carrier' => $result]);
        } catch (\Throwable $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }

    public function ajaxProcessDeleteCarrier(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();
        header('Content-Type: application/json; charset=utf-8');
        try {
            $this->inventoryService->deleteCarrier((int) Tools::getValue('id', 0));
            echo json_encode(['ok' => true]);
        } catch (\Throwable $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }

    public function ajaxProcessSaveDocumentType(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();
        header('Content-Type: application/json; charset=utf-8');
        try {
            $result = $this->inventoryService->saveDocumentType(
                (int) Tools::getValue('id', 0),
                (string) Tools::getValue('name', '')
            );
            echo json_encode(['ok' => true, 'document_type' => $result]);
        } catch (\Throwable $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }

    public function ajaxProcessDeleteDocumentType(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();
        header('Content-Type: application/json; charset=utf-8');
        try {
            $this->inventoryService->deleteDocumentType((int) Tools::getValue('id', 0));
            echo json_encode(['ok' => true]);
        } catch (\Throwable $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }

    public function ajaxProcessSaveOrderStatus(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();
        header('Content-Type: application/json; charset=utf-8');
        try {
            $key = (string) Tools::getValue('key', '');
            $label = (string) Tools::getValue('label', '');
            $color = (string) Tools::getValue('color', '#25B9D7');
            $menuBadgeEnabled = (string) Tools::getValue('menu_badge_enabled', '') === '1';

            if ($key === '' || $key === '0') {
                $status = $this->inventoryService->addOrderStatusEntry($label, $color, $menuBadgeEnabled);
            } else {
                $status = $this->inventoryService->saveOrderStatusEntry($key, $label, $color, $menuBadgeEnabled);
            }
            echo json_encode(['ok' => true, 'status' => $status]);
        } catch (\Throwable $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }

    public function ajaxProcessDeleteOrderStatus(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();
        header('Content-Type: application/json; charset=utf-8');
        try {
            $this->inventoryService->deleteOrderStatusEntry((string) Tools::getValue('key', ''));
            echo json_encode(['ok' => true]);
        } catch (\Throwable $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }

    private function assertViewAccess(): void
    {
        if (!$this->access('view')) {
            throw new PrestaShopException(CargoStockManagerI18n::translate($this->module, 'access_denied'));
        }
    }

    private function assertEditAccess(): void
    {
        if (!$this->access('edit')) {
            http_response_code(403);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'access_denied'),
            ]);
            exit;
        }
    }

    private function assertLicenseValid(): void
    {
        $status = $this->licenseService->getStatus();
        if (!empty($status['valid'])) {
            return;
        }

        http_response_code(403);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'ok' => false,
            'error' => (string) ($status['message'] ?? CargoStockManagerI18n::translate($this->module, 'license_missing_message')),
        ]);
        exit;
    }
}
