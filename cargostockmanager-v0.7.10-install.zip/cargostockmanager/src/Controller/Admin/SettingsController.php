<?php
declare(strict_types=1);

namespace PrestaShop\Module\CargoStockManager\Controller\Admin;

require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerService.php';
require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerLicense.php';

use PrestaShopBundle\Security\Annotation\AdminSecurity;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class SettingsController extends AbstractInventoryController
{
    /**
     * @AdminSecurity("is_granted('read', request.get('_legacy_controller'))")
     */
    public function indexAction(Request $request): Response
    {
        $this->assertModuleLicenseValid();

        $module = \Module::getInstanceByName('cargostockmanager');
        $context = \Context::getContext();
        $service = new \CargoStockManagerService($module->getLocalPath(), $context, $module);
        $licenseService = new \CargoStockManagerLicense($module->getLocalPath(), $context, $module);
        $messages = [];
        $errors = [];

        if ($module instanceof \CargoStockManager) {
            $module->ensureTabsAvailable();
        }

        if ($request->isMethod('POST') && \Tools::isSubmit('submitCargoStockManagerRestoreHidden')) {
            try {
                $service->unhideProduct((int) \Tools::getValue('id_product'));
                $messages[] = $this->translate('product_restored');
            } catch (\Throwable $e) {
                $errors[] = $this->translate('product_restore_error');
                if (\defined('_PS_MODE_DEV_') && _PS_MODE_DEV_) {
                    $errors[] = $e->getMessage();
                }
            }
        }

        if ($request->isMethod('POST') && \Tools::isSubmit('submitCargoStockManagerSaveOrderSettings')) {
            try {
                $postedStatuses = \Tools::getValue('cargoStockManagerOrderStatuses', []);
                $service->savePurchaseOrderSettings(
                    (string) \Tools::getValue('cargoStockManagerDeliveryAddress', ''),
                    is_array($postedStatuses) ? $postedStatuses : []
                );
                $messages[] = 'Ustawienia zamówień zostały zapisane.';
            } catch (\Throwable $e) {
                $errors[] = 'Nie udało się zapisać ustawień zamówień.';
                if (\defined('_PS_MODE_DEV_') && _PS_MODE_DEV_) {
                    $errors[] = $e->getMessage();
                }
            }
        }

        $licenseStatus = $licenseService->getStatus();
        $licenseDetails = is_array($licenseStatus['details'] ?? null) ? $licenseStatus['details'] : [];
        $licensePayload = is_array($licenseDetails['payload'] ?? null) ? $licenseDetails['payload'] : [];
        $licenseCustomer = trim((string) ($licensePayload['customer'] ?? ''));
        $licenseDomain = trim((string) ($licenseDetails['domain'] ?? $licensePayload['domain'] ?? ''));
        $licenseExpiresAt = trim((string) ($licenseDetails['expires_at'] ?? $licensePayload['expires_at'] ?? ''));

        $context->smarty->assign([
            'cargoStockManagerConfigAction' => $this->generateUrl('cargo_stock_manager_settings'),
            'cargoStockManagerBackUrl' => $this->generateUrl('cargo_stock_manager_products'),
            'cargoStockManagerSuppliersUrl' => $this->generateUrl('cargo_stock_manager_suppliers'),
            'cargoStockManagerPurchaseOrdersUrl' => $this->generateUrl('cargo_stock_manager_purchase_orders'),
            'cargoStockManagerIgnoredProducts' => $service->getIgnoredProducts(),
            'cargoStockManagerTranslations' => $service->getTranslations(),
            'cargoStockManagerModuleVersion' => (string) $module->version,
            'cargoStockManagerLicenseStatus' => $licenseStatus,
            'cargoStockManagerLicenseSummary' => [
                'customer' => $licenseCustomer !== '' ? $licenseCustomer : '—',
                'domain' => $licenseDomain !== '' ? $licenseDomain : '—',
                'expires_at' => $licenseExpiresAt !== '' ? $licenseExpiresAt : '—',
            ],
            'cargoStockManagerEmbeddedInModernLayout' => true,
            'cargoStockManagerMessages' => $messages,
            'cargoStockManagerErrors' => $errors,
            'cargoStockManagerDeliveryAddress' => $service->getConfiguredDeliveryAddress(),
            'cargoStockManagerOrderStatuses' => $service->getConfiguredPurchaseOrderStatuses(),
            'cargoStockManagerCarriers' => $service->getCarriers(),
            'cargoStockManagerDocumentTypes' => $service->getDocumentTypes(),
            'cargoStockManagerIncotermOptions' => $service->getPurchaseOrderIncotermOptions(),
            'cargoStockManagerAjaxUrl' => $context->link->getAdminLink('AdminCargoStockManagerProducts', true, [], ['ajax' => 1]),
        ]);

        $legacyContent = $module->display(
            $module->getLocalPath() . $module->name . '.php',
            'views/templates/admin/configure.tpl'
        );

        return $this->renderInventoryPage(
            '@Modules/cargostockmanager/views/templates/admin-modern/settings.html.twig',
            'cargo_stock_manager_settings',
            'settings_tab',
            [
                'legacyContent' => $legacyContent,
            ]
        );
    }
}
