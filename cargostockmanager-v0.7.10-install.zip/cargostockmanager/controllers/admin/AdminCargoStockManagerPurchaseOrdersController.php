<?php

require_once dirname(__DIR__, 2) . '/classes/CargoStockManagerService.php';
require_once dirname(__DIR__, 2) . '/classes/CargoStockManagerI18n.php';
require_once dirname(__DIR__, 2) . '/classes/CargoStockManagerLicense.php';

class AdminCargoStockManagerPurchaseOrdersController extends ModuleAdminController
{
    private CargoStockManagerService $inventoryService;
    private CargoStockManagerLicense $licenseService;

    public function __construct()
    {
        $this->bootstrap = true;

        parent::__construct();

        $this->inventoryService = new CargoStockManagerService($this->module->getLocalPath(), $this->context, $this->module);
        $this->licenseService = new CargoStockManagerLicense($this->module->getLocalPath(), $this->context, $this->module);
    }

    public function initContent(): void
    {
        $this->assertLicenseValid();

        Tools::redirectAdmin($this->getModuleRouteUrl('cargo_stock_manager_purchase_orders'));

        if ($this->module instanceof CargoStockManager) {
            $this->module->ensureTabsAvailable();
        }

        $translations = $this->inventoryService->getTranslations();
        $licenseStatus = $this->licenseService->getStatus();
        $purchaseOrders = $this->inventoryService->getPurchaseOrders();

        $this->context->smarty->assign([
            'inventoryModuleUrl' => $this->context->link->getAdminLink('AdminCargoStockManagerProducts', true),
            'inventorySuppliersUrl' => $this->context->link->getAdminLink('AdminCargoStockManagerSuppliers', true),
            'inventoryPurchaseOrdersUrl' => $this->context->link->getAdminLink('AdminCargoStockManagerPurchaseOrders', true),
            'inventoryConfigUrl' => $this->context->link->getAdminLink('AdminModules', true, [], [
                'configure' => $this->module->name,
                'module_name' => $this->module->name,
                'tab_module' => $this->module->tab,
            ]),
            'inventoryTranslations' => $translations,
            'inventoryLicenseStatus' => $licenseStatus,
            'inventoryPurchaseOrders' => $purchaseOrders,
        ]);

        $this->content = $this->module->display(
            $this->module->getLocalPath() . $this->module->name . '.php',
            'views/templates/admin/purchase_orders.tpl'
        );

        parent::initContent();
    }

    private function getModuleRouteUrl(string $routeName): string
    {
        $router = \PrestaShop\PrestaShop\Adapter\SymfonyContainer::getInstance()->get('router');
        $query = $_GET;
        unset($query['controller'], $query['token']);
        unset($query['view']);

        $url = $router->generate($routeName);
        if (!$query) {
            return $url;
        }

        return $url . (strpos($url, '?') === false ? '?' : '&') . http_build_query($query);
    }

    private function assertLicenseValid(): void
    {
        $status = $this->licenseService->getStatus();
        if (!($status['valid'] ?? false)) {
            throw new PrestaShopException((string) ($status['message'] ?? CargoStockManagerI18n::translate($this->module, 'license_missing_message')));
        }
    }
}
