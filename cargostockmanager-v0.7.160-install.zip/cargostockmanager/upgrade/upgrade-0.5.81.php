<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_5_81(Module $module): bool
{
    return true;
}
