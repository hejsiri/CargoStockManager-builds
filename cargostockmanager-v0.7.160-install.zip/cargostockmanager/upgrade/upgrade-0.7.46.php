<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_7_46($module)
{
    return is_object($module);
}
