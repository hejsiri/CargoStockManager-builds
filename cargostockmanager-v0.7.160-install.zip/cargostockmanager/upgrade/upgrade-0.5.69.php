<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_5_69(Module $module): bool
{
    return true;
}
