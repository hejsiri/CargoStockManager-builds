<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_7_15(Module $module): bool
{
    return true;
}
