<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_5_126(Module $module): bool
{
    return true;
}
