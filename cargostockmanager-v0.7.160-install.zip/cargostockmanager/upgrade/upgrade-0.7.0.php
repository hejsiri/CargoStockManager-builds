<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_7_0(Module $module): bool
{
    if (method_exists($module, 'ensureTabsAvailable')) {
        $module->ensureTabsAvailable();
    }

    if (method_exists($module, 'ensureModuleRuntimeReady')) {
        $module->ensureModuleRuntimeReady();
    }

    return true;
}
