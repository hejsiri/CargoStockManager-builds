<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_7_8(Module $module): bool
{
    return true;
}
