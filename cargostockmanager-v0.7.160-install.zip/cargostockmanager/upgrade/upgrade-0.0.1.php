<?php
/**
 * Generic upgrade stub — PrestaShop requires at least one upgrade script
 * in the upgrade/ directory to update the module version in ps_module.
 * This file covers upgrades from any version to the current one.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_0_1(Module $module): bool
{
    return true;
}
