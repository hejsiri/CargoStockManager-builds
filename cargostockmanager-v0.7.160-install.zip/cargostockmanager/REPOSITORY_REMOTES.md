# Repository Remotes

Projekt trzyma definicje remote'ow w pliku `config/git-remotes.conf`.

- Kod zrodlowy: `origin` -> `git@github.com:hejsiri/CargoStockManager.git`
- Buildy release: `builds` -> `git@github.com:hejsiri/CargoStockManager-builds.git`

Aby ustawic remotes w lokalnym repo:

```bash
bash scripts/setup_git_remotes.sh
```

Aby wypchnac zmiany:

```bash
bash scripts/push_git_remote.sh source
bash scripts/push_git_remote.sh builds
```

Mozesz tez przekazac dodatkowe argumenty do `git push`, na przyklad:

```bash
bash scripts/push_git_remote.sh source --force-with-lease
```

Skrypt:

- ustawia lub aktualizuje remote `origin` dla prywatnego repo zrodlowego,
- ustawia lub aktualizuje remote `builds` dla publicznego repo buildow,
- nie tworzy commita ani nie wykonuje `git push`.

Skrypt `push_git_remote.sh`:

- wypycha aktualna lokalna galaz do skonfigurowanego brancha docelowego,
- obsluguje target `source` i `builds`,
- wymaga istniejacego lokalnego repo git oraz skonfigurowanych remote'ow.
