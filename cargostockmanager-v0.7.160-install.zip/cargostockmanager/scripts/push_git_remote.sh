#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
CONFIG_FILE="${PROJECT_ROOT}/config/git-remotes.conf"

if [[ ! -f "${CONFIG_FILE}" ]]; then
  echo "Brak pliku konfiguracyjnego: ${CONFIG_FILE}" >&2
  exit 1
fi

# shellcheck disable=SC1090
source "${CONFIG_FILE}"

if ! git -C "${PROJECT_ROOT}" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "Katalog ${PROJECT_ROOT} nie jest repozytorium git." >&2
  exit 1
fi

TARGET="${1:-}"
if [[ -z "${TARGET}" ]]; then
  echo "Uzycie: bash scripts/push_git_remote.sh <source|builds> [git push args...]" >&2
  exit 1
fi
shift || true

case "${TARGET}" in
  source)
    REMOTE_NAME="${SOURCE_REMOTE_NAME}"
    REMOTE_BRANCH="${SOURCE_REMOTE_BRANCH}"
    ;;
  builds)
    REMOTE_NAME="${BUILDS_REMOTE_NAME}"
    REMOTE_BRANCH="${BUILDS_REMOTE_BRANCH}"
    ;;
  *)
    echo "Nieznany target: ${TARGET}. Uzyj source albo builds." >&2
    exit 1
    ;;
esac

if ! git -C "${PROJECT_ROOT}" remote get-url "${REMOTE_NAME}" >/dev/null 2>&1; then
  echo "Remote ${REMOTE_NAME} nie jest skonfigurowany. Najpierw uruchom: bash scripts/setup_git_remotes.sh" >&2
  exit 1
fi

CURRENT_BRANCH="$(git -C "${PROJECT_ROOT}" rev-parse --abbrev-ref HEAD)"
if [[ "${CURRENT_BRANCH}" == "HEAD" ]]; then
  echo "Jestes w detached HEAD. Przelacz sie na branche przed push." >&2
  exit 1
fi

echo "Push do ${TARGET}: ${REMOTE_NAME} (${CURRENT_BRANCH}:${REMOTE_BRANCH})"
git -C "${PROJECT_ROOT}" push "${REMOTE_NAME}" "${CURRENT_BRANCH}:${REMOTE_BRANCH}" "$@"
