#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
CONFIG_FILE="${PROJECT_ROOT}/config/git-remotes.conf"

if [[ ! -f "${CONFIG_FILE}" ]]; then
  echo "Brak pliku konfiguracyjnego: ${CONFIG_FILE}" >&2
  exit 1
fi

# shellcheck disable=SC1090
source "${CONFIG_FILE}"

if ! git -C "${PROJECT_ROOT}" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "Katalog ${PROJECT_ROOT} nie jest repozytorium git." >&2
  echo "Zainicjalizuj repo (`git init`) albo uruchom ten skrypt w katalogu repo." >&2
  exit 1
fi

set_remote() {
  local remote_name="$1"
  local remote_url="$2"

  if git -C "${PROJECT_ROOT}" remote get-url "${remote_name}" >/dev/null 2>&1; then
    git -C "${PROJECT_ROOT}" remote set-url "${remote_name}" "${remote_url}"
  else
    git -C "${PROJECT_ROOT}" remote add "${remote_name}" "${remote_url}"
  fi
}

set_remote "${SOURCE_REMOTE_NAME}" "${SOURCE_REMOTE_URL}"
set_remote "${BUILDS_REMOTE_NAME}" "${BUILDS_REMOTE_URL}"

echo "Skonfigurowano remotes:"
git -C "${PROJECT_ROOT}" remote -v
echo
echo "Repo zrodlowe: ${SOURCE_REMOTE_NAME} -> ${SOURCE_REMOTE_URL} (branch ${SOURCE_REMOTE_BRANCH})"
echo "Repo buildow: ${BUILDS_REMOTE_NAME} -> ${BUILDS_REMOTE_URL} (branch ${BUILDS_REMOTE_BRANCH})"
