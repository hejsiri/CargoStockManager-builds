# Release Automation

Do pelnego wypchniecia aktualizacji potrzebny jest prywatny klucz podpisu odpowiadajacy:

- [update_public.pem](/Users/paweltucki/Sites/localhost/cargostockmanager-source/keys/update_public.pem)
- fingerprint SHA-256 klucza publicznego: `63896620f7793b2d06761c6b3f30f38b50102e5e3f707e9eff2caf1d600f1cd9`

Bez tego klucza da sie wypchnac samo zrodlo i sam ZIP, ale nie da sie poprawnie zaktualizowac `latest.json`, a wtedy automatyczny updater w module nie zobaczy nowej wersji.

## Konfiguracja

1. Skopiuj:

```bash
cp config/release-build.conf.example config/release-build.conf
```

2. Ustaw w `config/release-build.conf`:

- `UPDATE_SIGNING_PRIVATE_KEY` do prywatnego klucza podpisu
- `LOCAL_RELEASES_PATH` jesli chcesz zmienic lokalny katalog, w ktorym zostaja zapisane gotowe buildy do recznej instalacji
- `RELEASE_KEEP_ZIPS` jesli chcesz trzymac inna liczbe ostatnich buildow niz 5
- `RELEASE_CHANNEL=public` albo `RELEASE_CHANNEL=beta`
- opcjonalnie lokalizacje repo i `DRY_RUN`

## Release

Po podbiciu wersji w module uruchom:

```bash
bash scripts/release_build.sh
```

Albo jednorazowo dla konkretnego kanalu:

```bash
RELEASE_CHANNEL=beta bash scripts/release_build.sh
```

Skrypt:

- klonuje publiczne repo `CargoStockManager-builds`
- buduje ZIP z aktualnego `HEAD`
- liczy `sha256`
- podpisuje manifest `latest.json` albo `latest-beta.json`
- zapisuje lokalna kopie ZIP-a oraz manifest kanału w `LOCAL_RELEASES_PATH`
- usuwa starsze ZIP-y i zostawia tylko ostatnie `RELEASE_KEEP_ZIPS` buildow
- commituje i pushuje ZIP oraz manifest do repo buildow
