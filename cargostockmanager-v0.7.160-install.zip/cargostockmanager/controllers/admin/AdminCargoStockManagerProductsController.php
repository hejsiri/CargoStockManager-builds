<?php

require_once __DIR__ . '/AdminCargoStockManagerController.php';

class AdminCargoStockManagerProductsController extends AdminCargoStockManagerController
{
}
