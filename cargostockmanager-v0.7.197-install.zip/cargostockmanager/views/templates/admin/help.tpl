<div class="inventory-module-content">
<div id="csmgr-help-head-tabs-source" class="page-head-tabs inventory-panel-tabs" role="tablist" aria-label="{$inventoryTranslations.module_navigation|escape:'html':'UTF-8'}">
  <ul class="nav nav-pills">
    <li class="nav-item">
      <a href="{$inventoryModuleUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">category</span><span>{$inventoryTranslations.products_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
    <li class="nav-item">
      <a href="{$inventorySuppliersUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">factory</span><span>{$inventoryTranslations.suppliers_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
    <li class="nav-item">
      <a href="{$inventoryPurchaseOrdersUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">inventory_2</span><span>{$inventoryTranslations.purchase_orders_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
    <li class="nav-item">
      <a href="{$inventoryConfigUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">settings</span><span>{$inventoryTranslations.settings_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
    <li class="nav-item">
      <a href="{$inventoryHelpUrl|escape:'html':'UTF-8'}" class="router-link-active router-link-exact-active nav-link active" aria-current="page" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">help_outline</span><span>{$inventoryTranslations.help_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
  </ul>
</div>

<style>
.csmgr-help-page { max-width: 680px; margin: 0 auto; padding: 24px 0 48px; }
.csmgr-help-panel { background: #fff; border: 1px solid #e0e0e0; border-radius: 4px; padding: 28px 32px 32px; }
.csmgr-help-panel h2 { font-size: 1.15rem; font-weight: 600; margin: 0 0 24px; display: flex; align-items: center; gap: 8px; }
.csmgr-help-panel h2 .material-icons { font-size: 1.3rem; color: #6c757d; }
.csmgr-help-field { margin-bottom: 18px; }
.csmgr-help-field label { display: block; font-weight: 500; font-size: 0.85rem; margin-bottom: 5px; color: #333; }
.csmgr-help-field select,
.csmgr-help-field input[type="text"],
.csmgr-help-field input[type="email"],
.csmgr-help-field textarea { width: 100%; padding: 8px 11px; border: 1px solid #ccc; border-radius: 3px; font-size: 0.92rem; box-sizing: border-box; }
.csmgr-help-field textarea { min-height: 120px; resize: vertical; }
.csmgr-help-row { display: flex; gap: 16px; }
.csmgr-help-row .csmgr-help-field { flex: 1; }
.csmgr-help-actions { margin-top: 24px; display: flex; align-items: center; gap: 16px; }
.csmgr-help-alert { padding: 10px 16px; border-radius: 3px; font-size: 0.9rem; display: none; }
.csmgr-help-alert.is-success { display: block; background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
.csmgr-help-alert.is-error { display: block; background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
</style>

<div class="csmgr-help-page">
  <div class="csmgr-help-panel">
    <h2><span class="material-icons">help_outline</span>{$inventoryTranslations.help_form_title|escape:'html':'UTF-8'}</h2>

    <div id="csmgr-help-alert" class="csmgr-help-alert" role="alert"></div>

    <div class="csmgr-help-row">
      <div class="csmgr-help-field">
        <label for="csmgr-help-type">{$inventoryTranslations.help_form_type|escape:'html':'UTF-8'}</label>
        <select id="csmgr-help-type">
          <option value="Problem">{$inventoryTranslations.help_form_type_problem|escape:'html':'UTF-8'}</option>
          <option value="Sugestia">{$inventoryTranslations.help_form_type_suggestion|escape:'html':'UTF-8'}</option>
          <option value="Pytanie">{$inventoryTranslations.help_form_type_question|escape:'html':'UTF-8'}</option>
        </select>
      </div>
      <div class="csmgr-help-field">
        <label for="csmgr-help-email">{$inventoryTranslations.help_form_email|escape:'html':'UTF-8'}</label>
        <input type="email" id="csmgr-help-email" value="{$inventoryAdminEmail|escape:'html':'UTF-8'}" autocomplete="email">
      </div>
    </div>

    <div class="csmgr-help-field">
      <label for="csmgr-help-subject">{$inventoryTranslations.help_form_subject|escape:'html':'UTF-8'}</label>
      <input type="text" id="csmgr-help-subject">
    </div>

    <div class="csmgr-help-field">
      <label for="csmgr-help-message">{$inventoryTranslations.help_form_message|escape:'html':'UTF-8'}</label>
      <textarea id="csmgr-help-message"></textarea>
    </div>

    <div class="csmgr-help-actions">
      <button id="csmgr-help-submit" class="btn btn-primary">
        <span class="material-icons" style="font-size:1rem;vertical-align:middle;margin-right:4px">send</span>
        {$inventoryTranslations.help_form_submit|escape:'html':'UTF-8'}
      </button>
    </div>
  </div>
</div>

<script>
(function () {
  var ajaxUrl = {$inventoryAjaxUrl|json_encode};
  var submitBtn = document.getElementById('csmgr-help-submit');
  var alertEl  = document.getElementById('csmgr-help-alert');

  function showAlert(text, isError) {
    alertEl.textContent = text;
    alertEl.className = 'csmgr-help-alert ' + (isError ? 'is-error' : 'is-success');
    alertEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  submitBtn.addEventListener('click', function () {
    var type    = document.getElementById('csmgr-help-type').value;
    var email   = document.getElementById('csmgr-help-email').value.trim();
    var subject = document.getElementById('csmgr-help-subject').value.trim();
    var message = document.getElementById('csmgr-help-message').value.trim();

    alertEl.className = 'csmgr-help-alert';
    alertEl.textContent = '';

    if (!subject || !message) {
      showAlert('Temat i wiadomość są wymagane.', true);
      return;
    }

    submitBtn.disabled = true;

    $.post(ajaxUrl + '&action=SendSupportMessage', {
      ajax: 1,
      type: type,
      email: email,
      subject: subject,
      message: message
    }, function (resp) {
      if (resp && resp.ok) {
        showAlert('{$inventoryTranslations.help_form_success|escape:'javascript'}', false);
        document.getElementById('csmgr-help-subject').value = '';
        document.getElementById('csmgr-help-message').value = '';
      } else {
        showAlert((resp && resp.error) ? resp.error : '{$inventoryTranslations.help_form_error|escape:'javascript'}', true);
      }
    }, 'json').fail(function () {
      showAlert('{$inventoryTranslations.help_form_error|escape:'javascript'}', true);
    }).always(function () {
      submitBtn.disabled = false;
    });
  });
}());
</script>
</div>
