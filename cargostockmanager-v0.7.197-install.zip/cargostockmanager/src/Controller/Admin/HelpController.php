<?php
declare(strict_types=1);

namespace PrestaShop\Module\CargoStockManager\Controller\Admin;

require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerService.php';
require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerLicense.php';

use PrestaShopBundle\Security\Annotation\AdminSecurity;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class HelpController extends AbstractInventoryController
{
    /**
     * @AdminSecurity("is_granted('read', request.get('_legacy_controller'))")
     */
    public function indexAction(Request $request): Response
    {
        $module = \Module::getInstanceByName('cargostockmanager');
        $context = \Context::getContext();

        if ($module instanceof \CargoStockManager) {
            $module->ensureTabsAvailable();
        }

        $adminEmail = '';
        if ($context instanceof \Context && isset($context->employee) && $context->employee instanceof \Employee) {
            $adminEmail = (string) $context->employee->email;
        }

        $ajaxUrl = '';
        if ($context instanceof \Context && isset($context->link) && $context->link instanceof \Link) {
            $ajaxUrl = $context->link->getAdminLink('AdminCargoStockManager', true, [], ['ajax' => 1]);
        }

        return $this->renderInventoryPage(
            '@Modules/cargostockmanager/views/templates/admin-modern/help.html.twig',
            'cargo_stock_manager_help',
            'help_tab',
            [
                'adminEmail' => $adminEmail,
                'ajaxUrl' => $ajaxUrl,
            ]
        );
    }
}
