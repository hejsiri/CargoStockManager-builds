<?php
declare(strict_types=1);

namespace PrestaShop\Module\CargoStockManager\Controller\Admin;

require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerI18n.php';
require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerLicense.php';

use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Symfony\Contracts\Translation\TranslatorInterface;
use Twig\Markup;

abstract class AbstractInventoryController extends FrameworkBundleAdminController
{
    private TranslatorInterface $translator;

    public function __construct(TranslatorInterface $translator)
    {
        $this->translator = $translator;
    }

    protected function buildHeaderTabContent(string $currentRoute): array|string
    {
        $context = \Context::getContext();
        $module = \Module::getInstanceByName('cargostockmanager');
        $configUrl = '';

        if ($context instanceof \Context && isset($context->link) && $context->link instanceof \Link && $module instanceof \Module) {
            $configUrl = $context->link->getAdminLink('AdminCargoStockManagerSettings', true);
        }

        $tabsMarkup = $this->renderView('@Modules/cargostockmanager/views/templates/admin-modern/_head_tabs.html.twig', [
            'currentRoute' => $currentRoute,
            'inventoryTexts' => \CargoStockManagerI18n::all($this->translator),
            'inventoryModuleUrl' => $context instanceof \Context ? $context->link->getAdminLink('AdminCargoStockManager', true) : '',
            'inventoryConfigUrl' => $configUrl,
            'inventorySuppliersUrl' => $context instanceof \Context ? $context->link->getAdminLink('AdminCargoStockManagerSuppliers', true) : '',
            'inventoryPurchaseOrdersUrl' => $context instanceof \Context ? $context->link->getAdminLink('AdminCargoStockManagerPurchaseOrders', true) : '',
            'inventoryHelpUrl' => $context instanceof \Context ? $context->link->getAdminLink('AdminCargoStockManagerHelp', true) : '',
        ]);

        if (version_compare(_PS_VERSION_, '9.0.0', '>=')) {
            return [new Markup($tabsMarkup, 'UTF-8')];
        }

        return $tabsMarkup;
    }

    protected function translate(string $key, array $params = []): string
    {
        return \CargoStockManagerI18n::translate($this->translator, $key, $params);
    }

    protected function inventoryTexts(): array
    {
        return \CargoStockManagerI18n::all($this->translator);
    }

    protected function getModuleLicenseStatus(): array
    {
        $module = \Module::getInstanceByName('cargostockmanager');
        $context = \Context::getContext();

        if (!$module instanceof \Module || !$context instanceof \Context) {
            return [
                'valid' => false,
                'code' => 'context_missing',
                'message' => $this->translate('license_missing_message'),
                'details' => [],
            ];
        }

        $licenseService = new \CargoStockManagerLicense($module->getLocalPath(), $context, $module);

        return $licenseService->getStatus();
    }

    protected function isModuleLicenseValid(): bool
    {
        $status = $this->getModuleLicenseStatus();

        return (bool) ($status['valid'] ?? false);
    }

    protected function renderInventoryPage(string $template, string $currentRoute, string $sectionLabelKey, array $extra = [])
    {
        $module = \Module::getInstanceByName('cargostockmanager');
        $context = \Context::getContext();

        return $this->render($template, array_merge([
            'layoutTitle' => $this->translate('inventory_report'),
            'headerTabContent' => $this->buildHeaderTabContent($currentRoute),
            'inventoryCurrentSectionLabel' => $this->translate($sectionLabelKey),
            'inventoryReportLabel' => $this->translate('inventory_report'),
            'inventoryHomeUrl' => $context instanceof \Context ? $context->link->getAdminLink('AdminCargoStockManager', true) : '',
            'moduleVersion' => $module instanceof \Module ? (string) $module->version : '0.0.0',
            'inventoryTexts' => $this->inventoryTexts(),
            'licenseStatus' => $this->getModuleLicenseStatus(),
        ], $extra));
    }
}
