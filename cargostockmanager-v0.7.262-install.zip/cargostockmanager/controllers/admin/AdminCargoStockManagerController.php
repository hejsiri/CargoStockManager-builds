<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__DIR__, 2) . '/classes/CargoStockManagerService.php';
require_once dirname(__DIR__, 2) . '/classes/CargoStockManagerI18n.php';
require_once dirname(__DIR__, 2) . '/classes/CargoStockManagerLicense.php';
require_once dirname(__DIR__, 2) . '/classes/CargoStockManagerUpdater.php';

class AdminCargoStockManagerController extends ModuleAdminController
{
    private CargoStockManagerService $inventoryService;
    private CargoStockManagerLicense $licenseService;
    private CargoStockManagerUpdater $updaterService;

    public function __construct()
    {
        $this->bootstrap = true;

        parent::__construct();

        $this->inventoryService = new CargoStockManagerService($this->module->getLocalPath(), $this->context, $this->module);
        $this->licenseService = new CargoStockManagerLicense($this->module->getLocalPath(), $this->context, $this->module);
        $this->updaterService = new CargoStockManagerUpdater($this->module->getLocalPath(), $this->context, $this->module);
    }

    public function initContent(): void
    {
        $this->assertViewAccess();

        if ($this->shouldUseModernAdminNavigation() && !Tools::getIsset('ajax') && !Tools::getIsset('exportPdf') && !Tools::getIsset('downloadProductLabel')) {
            Tools::redirectAdmin($this->getModuleRouteUrl('cargo_stock_manager_products'));
        }

        if ($this->module instanceof CargoStockManager) {
            $this->module->ensureTabsAvailable();
        }

        $translations = $this->inventoryService->getTranslations();
        $licenseStatus = $this->licenseService->getStatus();
        $assetsVersion = $this->module instanceof CargoStockManager
            ? $this->module->getAssetVersion('views/js/chart.umd.min.js')
            : (string) $this->module->version;

        $this->context->smarty->assign([
            'inventoryCatalogUrl' => $this->context->link->getAdminLink('AdminProducts', true),
            'inventoryModuleUrl' => $this->context->link->getAdminLink('AdminCargoStockManager', true),
            'inventoryStatisticsUrl' => $this->context->link->getAdminLink('AdminCargoStockManagerStatistics', true),
            'inventorySuppliersUrl' => $this->context->link->getAdminLink('AdminCargoStockManagerSuppliers', true),
            'inventoryPurchaseOrdersUrl' => $this->context->link->getAdminLink('AdminCargoStockManagerPurchaseOrders', true),
            'inventoryModuleBaseUrl' => $this->module->getPathUri(),
            'inventoryAjaxUrl' => $this->context->link->getAdminLink('AdminCargoStockManager', true, [], [
                'ajax' => 1,
            ]),
            'inventoryExportUrl' => $this->context->link->getAdminLink('AdminCargoStockManager', true, [], [
                'exportPdf' => 1,
            ]),
            'inventoryConfigUrl' => $this->context->link->getAdminLink('AdminModules', true, [], [
                'configure' => $this->module->name,
                'module_name' => $this->module->name,
                'tab_module' => $this->module->tab,
            ]),
            'inventoryHelpUrl' => $this->context->link->getAdminLink('AdminCargoStockManagerHelp', true),
            'inventoryLanguageIso' => (string) $this->context->language->iso_code,
            'inventoryCanEdit' => $this->access('edit'),
            'inventoryTranslations' => $translations,
            'inventoryTranslationsJson' => json_encode($translations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'inventoryModuleVersion' => (string) $this->module->version,
            'inventoryAssetsVersion' => $assetsVersion,
            'inventoryLicenseStatus' => $licenseStatus,
            'inventoryUpdateConfigured' => $this->updaterService->isConfigured(),
            'inventoryUpdateChannel' => $this->updaterService->getConfiguredChannel(),
        ]);

        $this->content = $this->module->display(
            $this->module->getLocalPath() . $this->module->name . '.php',
            'views/templates/admin/app.tpl'
        );

        parent::initContent();
    }

    private function getModuleRouteUrl(string $routeName): string
    {
        $router = \PrestaShop\PrestaShop\Adapter\SymfonyContainer::getInstance()->get('router');

        return $router->generate($routeName);
    }

    private function shouldUseModernAdminNavigation(): bool
    {
        return version_compare(_PS_VERSION_, '9.0.0', '>=');
    }

    public function postProcess(): void
    {
        if (Tools::getIsset('downloadProductLabel')) {
            $this->assertViewAccess();
            $this->assertLicenseValid();
            $this->inventoryService->outputProductLabelPdf(
                (int) Tools::getValue('id_product', 0),
                (int) Tools::getValue('id_product_attribute', 0),
                (string) Tools::getValue('lang', (string) $this->context->language->iso_code)
            );
        }

        if (Tools::getIsset('exportPdf')) {
            $this->assertViewAccess();
            $this->assertLicenseValid();
            $this->inventoryService->outputPdfReport([
                'lang' => (string) Tools::getValue('lang', (string) $this->context->language->iso_code),
                'activeOnly' => (string) Tools::getValue('activeOnly', '0'),
                'onlyAvailable' => (string) Tools::getValue('onlyAvailable', '0'),
                'missingPurchasePriceOnly' => (string) Tools::getValue('missingPurchasePriceOnly', '0'),
                'missingWeightOnly' => (string) Tools::getValue('missingWeightOnly', '0'),
                'showWeight' => (string) Tools::getValue('showWeight', '1'),
                'showUnitVolume' => (string) Tools::getValue('showUnitVolume', '1'),
                'showUnitsPerCarton' => (string) Tools::getValue('showUnitsPerCarton', '1'),
                'showCartonDimensions' => (string) Tools::getValue('showCartonDimensions', '1'),
                'showCartonGrossWeight' => (string) Tools::getValue('showCartonGrossWeight', '1'),
                'showBrutto' => (string) Tools::getValue('showBrutto', '1'),
                'query' => (string) Tools::getValue('query', ''),
            ]);
        }

        parent::postProcess();
    }

    public function ajaxProcessFetchProducts(): void
    {
        header('Content-Type: application/json; charset=utf-8');

        try {
            $this->assertViewAccess();

            echo json_encode($this->inventoryService->renderProductsTable([
                'query' => (string) Tools::getValue('query', ''),
                'keywords' => Tools::getValue('keywords'),
                'activeOnly' => Tools::getValue('activeOnly'),
                'onlyAvailable' => Tools::getValue('onlyAvailable'),
                'missingPurchasePriceOnly' => Tools::getValue('missingPurchasePriceOnly'),
                'missingWeightOnly' => Tools::getValue('missingWeightOnly'),
                'showWeight' => Tools::getValue('showWeight', 1),
                'showUnitVolume' => Tools::getValue('showUnitVolume', 1),
                'showUnitsPerCarton' => Tools::getValue('showUnitsPerCarton', 1),
                'showCartonDimensions' => Tools::getValue('showCartonDimensions', 1),
                'showCartonGrossWeight' => Tools::getValue('showCartonGrossWeight', 1),
                'showMaterial' => Tools::getValue('showMaterial', 1),
                'showHsCode' => Tools::getValue('showHsCode', 1),
                'showCustomsDutyRate' => Tools::getValue('showCustomsDutyRate', 1),
                'showBrutto' => Tools::getValue('showBrutto', 1),
                'lang' => (string) Tools::getValue('lang', (string) $this->context->language->iso_code),
                'sort_field' => (string) Tools::getValue('sort_field', 'id_product'),
                'sort_dir' => (string) Tools::getValue('sort_dir', 'DESC'),
                'page' => (int) Tools::getValue('page', 1),
                'per_page' => (int) Tools::getValue('per_page', 20),
            ]));
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => _PS_MODE_DEV_
                    ? $e->getMessage()
                    : CargoStockManagerI18n::translate($this->module, 'load_error'),
            ]);
        }
        exit;
    }

    public function ajaxProcessSavePrice(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $price = $this->inventoryService->saveWholesalePrice(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('price', '')
            );

            echo json_encode([
                'ok' => true,
                'price' => $price,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => _PS_MODE_DEV_
                    ? CargoStockManagerI18n::translate($this->module, 'db_update_error') . ': ' . $e->getMessage()
                    : CargoStockManagerI18n::translate($this->module, 'db_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessSaveRetailPrice(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $price = $this->inventoryService->saveRetailGrossPrice(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('price', '')
            );

            echo json_encode([
                'ok' => true,
                'price' => $price,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => _PS_MODE_DEV_
                    ? CargoStockManagerI18n::translate($this->module, 'db_update_error') . ': ' . $e->getMessage()
                    : CargoStockManagerI18n::translate($this->module, 'db_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessToggleProductActive(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $isActive = $this->inventoryService->setProductActive(
                (int) Tools::getValue('id_product'),
                Tools::getValue('active')
            );

            echo json_encode([
                'ok' => true,
                'active' => $isActive ? 1 : 0,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessSaveQuantity(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $quantity = $this->inventoryService->saveQuantity(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('quantity', '')
            );

            echo json_encode([
                'ok' => true,
                'quantity' => $quantity,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'stock_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessSaveWeight(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $weight = $this->inventoryService->saveWeight(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('weight', '')
            );

            echo json_encode([
                'ok' => true,
                'weight' => $weight,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessSaveUnitVolume(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $volume = $this->inventoryService->saveUnitVolume(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('volume', '')
            );

            echo json_encode([
                'ok' => true,
                'volume' => $volume,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessSaveUnitsPerCarton(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $units = $this->inventoryService->saveUnitsPerCarton(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('units_per_carton', '')
            );

            echo json_encode([
                'ok' => true,
                'units_per_carton' => $units,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessSaveMaterial(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $value = $this->inventoryService->saveMaterial(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('material', '')
            );

            echo json_encode(['ok' => true, 'material' => $value]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode(['ok' => false, 'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error')]);
        }

        exit;
    }

    public function ajaxProcessSaveModuleModel(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $value = $this->inventoryService->saveModuleModel(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('module_model', '')
            );

            echo json_encode(['ok' => true, 'module_model' => $value]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode(['ok' => false, 'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error')]);
        }

        exit;
    }

    public function ajaxProcessSaveLogisticsDescription(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $value = $this->inventoryService->saveLogisticsDescription(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('description', '')
            );

            echo json_encode(['ok' => true, 'description' => $value]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode(['ok' => false, 'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error')]);
        }

        exit;
    }

    public function ajaxProcessSaveHsCode(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $value = $this->inventoryService->saveHsCode(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('hs_code', '')
            );

            echo json_encode(['ok' => true, 'hs_code' => $value]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode(['ok' => false, 'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error')]);
        }

        exit;
    }

    public function ajaxProcessSaveCustomsDutyRate(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $rate = $this->inventoryService->saveCustomsDutyRate(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('customs_duty_rate', '')
            );

            echo json_encode(['ok' => true, 'customs_duty_rate' => $rate]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode(['ok' => false, 'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error')]);
        }

        exit;
    }

    public function ajaxProcessSaveCartonDimensions(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $dimensions = $this->inventoryService->saveCartonDimensions(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('carton_dimensions', '')
            );

            echo json_encode([
                'ok' => true,
                'carton_dimensions' => $dimensions,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessSaveCartonGrossWeight(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $weight = $this->inventoryService->saveCartonGrossWeight(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (string) Tools::getValue('carton_gross_weight', '')
            );

            echo json_encode([
                'ok' => true,
                'carton_gross_weight' => $weight,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'db_update_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessGetSalesStats(): void
    {
        $this->assertViewAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $stats = $this->inventoryService->getMonthlySalesStats(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute'),
                (int) Tools::getValue('months', 12),
                (int) Tools::getValue('offset_months', 0)
            );

            echo json_encode([
                'ok' => true,
                'stats' => $stats,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'error_sales_stats'),
            ]);
        }

        exit;
    }

    public function ajaxProcessGetGlobalSalesStats(): void
    {
        $this->assertViewAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $stats = $this->inventoryService->getGlobalMonthlySalesStats(
                (int) Tools::getValue('months', 12),
                (int) Tools::getValue('offset_months', 0)
            );

            echo json_encode([
                'ok' => true,
                'stats' => $stats,
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'error_sales_stats'),
            ]);
        }

        exit;
    }

    public function ajaxProcessGetPurchasePriceHistory(): void
    {
        $this->assertViewAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $history = $this->inventoryService->getPurchasePriceHistory(
                (int) Tools::getValue('id_product'),
                (int) Tools::getValue('id_product_attribute')
            );

            echo json_encode([
                'ok' => true,
                'history' => $history,
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'error_sales_stats'),
            ]);
        }

        exit;
    }

    public function ajaxProcessHideProduct(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $result = $this->inventoryService->hideProduct(
                (int) Tools::getValue('id_product')
            );

            echo json_encode([
                'ok' => true,
                'id_product' => (int) $result['id_product'],
            ]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode([
                'ok' => false,
                'error' => $e->getMessage(),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'hide_product_error'),
            ]);
        }

        exit;
    }

    public function ajaxProcessFindProductByEan(): void
    {
        $this->assertViewAccess();
        $this->assertLicenseValid();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $ean = trim((string) Tools::getValue('ean', ''));
            $lang = (string) Tools::getValue('lang', '');

            if ($ean === '') {
                throw new InvalidArgumentException('Brak kodu EAN.');
            }

            $product = $this->inventoryService->findProductByEan($ean, $lang);
            if ($product === null) {
                echo json_encode(['ok' => false, 'not_found' => true]);
                exit;
            }

            echo json_encode(['ok' => true, 'product' => $product]);
        } catch (Throwable $e) {
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        }

        exit;
    }

    public function ajaxProcessCheckForUpdates(): void
    {
        $this->assertViewAccess();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $channel = trim((string) Tools::getValue('channel', ''));
            $status = $this->updaterService->checkForUpdates($channel !== '' ? $channel : null);
            echo json_encode([
                'ok' => true,
                'status' => $status,
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'update_check_error_message'),
            ]);
        }

        exit;
    }

    public function ajaxProcessInstallUpdate(): void
    {
        $this->assertEditAccess();

        header('Content-Type: application/json; charset=utf-8');

        try {
            $channel = trim((string) Tools::getValue('channel', ''));
            $result = $this->updaterService->installAvailableUpdate($channel !== '' ? $channel : null);
            echo json_encode([
                'ok' => true,
                'version' => (string) ($result['version'] ?? ''),
                'message' => CargoStockManagerI18n::translate($this->module, 'update_installed_message'),
            ]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'update_install_error_message'),
            ]);
        }

        exit;
    }

    public function ajaxProcessSaveCarrier(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();
        header('Content-Type: application/json; charset=utf-8');
        try {
            $result = $this->inventoryService->saveCarrier(
                (int) Tools::getValue('id', 0),
                (string) Tools::getValue('name', '')
            );
            echo json_encode(['ok' => true, 'carrier' => $result]);
        } catch (\Throwable $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }

    public function ajaxProcessDeleteCarrier(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();
        header('Content-Type: application/json; charset=utf-8');
        try {
            $this->inventoryService->deleteCarrier((int) Tools::getValue('id', 0));
            echo json_encode(['ok' => true]);
        } catch (\Throwable $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }

    public function ajaxProcessSaveDocumentType(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();
        header('Content-Type: application/json; charset=utf-8');
        try {
            $result = $this->inventoryService->saveDocumentType(
                (int) Tools::getValue('id', 0),
                (string) Tools::getValue('name', '')
            );
            echo json_encode(['ok' => true, 'document_type' => $result]);
        } catch (\Throwable $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }

    public function ajaxProcessDeleteDocumentType(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();
        header('Content-Type: application/json; charset=utf-8');
        try {
            $this->inventoryService->deleteDocumentType((int) Tools::getValue('id', 0));
            echo json_encode(['ok' => true]);
        } catch (\Throwable $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }

    public function ajaxProcessSaveOrderStatus(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();
        header('Content-Type: application/json; charset=utf-8');
        try {
            $key = (string) Tools::getValue('key', '');
            $label = (string) Tools::getValue('label', '');
            $color = (string) Tools::getValue('color', '#25B9D7');
            $menuBadgeEnabled = (string) Tools::getValue('menu_badge_enabled', '') === '1';

            if ($key === '' || $key === '0') {
                $status = $this->inventoryService->addOrderStatusEntry($label, $color, $menuBadgeEnabled);
            } else {
                $status = $this->inventoryService->saveOrderStatusEntry($key, $label, $color, $menuBadgeEnabled);
            }
            echo json_encode(['ok' => true, 'status' => $status]);
        } catch (\Throwable $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }

    public function ajaxProcessDeleteOrderStatus(): void
    {
        $this->assertEditAccess();
        $this->assertLicenseValid();
        header('Content-Type: application/json; charset=utf-8');
        try {
            $this->inventoryService->deleteOrderStatusEntry((string) Tools::getValue('key', ''));
            echo json_encode(['ok' => true]);
        } catch (\Throwable $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        }
        exit;
    }

    public function ajaxProcessSendSupportMessage(): void
    {
        header('Content-Type: application/json; charset=utf-8');

        try {
            $type    = trim((string) Tools::getValue('type', ''));
            $subject = trim((string) Tools::getValue('subject', ''));
            $message = trim((string) Tools::getValue('message', ''));
            $from    = trim((string) Tools::getValue('email', ''));

            if ($subject === '' || $message === '') {
                throw new InvalidArgumentException('Temat i wiadomość są wymagane.');
            }

            if ($from !== '' && !filter_var($from, FILTER_VALIDATE_EMAIL)) {
                throw new InvalidArgumentException('Nieprawidłowy adres e-mail.');
            }

            $version    = (string) $this->module->version;
            $shopName   = (string) Configuration::get('PS_SHOP_NAME');
            $shopDomain = (string) Tools::getShopDomain();
            $shopUrl    = 'https://' . $shopDomain;
            $psVersion  = (string) _PS_VERSION_;
            $phpVersion = PHP_VERSION;
            $sentAt     = date('Y-m-d H:i:s T');
            $employee   = $this->context->employee;
            $adminName  = $employee instanceof Employee
                ? trim($employee->firstname . ' ' . $employee->lastname)
                : '';

            $emailSubject = 'Cargo Stock Manager ' . $version . ' — ' . $type . ': ' . $subject;

            $he = static fn(string $s): string => htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
            $shopUrlClean  = rtrim($shopUrl, '/');
            $hVersion      = $he($version);
            $hType         = $he($type);
            $hSubject      = $he($subject);
            $hSentAt       = $he($sentAt);
            $hShopName     = $he($shopName);
            $hShopUrl      = $he($shopUrlClean);
            $hPsVersion    = $he($psVersion);
            $hPhpVersion   = $he($phpVersion);
            $messageHtml   = nl2br($he($message));

            $nameLine  = $adminName !== '' ? '<tr><td class="lbl">Imię i nazwisko</td><td>' . $he($adminName) . '</td></tr>' : '';
            $emailLine = $from !== ''      ? '<tr><td class="lbl">E-mail</td><td><a href="mailto:' . $he($from) . '">' . $he($from) . '</a></td></tr>' : '';

            $body = <<<HTML
<!DOCTYPE html>
<html lang="pl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cargo Stock Manager — Zgłoszenie</title>
</head>
<body style="margin:0;padding:0;background:#f4f4f4;font-family:Arial,Helvetica,sans-serif;font-size:14px;color:#333;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f4;padding:32px 0;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:6px;overflow:hidden;box-shadow:0 1px 4px rgba(0,0,0,.1);">

  <!-- HEADER -->
  <tr>
    <td style="background:#1a1a2e;padding:24px 32px;">
      <p style="margin:0;font-size:11px;letter-spacing:1.5px;text-transform:uppercase;color:#888;">Cargo Stock Manager $hVersion</p>
      <h1 style="margin:6px 0 0;font-size:20px;color:#ffffff;font-weight:600;">Nowe zgłoszenie</h1>
    </td>
  </tr>

  <!-- TYPE BADGE -->
  <tr>
    <td style="padding:20px 32px 0;">
      <span style="display:inline-block;background:#eef2ff;color:#3730a3;font-size:12px;font-weight:600;letter-spacing:.5px;padding:4px 12px;border-radius:20px;">$hType</span>
      <p style="margin:8px 0 0;font-size:18px;font-weight:600;color:#111;">$hSubject</p>
    </td>
  </tr>

  <!-- MESSAGE -->
  <tr>
    <td style="padding:16px 32px 24px;">
      <div style="background:#f8f9fa;border-left:3px solid #1a1a2e;border-radius:0 4px 4px 0;padding:16px 20px;font-size:14px;line-height:1.7;color:#333;">
        $messageHtml
      </div>
    </td>
  </tr>

  <!-- META -->
  <tr>
    <td style="padding:0 32px 28px;">
      <table width="100%" cellpadding="0" cellspacing="0" style="border-top:1px solid #eee;padding-top:20px;">
        <tr><td colspan="2" style="padding-bottom:10px;font-size:11px;letter-spacing:1px;text-transform:uppercase;color:#aaa;font-weight:600;">Nadawca</td></tr>
        $nameLine
        $emailLine
        <tr><td style="color:#888;font-size:12px;padding:5px 16px 5px 0;white-space:nowrap;vertical-align:top;">Data wysłania</td><td style="padding:5px 0;font-size:13px;">$hSentAt</td></tr>
        <tr><td colspan="2" style="padding:16px 0 10px;font-size:11px;letter-spacing:1px;text-transform:uppercase;color:#aaa;font-weight:600;">Środowisko</td></tr>
        <tr><td style="color:#888;font-size:12px;padding:5px 16px 5px 0;white-space:nowrap;vertical-align:top;">Sklep</td><td style="padding:5px 0;font-size:13px;">$hShopName &mdash; <a href="$hShopUrl" style="color:#3730a3;">$hShopUrl</a></td></tr>
        <tr><td style="color:#888;font-size:12px;padding:5px 16px 5px 0;white-space:nowrap;vertical-align:top;">PrestaShop</td><td style="padding:5px 0;font-size:13px;">$hPsVersion</td></tr>
        <tr><td style="color:#888;font-size:12px;padding:5px 16px 5px 0;white-space:nowrap;vertical-align:top;">PHP</td><td style="padding:5px 0;font-size:13px;">$hPhpVersion</td></tr>
      </table>
    </td>
  </tr>

  <!-- FOOTER -->
  <tr>
    <td style="background:#f8f9fa;border-top:1px solid #eee;padding:14px 32px;font-size:11px;color:#aaa;">
      Cargo Stock Manager $hVersion &bull; Wiadomość wysłana automatycznie z panelu modułu
    </td>
  </tr>

</table>
</td></tr>
</table>
</body>
</html>
HTML;

            $headers  = "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
            $headers .= "X-Mailer: CargoStockManager/" . $version . "\r\n";
            if ($from !== '') {
                $headers .= "From: " . ($adminName !== '' ? $adminName . ' <' . $from . '>' : $from) . "\r\n";
                $headers .= "Reply-To: " . $from . "\r\n";
            }

            $sent = @mail('pawel@tucki.pl', $emailSubject, $body, $headers);
            if (!$sent) {
                throw new RuntimeException('mail() failed');
            }

            echo json_encode(['ok' => true]);
        } catch (InvalidArgumentException $e) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
        } catch (Throwable $e) {
            http_response_code(500);
            echo json_encode(['ok' => false, 'error' => 'Nie udało się wysłać wiadomości.']);
        }

        exit;
    }

    private function assertViewAccess(): void
    {
        if (!$this->access('view')) {
            throw new PrestaShopException(CargoStockManagerI18n::translate($this->module, 'access_denied'));
        }
    }

    private function assertEditAccess(): void
    {
        if (!$this->access('edit')) {
            http_response_code(403);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'ok' => false,
                'error' => CargoStockManagerI18n::translate($this->module, 'access_denied'),
            ]);
            exit;
        }
    }

    private function assertLicenseValid(): void
    {
        $status = $this->licenseService->getStatus();
        if (!empty($status['valid'])) {
            return;
        }

        http_response_code(403);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode([
            'ok' => false,
            'error' => (string) ($status['message'] ?? CargoStockManagerI18n::translate($this->module, 'license_missing_message')),
        ]);
        exit;
    }
}
