#!/usr/bin/env php
<?php

declare(strict_types=1);

if (!defined('_PS_VERSION_')) {
    exit;
}

if (PHP_SAPI !== 'cli') {
    fwrite(STDERR, "This script must be run from CLI.\n");
    exit(1);
}

$options = getopt('', [
    'execute',
    'replace-target',
    'root-dir::',
    'source-table-prefix::',
    'source-config-prefix::',
    'old-module-name::',
    'new-module-name::',
    'help',
]);

if (isset($options['help'])) {
    echo <<<'TXT'
Usage:
  php scripts/migrate_06_to_07.php [--execute] [--replace-target] [--root-dir=/path/to/prestashop]
                                    [--source-table-prefix=prestashopinventory]
                                    [--source-config-prefix=PSINV]
                                    [--old-module-name=prestashopinventory]
                                    [--new-module-name=cargostockmanager]

Default mode is dry-run.

Recommended real migration:
  php scripts/migrate_06_to_07.php --root-dir=/var/www/html --execute --replace-target

What it migrates:
- suppliers
- carriers
- document types
- purchase orders
- purchase order items
- purchase order files
- purchase order notes
- product logistics data
- ignored products / delivery address / order statuses configuration
- purchase order uploaded files from old module uploads directory
TXT;
    exit(0);
}

function out(string $message): void
{
    fwrite(STDOUT, $message . PHP_EOL);
}

function err(string $message): void
{
    fwrite(STDERR, $message . PHP_EOL);
}

function locatePrestashopRoot(?string $explicitRoot): string
{
    if (is_string($explicitRoot) && trim($explicitRoot) !== '') {
        $resolved = realpath($explicitRoot);
        if ($resolved === false) {
            throw new RuntimeException('Provided --root-dir does not exist: ' . $explicitRoot);
        }
        if (!is_file($resolved . '/config/config.inc.php')) {
            throw new RuntimeException('Provided --root-dir is not a PrestaShop root: ' . $resolved);
        }

        return $resolved;
    }

    $dir = __DIR__;
    for ($i = 0; $i < 8; $i++) {
        if (is_file($dir . '/config/config.inc.php')) {
            return $dir;
        }
        $parent = dirname($dir);
        if ($parent === $dir) {
            break;
        }
        $dir = $parent;
    }

    throw new RuntimeException('Could not locate PrestaShop root automatically. Use --root-dir=/path/to/shop');
}

function pdo(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $pdo = new PDO(
        'mysql:host=' . _DB_SERVER_ . ';dbname=' . _DB_NAME_ . ';charset=utf8mb4',
        _DB_USER_,
        _DB_PASSWD_,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );

    return $pdo;
}

function tableExists(PDO $pdo, string $table): bool
{
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = :table');
    $stmt->execute([':table' => $table]);

    return (int) $stmt->fetchColumn() > 0;
}

function tableCount(PDO $pdo, string $table): int
{
    return (int) $pdo->query('SELECT COUNT(*) FROM `' . str_replace('`', '``', $table) . '`')->fetchColumn();
}

function tableColumns(PDO $pdo, string $table): array
{
    $rows = $pdo->query('SHOW COLUMNS FROM `' . str_replace('`', '``', $table) . '`')->fetchAll();

    return array_values(array_map(static function (array $row): string {
        return (string) ($row['Field'] ?? '');
    }, $rows));
}

function copyTable(PDO $pdo, string $sourceTable, string $targetTable): int
{
    $sourceColumns = tableColumns($pdo, $sourceTable);
    $targetColumns = tableColumns($pdo, $targetTable);
    $copyColumns = array_values(array_intersect($targetColumns, $sourceColumns));

    if ($copyColumns === []) {
        throw new RuntimeException(sprintf('No common columns between %s and %s', $sourceTable, $targetTable));
    }

    $quoted = array_map(static function (string $column): string {
        return '`' . str_replace('`', '``', $column) . '`';
    }, $copyColumns);

    $sql = sprintf(
        'INSERT INTO `%s` (%s) SELECT %s FROM `%s`',
        str_replace('`', '``', $targetTable),
        implode(', ', $quoted),
        implode(', ', $quoted),
        str_replace('`', '``', $sourceTable)
    );

    return $pdo->exec($sql) ?: 0;
}

function truncateTables(PDO $pdo, array $tables): void
{
    foreach ($tables as $table) {
        if (!tableExists($pdo, $table)) {
            continue;
        }
        $pdo->exec('TRUNCATE TABLE `' . str_replace('`', '``', $table) . '`');
    }
}

function recursiveCopy(string $sourceDir, string $targetDir): int
{
    if (!is_dir($sourceDir)) {
        return 0;
    }

    if (!is_dir($targetDir) && !mkdir($targetDir, 0775, true) && !is_dir($targetDir)) {
        throw new RuntimeException('Could not create directory: ' . $targetDir);
    }

    $copied = 0;
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($sourceDir, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($iterator as $item) {
        $targetPath = $targetDir . '/' . $iterator->getSubPathName();
        if ($item->isDir()) {
            if (!is_dir($targetPath) && !mkdir($targetPath, 0775, true) && !is_dir($targetPath)) {
                throw new RuntimeException('Could not create directory: ' . $targetPath);
            }
            continue;
        }

        $sourcePath = $item->getPathname();
        $targetParent = dirname($targetPath);
        if (!is_dir($targetParent) && !mkdir($targetParent, 0775, true) && !is_dir($targetParent)) {
            throw new RuntimeException('Could not create directory: ' . $targetParent);
        }

        if (!copy($sourcePath, $targetPath)) {
            throw new RuntimeException('Could not copy file: ' . $sourcePath . ' -> ' . $targetPath);
        }
        $copied++;
    }

    return $copied;
}

function fetchConfigurationValue(PDO $pdo, string $key): ?string
{
    $stmt = $pdo->prepare('SELECT value FROM `' . _DB_PREFIX_ . 'configuration` WHERE name = :name ORDER BY id_configuration DESC LIMIT 1');
    $stmt->execute([':name' => $key]);
    $value = $stmt->fetchColumn();

    return $value === false ? null : (string) $value;
}

function detectSourceTablePrefix(PDO $pdo, string $dbPrefix, ?string $explicitPrefix): string
{
    $candidates = [];
    if (is_string($explicitPrefix) && trim($explicitPrefix) !== '') {
        $candidates[] = trim($explicitPrefix);
    }
    $candidates[] = 'prestashopinventory';
    $candidates[] = 'cargostockmanager';
    $candidates = array_values(array_unique($candidates));

    foreach ($candidates as $candidate) {
        if ($candidate === 'cargostockmanager') {
            continue;
        }
        if (tableExists($pdo, $dbPrefix . $candidate . '_purchase_order')) {
            return $candidate;
        }
        if (tableExists($pdo, $dbPrefix . $candidate . '_supplier')) {
            return $candidate;
        }
    }

    if (is_string($explicitPrefix) && trim($explicitPrefix) !== '') {
        return trim($explicitPrefix);
    }

    return 'prestashopinventory';
}

$dryRun = !isset($options['execute']);
$replaceTarget = isset($options['replace-target']);
$oldModuleName = trim((string) ($options['old-module-name'] ?? 'prestashopinventory'));
$newModuleName = trim((string) ($options['new-module-name'] ?? 'cargostockmanager'));
$targetConfigPrefix = 'CSMGR';
$sourceConfigPrefix = trim((string) ($options['source-config-prefix'] ?? 'PSINV'));
$targetTablePrefix = 'cargostockmanager';

try {
    $prestashopRoot = locatePrestashopRoot($options['root-dir'] ?? null);
    require_once $prestashopRoot . '/config/config.inc.php';
    require_once $prestashopRoot . '/modules/' . $newModuleName . '/' . $newModuleName . '.php';
    require_once $prestashopRoot . '/modules/' . $newModuleName . '/classes/CargoStockManagerService.php';

    $context = $GLOBALS['context'] ?? null;
    $module = Module::getInstanceByName($newModuleName);
    if (!is_object($context)) {
        throw new RuntimeException('Could not initialize PrestaShop context.');
    }

    if (!$module instanceof Module) {
        $module = new cargostockmanager();
    }
    if (!$module instanceof Module) {
        throw new RuntimeException('Could not initialize target module: ' . $newModuleName);
    }

    $service = new CargoStockManagerService($module->getLocalPath(), $context, $module);
    $service->ensurePurchaseOrderInfrastructure();

    $pdo = pdo();
    $sourceTablePrefix = detectSourceTablePrefix($pdo, _DB_PREFIX_, $options['source-table-prefix'] ?? null);

    $tableSuffixes = [
        'carrier',
        'document_type',
        'supplier',
        'purchase_order',
        'purchase_order_item',
        'purchase_order_file',
        'purchase_order_note',
        'product_logistics',
    ];

    $sourceTables = [];
    $targetTables = [];
    foreach ($tableSuffixes as $suffix) {
        $sourceTables[$suffix] = _DB_PREFIX_ . $sourceTablePrefix . '_' . $suffix;
        $targetTables[$suffix] = _DB_PREFIX_ . $targetTablePrefix . '_' . $suffix;
    }

    out('PrestaShop root: ' . $prestashopRoot);
    out('Target module: ' . $newModuleName);
    out('Mode: ' . ($dryRun ? 'DRY-RUN' : 'EXECUTE'));
    out('Source table prefix: ' . $sourceTablePrefix);
    out('Source config prefix: ' . $sourceConfigPrefix);
    out('Replace target data: ' . ($replaceTarget ? 'yes' : 'no'));
    out('');

    $existingSourceTables = [];
    foreach ($sourceTables as $suffix => $table) {
        if (tableExists($pdo, $table)) {
            $existingSourceTables[$suffix] = $table;
        }
    }

    if ($existingSourceTables === []) {
        throw new RuntimeException('Could not find any source tables for prefix: ' . $sourceTablePrefix);
    }

    out('Table summary:');
    foreach ($tableSuffixes as $suffix) {
        $sourceTable = $sourceTables[$suffix];
        $targetTable = $targetTables[$suffix];
        $sourceExists = tableExists($pdo, $sourceTable);
        $targetExists = tableExists($pdo, $targetTable);
        $sourceCount = $sourceExists ? tableCount($pdo, $sourceTable) : 0;
        $targetCount = $targetExists ? tableCount($pdo, $targetTable) : 0;
        out(sprintf('- %-20s source=%-5s rows=%-6d target=%-5s rows=%-6d', $suffix, $sourceExists ? 'yes' : 'no', $sourceCount, $targetExists ? 'yes' : 'no', $targetCount));
    }
    out('');

    $configMap = [
        $sourceConfigPrefix . '_IGNORED_PRODUCT_IDS' => CargoStockManagerService::CONFIG_IGNORED_IDS,
        $sourceConfigPrefix . '_PURCHASE_DELIVERY_ADDRESS' => CargoStockManagerService::CONFIG_PURCHASE_DELIVERY_ADDRESS,
        $sourceConfigPrefix . '_PURCHASE_ORDER_STATUSES' => CargoStockManagerService::CONFIG_PURCHASE_ORDER_STATUSES,
    ];

    out('Configuration summary:');
    foreach ($configMap as $sourceKey => $targetKey) {
        $sourceValue = fetchConfigurationValue($pdo, $sourceKey);
        $targetValue = fetchConfigurationValue($pdo, $targetKey);
        out(sprintf('- %-36s => %-36s source=%s target=%s', $sourceKey, $targetKey, $sourceValue !== null ? 'yes' : 'no', $targetValue !== null ? 'yes' : 'no'));
    }
    out('');

    if ($dryRun) {
        out('Dry-run finished. No data changed.');
        out('Run again with --execute to perform migration.');
        exit(0);
    }

    $nonEmptyTargets = [];
    foreach ($tableSuffixes as $suffix) {
        $targetTable = $targetTables[$suffix];
        if (tableExists($pdo, $targetTable) && tableCount($pdo, $targetTable) > 0) {
            $nonEmptyTargets[] = $suffix;
        }
    }

    if ($nonEmptyTargets !== [] && !$replaceTarget) {
        throw new RuntimeException('Target tables already contain data: ' . implode(', ', $nonEmptyTargets) . '. Re-run with --replace-target if you want to replace demo / current data.');
    }

    $pdo->beginTransaction();

    if ($replaceTarget) {
        out('Truncating target tables...');
        truncateTables($pdo, [
            $targetTables['purchase_order_file'],
            $targetTables['purchase_order_note'],
            $targetTables['purchase_order_item'],
            $targetTables['purchase_order'],
            $targetTables['supplier'],
            $targetTables['carrier'],
            $targetTables['document_type'],
            $targetTables['product_logistics'],
        ]);
    }

    out('Copying tables...');
    $copiedRows = [];
    foreach ($tableSuffixes as $suffix) {
        $sourceTable = $sourceTables[$suffix];
        $targetTable = $targetTables[$suffix];
        if (!tableExists($pdo, $sourceTable) || !tableExists($pdo, $targetTable)) {
            $copiedRows[$suffix] = 0;
            continue;
        }
        $copiedRows[$suffix] = copyTable($pdo, $sourceTable, $targetTable);
        out(sprintf('- %s: copied %d rows', $suffix, $copiedRows[$suffix]));
    }

    out('Migrating configuration...');
    foreach ($configMap as $sourceKey => $targetKey) {
        $sourceValue = fetchConfigurationValue($pdo, $sourceKey);
        if ($sourceValue === null) {
            out(sprintf('- %s: skipped (missing)', $sourceKey));
            continue;
        }
        Configuration::updateValue($targetKey, $sourceValue);
        out(sprintf('- %s -> %s', $sourceKey, $targetKey));
    }

    if (tableExists($pdo, $targetTables['purchase_order_file'])) {
        $stmt = $pdo->prepare(
            'UPDATE `' . $targetTables['purchase_order_file'] . '`
             SET file_path = REPLACE(
                 REPLACE(file_path, :oldModuleWithSlash, :newModuleWithSlash),
                 :oldModuleNoSlash,
                 :newModuleNoSlash
             )
             WHERE file_path LIKE :needleWithSlash
                OR file_path LIKE :needleNoSlash'
        );
        $stmt->execute([
            ':oldModuleWithSlash' => '/modules/' . $oldModuleName . '/',
            ':newModuleWithSlash' => '/modules/' . $newModuleName . '/',
            ':oldModuleNoSlash' => 'modules/' . $oldModuleName . '/',
            ':newModuleNoSlash' => 'modules/' . $newModuleName . '/',
            ':needleWithSlash' => '%/modules/' . $oldModuleName . '/%',
            ':needleNoSlash' => '%modules/' . $oldModuleName . '/%',
        ]);
        out('- purchase_order_file.file_path rewritten to new module path');
    }

    $oldUploadsDir = $prestashopRoot . '/modules/' . $oldModuleName . '/uploads/purchase_orders';
    $newUploadsDir = $prestashopRoot . '/modules/' . $newModuleName . '/uploads/purchase_orders';
    $copiedFiles = recursiveCopy($oldUploadsDir, $newUploadsDir);
    out('- copied upload files: ' . $copiedFiles);

    $pdo->commit();

    out('');
    out('Migration finished successfully.');
    out('Recommended next step: open CargoStock Manager and verify suppliers, orders, files and product logistics.');
} catch (Throwable $e) {
    try {
        $pdo = pdo();
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
    } catch (Throwable $rollbackError) {
        // ignore rollback failures
    }

    err('Migration failed: ' . $e->getMessage());
    exit(1);
}
