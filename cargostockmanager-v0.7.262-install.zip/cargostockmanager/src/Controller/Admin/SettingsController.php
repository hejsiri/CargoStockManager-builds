<?php
declare(strict_types=1);

namespace PrestaShop\Module\CargoStockManager\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerService.php';
require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerLicense.php';
require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerUpdater.php';
require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerBackup.php';

if (!class_exists('PrestaShopBundle\\Security\\Attribute\\AdminSecurity')) {
    $legacySecurityClass = 'PrestaShopBundle\\Security\\Annotation\\Admin' . 'Security';
    if (class_exists($legacySecurityClass)) {
        class_alias($legacySecurityClass, 'PrestaShopBundle\\Security\\Attribute\\AdminSecurity');
    }
}

use PrestaShopBundle\Security\Attribute\AdminSecurity;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;

class SettingsController extends AbstractInventoryController
{
    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function indexAction(Request $request): Response
    {
        $module = \Module::getInstanceByName('cargostockmanager');
        $context = $this->getLegacyContext();
        $service = new \CargoStockManagerService($module->getLocalPath(), $context, $module);
        $updaterService = new \CargoStockManagerUpdater($module->getLocalPath(), $context, $module);
        $backupService = new \CargoStockManagerBackup($module->getLocalPath(), $context, $module);
        $messages = [];
        $errors = [];
        $uploadedBackupFile = [];

        if ($request->isMethod('POST') && \Tools::isSubmit('submitCargoStockManagerImportBackup')) {
            $uploadedBackupFile = $_FILES['cargoStockManagerBackupFile'] ?? [];
            unset($_FILES['cargoStockManagerBackupFile']);
            if (isset($GLOBALS['HTTP_POST_FILES']['cargoStockManagerBackupFile'])) {
                unset($GLOBALS['HTTP_POST_FILES']['cargoStockManagerBackupFile']);
            }
        }

        if ($module instanceof \CargoStockManager) {
            $module->ensureTabsAvailable();
        }

        $licenseStatus = $this->getModuleLicenseStatus();

        if (($licenseStatus['valid'] ?? false) && $request->isMethod('GET') && $request->query->has('downloadBackup')) {
            try {
                $filename = (string) $request->query->get('downloadBackup', '');
                $path = $backupService->getBackupPath($filename);
                $response = new BinaryFileResponse($path);
                $response->setContentDisposition(ResponseHeaderBag::DISPOSITION_ATTACHMENT, basename($path));

                return $response;
            } catch (\Throwable $e) {
                $errors[] = 'Nie udało się pobrać kopii zapasowej.';
                if (\defined('_PS_MODE_DEV_') && _PS_MODE_DEV_) {
                    $errors[] = $e->getMessage();
                }
            }
        }

        if (!($licenseStatus['valid'] ?? false) && $request->isMethod('POST')) {
            $errors[] = (string) ($licenseStatus['message'] ?? $this->translate('license_missing_message'));
        }

        if (($licenseStatus['valid'] ?? false) && $request->isMethod('POST') && \Tools::isSubmit('submitCargoStockManagerCreateBackup')) {
            try {
                $filename = $backupService->createBackup();
                $messages[] = 'Kopia zapasowa została utworzona: ' . $filename;
            } catch (\Throwable $e) {
                $errors[] = 'Nie udało się utworzyć kopii zapasowej.';
                if (\defined('_PS_MODE_DEV_') && _PS_MODE_DEV_) {
                    $errors[] = $e->getMessage();
                }
            }
        }

        if (($licenseStatus['valid'] ?? false) && $request->isMethod('POST') && \Tools::isSubmit('submitCargoStockManagerRestoreBackup')) {
            try {
                $backupService->restoreBackup((string) \Tools::getValue('backup_filename', ''));
                $messages[] = 'Dane modułu zostały przywrócone z kopii zapasowej.';
            } catch (\Throwable $e) {
                $errors[] = 'Nie udało się przywrócić kopii zapasowej.';
                if (\defined('_PS_MODE_DEV_') && _PS_MODE_DEV_) {
                    $errors[] = $e->getMessage();
                }
            }
        }

        if (($licenseStatus['valid'] ?? false) && $request->isMethod('POST') && \Tools::isSubmit('submitCargoStockManagerDeleteBackup')) {
            try {
                $backupService->deleteBackup((string) \Tools::getValue('backup_filename', ''));
                $messages[] = 'Kopia zapasowa została usunięta.';
            } catch (\Throwable $e) {
                $errors[] = 'Nie udało się usunąć kopii zapasowej.';
                if (\defined('_PS_MODE_DEV_') && _PS_MODE_DEV_) {
                    $errors[] = $e->getMessage();
                }
            }
        }

        if (($licenseStatus['valid'] ?? false) && $request->isMethod('POST') && \Tools::isSubmit('submitCargoStockManagerImportBackup')) {
            try {
                $filename = $backupService->importUploadedBackup($uploadedBackupFile);
                $messages[] = 'Wgrana kopia zapasowa została przywrócona: ' . $filename;
            } catch (\Throwable $e) {
                $errors[] = 'Nie udało się wgrać albo przywrócić kopii zapasowej.';
                if (\defined('_PS_MODE_DEV_') && _PS_MODE_DEV_) {
                    $errors[] = $e->getMessage();
                }
            }
        }

        if (($licenseStatus['valid'] ?? false) && $request->isMethod('POST') && \Tools::isSubmit('submitCargoStockManagerRestoreHidden')) {
            try {
                $service->unhideProduct((int) \Tools::getValue('id_product'));
                $messages[] = $this->translate('product_restored');
            } catch (\Throwable $e) {
                $errors[] = $this->translate('product_restore_error');
                if (\defined('_PS_MODE_DEV_') && _PS_MODE_DEV_) {
                    $errors[] = $e->getMessage();
                }
            }
        }

        if (($licenseStatus['valid'] ?? false) && $request->isMethod('POST') && \Tools::isSubmit('submitCargoStockManagerSaveOrderSettings')) {
            try {
                $postedStatuses = \Tools::getValue('cargoStockManagerOrderStatuses', null);
                $service->savePurchaseOrderSettings(
                    (string) \Tools::getValue('cargoStockManagerDeliveryAddress', ''),
                    (string) \Tools::getValue('cargoStockManagerAccountingEmail', ''),
                    is_array($postedStatuses) ? $postedStatuses : null
                );
                $messages[] = 'Ustawienia zamówień zostały zapisane.';
            } catch (\Throwable $e) {
                $errors[] = 'Nie udało się zapisać ustawień zamówień.';
                if (\defined('_PS_MODE_DEV_') && _PS_MODE_DEV_) {
                    $errors[] = $e->getMessage();
                }
            }
        }

        if (($licenseStatus['valid'] ?? false) && $request->isMethod('POST') && \Tools::isSubmit('submitCargoStockManagerSaveUpdateSettings')) {
            try {
                $updaterService->saveConfiguredChannel((string) \Tools::getValue('cargoStockManagerUpdateChannel', \CargoStockManagerUpdater::UPDATE_CHANNEL_PUBLIC));
                $messages[] = 'Ustawienia aktualizacji zostały zapisane.';
            } catch (\Throwable $e) {
                $errors[] = 'Nie udało się zapisać ustawień aktualizacji.';
                if (\defined('_PS_MODE_DEV_') && _PS_MODE_DEV_) {
                    $errors[] = $e->getMessage();
                }
            }
        }

        $licenseDetails = is_array($licenseStatus['details'] ?? null) ? $licenseStatus['details'] : [];
        $licensePayload = is_array($licenseDetails['payload'] ?? null) ? $licenseDetails['payload'] : [];
        $licenseCustomer = trim((string) ($licensePayload['customer'] ?? ''));
        $licenseDomain = trim((string) ($licenseDetails['domain'] ?? $licensePayload['domain'] ?? ''));
        $licenseExpiresAt = trim((string) ($licenseDetails['expires_at'] ?? $licensePayload['expires_at'] ?? ''));

        return $this->renderInventoryPage(
            '@Modules/cargostockmanager/views/templates/admin-modern/settings.html.twig',
            'cargo_stock_manager_settings',
            'settings_tab',
            [
                'settingsUrl' => $this->generateUrl('cargo_stock_manager_settings'),
                'ignoredProducts' => $service->getIgnoredProducts(),
                'moduleVersionValue' => (string) $module->version,
                'updateChannel' => $updaterService->getConfiguredChannel(),
                'licenseStatus' => $licenseStatus,
                'licenseSummary' => [
                    'customer' => $licenseCustomer !== '' ? $licenseCustomer : '—',
                    'domain' => $licenseDomain !== '' ? $licenseDomain : '—',
                    'expires_at' => $licenseExpiresAt !== '' ? $licenseExpiresAt : '—',
                ],
                'backups' => $backupService->listBackups(),
                'messages' => $messages,
                'errors' => $errors,
                'deliveryAddress' => $service->getConfiguredDeliveryAddress(),
                'accountingEmail' => $service->getConfiguredAccountingEmail(),
                'orderStatuses' => $service->getConfiguredPurchaseOrderStatuses(),
                'carriers' => $service->getCarriers(),
                'documentTypes' => $service->getDocumentTypes(),
                'incotermOptions' => $service->getPurchaseOrderIncotermOptions(),
                'ajaxUrl' => $context->link->getAdminLink('AdminCargoStockManagerProducts', true, [], ['ajax' => 1]),
            ]
        );
    }
}
