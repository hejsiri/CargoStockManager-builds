<?php
declare(strict_types=1);

namespace PrestaShop\Module\CargoStockManager\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerService.php';

if (!class_exists('PrestaShopBundle\\Security\\Attribute\\AdminSecurity')) {
    $legacySecurityClass = 'PrestaShopBundle\\Security\\Annotation\\Admin' . 'Security';
    if (class_exists($legacySecurityClass)) {
        class_alias($legacySecurityClass, 'PrestaShopBundle\\Security\\Attribute\\AdminSecurity');
    }
}

use PrestaShopBundle\Security\Attribute\AdminSecurity;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;

class PurchaseOrdersController extends AbstractInventoryController
{
    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function indexAction(Request $request): Response
    {
        $module = \Module::getInstanceByName('cargostockmanager');
        $context = $this->getLegacyContext();
        $purchaseOrders = [];
        $purchaseOrdersPageData = [];
        $selectedOrder = null;
        $messages = [];
        $errors = [];
        $purchaseOrderQuery = trim((string) $request->query->get('query', ''));
        $purchaseOrderPage = max(1, (int) $request->query->get('page', 1));
        $purchaseOrderPerPage = (int) $request->query->get('per_page', 20);
        $purchaseOrderProductId = max(0, (int) $request->query->get('id_product', 0));
        $purchaseOrderProductAttributeId = max(0, (int) $request->query->get('id_product_attribute', 0));
        $purchaseOrderFilters = [
            'id_product' => $purchaseOrderProductId,
            'id_product_attribute' => $purchaseOrderProductAttributeId,
        ];

        $licenseStatus = $this->getModuleLicenseStatus();

        if ($request->isMethod('GET') && $request->query->has('view')) {
            $redirectParams = [];
            $selectedOrderId = (int) $request->query->get('id_purchase_order', 0);
            if ($selectedOrderId > 0) {
                $redirectParams['id_purchase_order'] = $selectedOrderId;
            }

            $status = (string) $request->query->get('purchase_order_status', '');
            if ($status !== '') {
                $redirectParams['purchase_order_status'] = $status;
            }

            return $this->redirectToRoute('cargo_stock_manager_purchase_orders', $redirectParams);
        }

        if ($module instanceof \Module) {
            if ($module instanceof \CargoStockManager) {
                $module->ensureTabsAvailable();
            }

            $service = new \CargoStockManagerService($module->getLocalPath(), $context, $module);

            if ($licenseStatus['valid'] ?? false) {
                $service->ensurePurchaseOrderInfrastructure();
            }

            if (!($licenseStatus['valid'] ?? false)) {
                return $this->renderInventoryPage(
                    '@Modules/cargostockmanager/views/templates/admin-modern/purchase_orders.html.twig',
                    'cargo_stock_manager_purchase_orders',
                    'purchase_orders_tab',
                    [
                        'purchaseOrders' => [],
                        'selectedOrder' => null,
                        'purchaseOrderMessages' => $messages,
                        'purchaseOrderErrors' => $errors,
                        'purchaseOrdersUrl' => $this->generateUrl('cargo_stock_manager_purchase_orders'),
                        'purchaseOrdersListUrl' => $this->generateUrl('cargo_stock_manager_purchase_orders'),
                        'purchaseOrderQuery' => $purchaseOrderQuery,
                        'purchaseOrdersPagination' => '',
                        'purchaseOrderPage' => $purchaseOrderPage,
                        'purchaseOrderPerPage' => $purchaseOrderPerPage,
                        'purchaseOrderProductId' => $purchaseOrderProductId,
                        'purchaseOrderProductAttributeId' => $purchaseOrderProductAttributeId,
                        'licenseStatus' => $licenseStatus,
                        'accountingEmail' => '',
                    ]
                );
            }

            if ($request->isMethod('GET') && $request->query->has('exportOrderPdf')) {
                $orderId = (int) $request->query->get('id_purchase_order', 0);
                if ($orderId > 0) {
                    $service->outputPurchaseOrderPdf($orderId, (string) $request->query->get('pdf_lang', 'pl'));
                }
                exit;
            }

            if ($request->isMethod('GET') && $request->query->has('exportInvoiceTranslationPdf')) {
                $orderId = (int) $request->query->get('id_purchase_order', 0);
                if ($orderId > 0) {
                    $service->outputPurchaseOrderInvoiceTranslationPdf($orderId);
                }
                exit;
            }

            if ($request->isMethod('GET') && $request->query->has('downloadPurchaseOrderFile')) {
                $orderId = (int) $request->query->get('id_purchase_order', 0);
                $fileId = (int) $request->query->get('id_purchase_order_file', 0);
                $disposition = (string) $request->query->get('disposition', 'attachment');

                if ($orderId > 0 && $fileId > 0) {
                    $fileData = $service->getPurchaseOrderFileDownloadData($fileId, $orderId);
                    $response = new BinaryFileResponse($fileData['absolute_path']);
                    $response->headers->set('Content-Type', $fileData['mime_type'] !== '' ? $fileData['mime_type'] : 'application/octet-stream');
                    $response->setContentDisposition(
                        $disposition === 'inline' ? ResponseHeaderBag::DISPOSITION_INLINE : ResponseHeaderBag::DISPOSITION_ATTACHMENT,
                        $fileData['original_name'] !== '' ? $fileData['original_name'] : basename($fileData['absolute_path'])
                    );

                    return $response;
                }

                throw $this->createNotFoundException();
            }

            if (!($licenseStatus['valid'] ?? false) && $request->isMethod('POST')) {
                $errors[] = (string) ($licenseStatus['message'] ?? $this->translate('license_missing_message'));
            }

            if (($licenseStatus['valid'] ?? false) && $request->isMethod('POST')) {
                try {
                    if (\Tools::isSubmit('submitCargoStockManagerCreatePurchaseOrder')) {
                        $idPurchaseOrder = $service->createPurchaseOrder();

                        return $this->redirectToRoute('cargo_stock_manager_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'created',
                        ]);
                    }

                    if (\Tools::isSubmit('submitCargoStockManagerSavePurchaseOrder')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $service->savePurchaseOrder($idPurchaseOrder, $request->request->all());

                        return $this->redirectToRoute('cargo_stock_manager_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'saved',
                        ]);
                    }

                    if (\Tools::isSubmit('submitCargoStockManagerChangePurchaseOrderStatus')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $service->updatePurchaseOrderStatus($idPurchaseOrder, (string) \Tools::getValue('status_key', 'draft'));

                        return $this->redirectToRoute('cargo_stock_manager_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'status_changed',
                        ]);
                    }

                    if (\Tools::isSubmit('submitCargoStockManagerReceivePurchaseOrderStock')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $payload = $service->receivePurchaseOrderToStock($idPurchaseOrder);

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse([
                                'ok' => true,
                                'items' => $payload['items'] ?? [],
                                'stock_received' => !empty($payload['stock_received']),
                            ]);
                        }

                        return $this->redirectToRoute('cargo_stock_manager_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'stock_received',
                        ]);
                    }

                    if (\Tools::isSubmit('submitCargoStockManagerUpdatePurchaseOrderSupplierInline')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $payload = $service->updatePurchaseOrderSupplier(
                            $idPurchaseOrder,
                            (int) \Tools::getValue('id_supplier')
                        );

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse([
                                'ok' => true,
                                'supplier' => $payload['supplier'] ?? [],
                                'id_supplier' => (int) ($payload['order']['id_supplier'] ?? 0),
                            ]);
                        }

                        return $this->redirectToRoute('cargo_stock_manager_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'saved',
                        ]);
                    }

                    if (\Tools::isSubmit('submitCargoStockManagerUpdatePurchaseOrderFieldInline')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $payload = $service->updatePurchaseOrderFieldInline(
                            $idPurchaseOrder,
                            (string) \Tools::getValue('field'),
                            (string) \Tools::getValue('value')
                        );

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse([
                                'ok' => true,
                                'order' => $payload['order'] ?? [],
                            ]);
                        }

                        return $this->redirectToRoute('cargo_stock_manager_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'saved',
                        ]);
                    }

                    if (\Tools::isSubmit('submitCargoStockManagerUpdatePurchaseOrderItemInline')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $payload = $service->updatePurchaseOrderItemField(
                            $idPurchaseOrder,
                            (int) \Tools::getValue('id_purchase_order_item'),
                            (string) \Tools::getValue('field'),
                            (string) \Tools::getValue('value')
                        );

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse([
                                'ok' => true,
                                'item' => $payload['item'] ?? [],
                                'items_total_formatted' => $payload['items_total_formatted'] ?? '',
                            ]);
                        }

                        return $this->redirectToRoute('cargo_stock_manager_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'item_saved',
                        ]);
                    }

                    if (\Tools::isSubmit('submitCargoStockManagerUpdatePurchaseOrderProductModuleData')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $payload = $service->updatePurchaseOrderProductModuleData(
                            $idPurchaseOrder,
                            (int) \Tools::getValue('id_purchase_order_item'),
                            $request->request->all()
                        );

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse([
                                'ok' => true,
                                'item' => $payload['item'] ?? [],
                            ]);
                        }

                        return $this->redirectToRoute('cargo_stock_manager_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'item_saved',
                        ]);
                    }

                    if (\Tools::isSubmit('submitCargoStockManagerSavePurchaseOrderItemMarkup')) {
                        $markupRate = $service->savePurchaseMarkupRate(
                            (int) \Tools::getValue('id_product'),
                            (int) \Tools::getValue('id_product_attribute'),
                            (string) \Tools::getValue('markup_rate', '')
                        );

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse([
                                'ok' => true,
                                'markup_rate' => $markupRate,
                            ]);
                        }
                    }

                    if (\Tools::isSubmit('submitCargoStockManagerDeletePurchaseOrder')) {
                        $service->deletePurchaseOrder((int) \Tools::getValue('id_purchase_order'));

                        return $this->redirectToRoute('cargo_stock_manager_purchase_orders', [
                            'purchase_order_status' => 'deleted',
                        ]);
                    }

                    if (\Tools::isSubmit('submitCargoStockManagerDeletePurchaseOrderItem')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $service->deletePurchaseOrderItem(
                            (int) \Tools::getValue('id_purchase_order_item'),
                            $idPurchaseOrder
                        );

                        return $this->redirectToRoute('cargo_stock_manager_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'item_deleted',
                        ]);
                    }

                    if (\Tools::isSubmit('submitCargoStockManagerAddPurchaseOrderItem')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $payload = $service->addPurchaseOrderItem(
                            $idPurchaseOrder,
                            (string) \Tools::getValue('purchase_order_product_selection', ''),
                            (string) \Tools::getValue('purchase_order_item_quantity', '1'),
                            (string) \Tools::getValue('purchase_order_item_price', '')
                        );

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse([
                                'ok' => true,
                                'item' => $payload['item'] ?? [],
                                'items_total_formatted' => $payload['items_total_formatted'] ?? '',
                            ]);
                        }

                        return $this->redirectToRoute('cargo_stock_manager_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'item_added',
                        ]);
                    }

                    if (\Tools::isSubmit('submitCargoStockManagerRelinkPurchaseOrderItem')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $payload = $service->relinkPurchaseOrderItem(
                            $idPurchaseOrder,
                            (int) \Tools::getValue('id_purchase_order_item'),
                            (string) \Tools::getValue('purchase_order_product_selection', '')
                        );

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse([
                                'ok' => true,
                                'item' => $payload['item'] ?? [],
                                'items_total_formatted' => $payload['items_total_formatted'] ?? '',
                            ]);
                        }

                        return $this->redirectToRoute('cargo_stock_manager_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'item_saved',
                        ]);
                    }

                    if (\Tools::isSubmit('submitCargoStockManagerUploadPurchaseOrderFile')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $uploadedFiles = [];
                        $normalizedFiles = $this->normalizeUploadedFiles($_FILES['purchase_order_files'] ?? ($_FILES['purchase_order_file'] ?? []));
                        $descriptions = \Tools::getValue('purchase_order_file_descriptions', \Tools::getValue('purchase_order_file_description', []));
                        $documentTypeIds = \Tools::getValue('id_csmgr_document_types', \Tools::getValue('id_csmgr_document_type', []));

                        try {
                            foreach ($normalizedFiles as $index => $uploadedFile) {
                                $uploadedFiles[] = $service->uploadPurchaseOrderFile(
                                    $idPurchaseOrder,
                                    $uploadedFile,
                                    $this->getIndexedPostValue($descriptions, $index),
                                    (int) $this->getIndexedPostValue($documentTypeIds, $index)
                                );
                            }
                        } catch (\Throwable $uploadException) {
                            foreach ($uploadedFiles as $uploadedFile) {
                                $uploadedFileId = (int) ($uploadedFile['id_purchase_order_file'] ?? 0);
                                if ($uploadedFileId > 0) {
                                    try {
                                        $service->deletePurchaseOrderFile($uploadedFileId, $idPurchaseOrder);
                                    } catch (\Throwable $cleanupException) {
                                    }
                                }
                            }

                            throw $uploadException;
                        }

                        if ($uploadedFiles === []) {
                            throw new \RuntimeException('Nie udało się dodać pliku.');
                        }

                        if ($request->isXmlHttpRequest()) {
                            $uploadedFiles = array_map(function (array $fileData) use ($idPurchaseOrder): array {
                                $fileData['download_url'] = $this->buildPurchaseOrderFileUrl($idPurchaseOrder, (int) ($fileData['id_purchase_order_file'] ?? 0));
                                $fileData['preview_url'] = $this->buildPurchaseOrderFileUrl($idPurchaseOrder, (int) ($fileData['id_purchase_order_file'] ?? 0), 'inline');

                                return $fileData;
                            }, $uploadedFiles);

                            return new JsonResponse(['ok' => true, 'files' => $uploadedFiles]);
                        }

                        return $this->redirectToRoute('cargo_stock_manager_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'file_uploaded',
                        ]);
                    }

                    if (\Tools::isSubmit('submitCargoStockManagerDeletePurchaseOrderFile')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $service->deletePurchaseOrderFile(
                            (int) \Tools::getValue('id_purchase_order_file'),
                            $idPurchaseOrder
                        );

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse(['ok' => true]);
                        }

                        return $this->redirectToRoute('cargo_stock_manager_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'file_deleted',
                        ]);
                    }

                    if (\Tools::isSubmit('submitCargoStockManagerSendPurchaseOrderFilesToAccounting')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $service->sendPurchaseOrderFilesToAccounting(
                            $idPurchaseOrder,
                            (array) \Tools::getValue('purchase_order_accounting_file_ids', []),
                            (string) \Tools::getValue('purchase_order_accounting_email', '')
                        );

                        return $this->redirectToRoute('cargo_stock_manager_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'files_sent_to_accounting',
                        ]);
                    }

                    if (\Tools::isSubmit('submitCargoStockManagerAddPurchaseOrderNote')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $service->addPurchaseOrderNote(
                            $idPurchaseOrder,
                            (string) \Tools::getValue('purchase_order_note_content', '')
                        );

                        return $this->redirectToRoute('cargo_stock_manager_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'note_added',
                        ]);
                    }

                    if (\Tools::isSubmit('submitCargoStockManagerDeletePurchaseOrderNote')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $service->deletePurchaseOrderNote(
                            (int) \Tools::getValue('id_purchase_order_note'),
                            $idPurchaseOrder
                        );

                        return $this->redirectToRoute('cargo_stock_manager_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'note_deleted',
                        ]);
                    }

                    if (\Tools::isSubmit('submitCargoStockManagerUpdatePurchaseOrderFileDescription')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $service->updatePurchaseOrderFileDescription(
                            (int) \Tools::getValue('id_purchase_order_file'),
                            $idPurchaseOrder,
                            (string) \Tools::getValue('description', '')
                        );

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse(['ok' => true]);
                        }

                        return $this->redirectToRoute('cargo_stock_manager_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'file_saved',
                        ]);
                    }

                    if (\Tools::isSubmit('submitCargoStockManagerUpdatePurchaseOrderFileDocType')) {
                        $idPurchaseOrder = (int) \Tools::getValue('id_purchase_order');
                        $payload = $service->updatePurchaseOrderFileDocType(
                            (int) \Tools::getValue('id_purchase_order_file'),
                            $idPurchaseOrder,
                            (int) \Tools::getValue('id_csmgr_document_type', 0)
                        );

                        if ($request->isXmlHttpRequest()) {
                            return new JsonResponse(['ok' => true, 'file' => $payload]);
                        }

                        return $this->redirectToRoute('cargo_stock_manager_purchase_orders', [
                            'id_purchase_order' => $idPurchaseOrder,
                            'purchase_order_status' => 'file_saved',
                        ]);
                    }
                } catch (\Throwable $e) {
                    if ($request->isXmlHttpRequest()) {
                        return new JsonResponse([
                            'ok' => false,
                            'error' => $e->getMessage() !== '' ? $e->getMessage() : 'Nie udało się zapisać zamówienia.',
                        ], 400);
                    }

                    $errors[] = $e->getMessage() !== '' ? $e->getMessage() : 'Nie udało się zapisać zamówienia.';
                }
            }

            $status = (string) $request->query->get('purchase_order_status', '');
            if ($status === 'created') {
                $messages[] = 'Nowe zamówienie zostało utworzone.';
            } elseif ($status === 'saved') {
                $messages[] = 'Zamówienie zostało zapisane.';
            } elseif ($status === 'deleted') {
                $messages[] = 'Zamówienie zostało usunięte.';
            } elseif ($status === 'item_deleted') {
                $messages[] = 'Pozycja zamówienia została usunięta.';
            } elseif ($status === 'item_added') {
                $messages[] = 'Produkt został dodany do zamówienia.';
            } elseif ($status === 'item_saved') {
                $messages[] = 'Pozycja zamówienia została zapisana.';
            } elseif ($status === 'file_uploaded') {
                $messages[] = 'Plik został dodany do zamówienia.';
            } elseif ($status === 'file_deleted') {
                $messages[] = 'Plik został usunięty z zamówienia.';
            } elseif ($status === 'files_sent_to_accounting') {
                $messages[] = 'Dokumenty zostały wysłane.';
            } elseif ($status === 'note_added') {
                $messages[] = 'Notatka została dodana do zamówienia.';
            } elseif ($status === 'note_deleted') {
                $messages[] = 'Notatka została usunięta z zamówienia.';
            } elseif ($status === 'status_changed') {
                $messages[] = 'Status zamówienia został zmieniony.';
            } elseif ($status === 'stock_received') {
                $messages[] = 'Produkty z zamówienia zostały dodane do magazynu.';
            }

            $purchaseOrdersPageData = $service->getPurchaseOrdersPage($purchaseOrderQuery, $purchaseOrderPage, $purchaseOrderPerPage, $purchaseOrderFilters);
            $purchaseOrders = array_map(function (array $order) use ($purchaseOrderQuery, $purchaseOrderPage, $purchaseOrderPerPage, $purchaseOrderProductId, $purchaseOrderProductAttributeId): array {
                $previewUrl = $this->generateUrl('cargo_stock_manager_purchase_orders', [
                    'id_purchase_order' => (int) ($order['id_purchase_order'] ?? 0),
                    'query' => $purchaseOrderQuery !== '' ? $purchaseOrderQuery : null,
                    'page' => $purchaseOrderPage > 1 ? $purchaseOrderPage : null,
                    'per_page' => $purchaseOrderPerPage !== 20 ? $purchaseOrderPerPage : null,
                    'id_product' => $purchaseOrderProductId > 0 ? $purchaseOrderProductId : null,
                    'id_product_attribute' => $purchaseOrderProductAttributeId > 0 ? $purchaseOrderProductAttributeId : null,
                ]);

                $order['detail_url'] = $previewUrl;
                $order['preview_url'] = $previewUrl;

                return $order;
            }, $purchaseOrdersPageData['items'] ?? []);

            $selectedOrderId = (int) $request->query->get('id_purchase_order', (int) \Tools::getValue('id_purchase_order', 0));
            if ($selectedOrderId > 0) {
                try {
                    $selectedOrder = $service->getPurchaseOrder($selectedOrderId);
                    $selectedOrder['files'] = array_map(function (array $file) use ($selectedOrderId): array {
                        $fileId = (int) ($file['id_purchase_order_file'] ?? 0);
                        $file['download_url'] = $this->buildPurchaseOrderFileUrl($selectedOrderId, $fileId);
                        $file['preview_url'] = $this->buildPurchaseOrderFileUrl($selectedOrderId, $fileId, 'inline');

                        return $file;
                    }, $selectedOrder['files'] ?? []);
                    $statusValues = array_column($selectedOrder['status_options'], 'value');
                    $selectedOrder['timeline'] = [
                        'current_index' => max(0, (int) array_search($selectedOrder['order']['status_key'], $statusValues, true)),
                    ];
                    $selectedOrder['navigation'] = [
                        'older_url' => null,
                        'newer_url' => null,
                    ];

                    $olderId = 0;
                    $newerId = 0;
                    $orderUrlsById = [];
                    foreach ($service->getPurchaseOrders($purchaseOrderQuery, $purchaseOrderFilters) as $orderRow) {
                        $orderId = (int) ($orderRow['id_purchase_order'] ?? 0);
                        if ($orderId <= 0) {
                            continue;
                        }

                        $orderUrlsById[$orderId] = (string) $this->generateUrl('cargo_stock_manager_purchase_orders', [
                            'id_purchase_order' => $orderId,
                            'query' => $purchaseOrderQuery !== '' ? $purchaseOrderQuery : null,
                            'page' => $purchaseOrderPage > 1 ? $purchaseOrderPage : null,
                            'per_page' => $purchaseOrderPerPage !== 20 ? $purchaseOrderPerPage : null,
                            'id_product' => $purchaseOrderProductId > 0 ? $purchaseOrderProductId : null,
                            'id_product_attribute' => $purchaseOrderProductAttributeId > 0 ? $purchaseOrderProductAttributeId : null,
                        ]);
                        if ($orderId < $selectedOrderId && $orderId > $olderId) {
                            $olderId = $orderId;
                        }
                        if ($orderId > $selectedOrderId && ($newerId === 0 || $orderId < $newerId)) {
                            $newerId = $orderId;
                        }
                    }

                    if ($olderId > 0 && isset($orderUrlsById[$olderId])) {
                        $selectedOrder['navigation']['older_url'] = $orderUrlsById[$olderId];
                    }
                    if ($newerId > 0 && isset($orderUrlsById[$newerId])) {
                        $selectedOrder['navigation']['newer_url'] = $orderUrlsById[$newerId];
                    }
                } catch (\Throwable $e) {
                    $errors[] = $e->getMessage() !== '' ? $e->getMessage() : 'Nie znaleziono zamówienia.';
                }
            }
        }

        return $this->renderInventoryPage(
            '@Modules/cargostockmanager/views/templates/admin-modern/purchase_orders.html.twig',
            'cargo_stock_manager_purchase_orders',
            'purchase_orders_tab',
            [
                'purchaseOrders' => $purchaseOrders,
                'selectedOrder' => $selectedOrder,
                'purchaseOrderMessages' => $messages,
                'purchaseOrderErrors' => $errors,
                'purchaseOrdersUrl' => $this->generateUrl('cargo_stock_manager_purchase_orders'),
                'purchaseOrdersListUrl' => $this->generateUrl('cargo_stock_manager_purchase_orders', array_filter([
                    'query' => $purchaseOrderQuery !== '' ? $purchaseOrderQuery : null,
                    'page' => $purchaseOrderPage > 1 ? $purchaseOrderPage : null,
                    'per_page' => $purchaseOrderPerPage !== 20 ? $purchaseOrderPerPage : null,
                    'id_product' => $purchaseOrderProductId > 0 ? $purchaseOrderProductId : null,
                    'id_product_attribute' => $purchaseOrderProductAttributeId > 0 ? $purchaseOrderProductAttributeId : null,
                ], static function ($value) {
                    return $value !== null && $value !== '';
                })),
                'purchaseOrderQuery' => $purchaseOrderQuery,
                'purchaseOrdersPagination' => $purchaseOrdersPageData['pagination'] ?? '',
                'purchaseOrderPage' => $purchaseOrdersPageData['current_page'] ?? $purchaseOrderPage,
                'purchaseOrderPerPage' => $purchaseOrdersPageData['per_page'] ?? $purchaseOrderPerPage,
                'purchaseOrderProductId' => $purchaseOrderProductId,
                'purchaseOrderProductAttributeId' => $purchaseOrderProductAttributeId,
                'licenseStatus' => $licenseStatus,
                'accountingEmail' => $service->getConfiguredAccountingEmail(),
            ]
        );
    }

    private function buildPurchaseOrderFileUrl(int $idPurchaseOrder, int $idPurchaseOrderFile, string $disposition = 'attachment'): string
    {
        return $this->generateUrl('cargo_stock_manager_purchase_orders', [
            'id_purchase_order' => $idPurchaseOrder,
            'id_purchase_order_file' => $idPurchaseOrderFile,
            'downloadPurchaseOrderFile' => 1,
            'disposition' => $disposition,
        ]);
    }

    /**
     * @param array<string, mixed> $files
     *
     * @return array<int, array<string, mixed>>
     */
    private function normalizeUploadedFiles(array $files): array
    {
        if ($files === [] || !isset($files['name'])) {
            return [];
        }

        if (!is_array($files['name'])) {
            return [$files];
        }

        $normalized = [];
        foreach (array_keys($files['name']) as $index) {
            $normalized[] = [
                'name' => $files['name'][$index] ?? '',
                'type' => $files['type'][$index] ?? '',
                'tmp_name' => $files['tmp_name'][$index] ?? '',
                'error' => $files['error'][$index] ?? UPLOAD_ERR_NO_FILE,
                'size' => $files['size'][$index] ?? 0,
            ];
        }

        return $normalized;
    }

    /**
     * @param mixed $value
     */
    private function getIndexedPostValue($value, int $index): string
    {
        if (is_array($value)) {
            return (string) ($value[$index] ?? '');
        }

        return $index === 0 ? (string) $value : '';
    }
}
