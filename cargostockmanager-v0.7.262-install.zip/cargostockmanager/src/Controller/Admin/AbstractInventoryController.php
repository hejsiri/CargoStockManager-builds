<?php
declare(strict_types=1);

namespace PrestaShop\Module\CargoStockManager\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerI18n.php';
require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerLicense.php';

if (!class_exists('PrestaShopBundle\\Controller\\Admin\\PrestaShopAdminController')) {
    $legacyControllerClass = 'PrestaShopBundle\\Controller\\Admin\\FrameworkBundleAdmin' . 'Controller';
    if (class_exists($legacyControllerClass)) {
        class_alias($legacyControllerClass, 'PrestaShopBundle\\Controller\\Admin\\PrestaShopAdminController');
    }
}

use PrestaShop\PrestaShop\Adapter\LegacyContext;
use PrestaShopBundle\Controller\Admin\PrestaShopAdminController;
use Symfony\Contracts\Translation\TranslatorInterface;
use Twig\Markup;

abstract class AbstractInventoryController extends PrestaShopAdminController
{
    private TranslatorInterface $translator;
    private LegacyContext $legacyContext;

    public function __construct(TranslatorInterface $translator, LegacyContext $legacyContext)
    {
        $this->translator = $translator;
        $this->legacyContext = $legacyContext;
    }

    protected function getLegacyContext()
    {
        return $this->legacyContext->getContext();
    }

    protected function buildHeaderTabContent(string $currentRoute): array|string
    {
        $context = $this->getLegacyContext();
        $module = \Module::getInstanceByName('cargostockmanager');
        $configUrl = '';

        if (is_object($context) && isset($context->link) && $context->link instanceof \Link && $module instanceof \Module) {
            $configUrl = $context->link->getAdminLink('AdminCargoStockManagerSettings', true);
        }

        $tabsMarkup = $this->renderView('@Modules/cargostockmanager/views/templates/admin-modern/_head_tabs.html.twig', [
            'currentRoute' => $currentRoute,
            'inventoryTexts' => \CargoStockManagerI18n::all($this->translator),
            'inventoryModuleUrl' => is_object($context) ? $context->link->getAdminLink('AdminCargoStockManager', true) : '',
            'inventoryStatisticsUrl' => is_object($context) ? $context->link->getAdminLink('AdminCargoStockManagerStatistics', true) : '',
            'inventoryConfigUrl' => $configUrl,
            'inventorySuppliersUrl' => is_object($context) ? $context->link->getAdminLink('AdminCargoStockManagerSuppliers', true) : '',
            'inventoryPurchaseOrdersUrl' => is_object($context) ? $context->link->getAdminLink('AdminCargoStockManagerPurchaseOrders', true) : '',
            'inventoryHelpUrl' => is_object($context) ? $context->link->getAdminLink('AdminCargoStockManagerHelp', true) : '',
        ]);

        if (version_compare(_PS_VERSION_, '9.0.0', '>=')) {
            return [new Markup($tabsMarkup, 'UTF-8')];
        }

        return $tabsMarkup;
    }

    protected function translate(string $key, array $params = []): string
    {
        return \CargoStockManagerI18n::translate($this->translator, $key, $params);
    }

    protected function inventoryTexts(): array
    {
        return \CargoStockManagerI18n::all($this->translator);
    }

    protected function getModuleLicenseStatus(): array
    {
        $module = \Module::getInstanceByName('cargostockmanager');
        $context = $this->getLegacyContext();

        if (!$module instanceof \Module || !is_object($context)) {
            return [
                'valid' => false,
                'code' => 'context_missing',
                'message' => $this->translate('license_missing_message'),
                'details' => [],
            ];
        }

        $licenseService = new \CargoStockManagerLicense($module->getLocalPath(), $context, $module);

        return $licenseService->getStatus();
    }

    protected function isModuleLicenseValid(): bool
    {
        $status = $this->getModuleLicenseStatus();

        return (bool) ($status['valid'] ?? false);
    }

    protected function renderInventoryPage(string $template, string $currentRoute, string $sectionLabelKey, array $extra = [])
    {
        $module = \Module::getInstanceByName('cargostockmanager');
        $context = $this->getLegacyContext();

        return $this->render($template, array_merge([
            'layoutTitle' => $this->translate('inventory_report'),
            'headerTabContent' => $this->buildHeaderTabContent($currentRoute),
            'inventoryCurrentSectionLabel' => $this->translate($sectionLabelKey),
            'inventoryReportLabel' => $this->translate('inventory_report'),
            'inventoryHomeUrl' => is_object($context) ? $context->link->getAdminLink('AdminCargoStockManager', true) : '',
            'moduleVersion' => $module instanceof \Module ? (string) $module->version : '0.0.0',
            'inventoryTexts' => $this->inventoryTexts(),
            'licenseStatus' => $this->getModuleLicenseStatus(),
        ], $extra));
    }
}
