<?php
/**
 * CargoStock Manager module.
 *
 * @author    Prestino
 * @copyright 2026 Prestino
 * @license   Commercial
 */
declare(strict_types=1);

namespace PrestaShop\Module\CargoStockManager\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerService.php';
require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerLicense.php';
require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerUpdater.php';

if (!class_exists('PrestaShopBundle\\Security\\Attribute\\AdminSecurity')) {
    $legacySecurityClass = 'PrestaShopBundle\\Security\\Annotation\\AdminSecurity';
    if (class_exists($legacySecurityClass)) {
        class_alias($legacySecurityClass, 'PrestaShopBundle\\Security\\Attribute\\AdminSecurity');
    }
}

use PrestaShopBundle\Security\Attribute\AdminSecurity;
use Symfony\Component\HttpFoundation\Response;

class WarehouseController extends AbstractInventoryController
{
    public const TAB_CLASS_NAME = 'AdminCargoStockManager';

    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function indexAction(): Response
    {
        $module = $this->getModuleInstance();
        $context = $this->getLegacyContext();
        $service = new \CargoStockManagerService($module->getLocalPath(), $context, $module);
        $updaterService = new \CargoStockManagerUpdater($module->getLocalPath(), $module);

        if ($module instanceof \cargostockmanager) {
            $module->ensureTabsAvailable();
        }

        $translations = $service->getTranslations();
        $licenseStatus = $this->getModuleLicenseStatus();
        $assetsVersion = $module instanceof \cargostockmanager
            ? $module->getAssetVersion('views/js/chart.umd.min.js')
            : (string) $module->version;

        $context->smarty->assign([
            'inventoryCatalogUrl' => $context->link->getAdminLink('AdminProducts', true),
            'inventoryModuleUrl' => $context->link->getAdminLink('AdminCargoStockManager', true),
            'inventoryStatisticsUrl' => $context->link->getAdminLink('AdminCargoStockManagerStatistics', true),
            'inventorySuppliersUrl' => $context->link->getAdminLink('AdminCargoStockManagerSuppliers', true),
            'inventoryPurchaseOrdersUrl' => $context->link->getAdminLink('AdminCargoStockManagerPurchaseOrders', true),
            'inventoryModuleBaseUrl' => $module->getPathUri(),
            'inventoryAjaxUrl' => $context->link->getAdminLink('AdminCargoStockManager', true, [], [
                'ajax' => 1,
            ]),
            'inventoryExportUrl' => $context->link->getAdminLink('AdminCargoStockManager', true, [], [
                'exportPdf' => 1,
            ]),
            'inventoryConfigUrl' => $context->link->getAdminLink('AdminCargoStockManagerSettings', true),
            'inventoryLanguageIso' => (string) $context->language->iso_code,
            'inventoryCanEdit' => true,
            'inventoryTranslations' => $translations,
            'inventoryTranslationsJson' => json_encode($translations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'inventoryModuleVersion' => (string) $module->version,
            'inventoryAssetsVersion' => $assetsVersion,
            'inventoryLicenseStatus' => $licenseStatus,
            'inventoryUpdateConfigured' => $updaterService->isConfigured(),
            'inventoryUpdateChannel' => $updaterService->getConfiguredChannel(),
            'inventoryEmbeddedInModernLayout' => true,
        ]);

        $legacyContent = '';
        if ($licenseStatus['valid'] ?? false) {
            $legacyContent = $module->display(
                $module->getLocalPath() . $module->name . '.php',
                'views/templates/admin/app.tpl'
            );
        }

        return $this->renderInventoryPage(
            '@Modules/cargostockmanager/views/templates/admin-modern/warehouse.html.twig',
            'cargo_stock_manager_products',
            'products_tab',
            [
                'legacyContent' => $legacyContent,
            ]
        );
    }
}
