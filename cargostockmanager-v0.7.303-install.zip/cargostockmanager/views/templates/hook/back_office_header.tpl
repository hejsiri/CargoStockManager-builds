{*
 * CargoStock Manager module.
 *
 * @author    Prestino
 * @copyright 2026 Prestino
 * @license   Commercial
 *}
<style>
  .cargostockmanager-menu-badge {
    font-size: 10px;
    color: #fff;
    padding: 0 5px !important;
    margin-left: 5px !important;
    border-radius: 10px;
    background: #f54c3e;
    height: 15px;
    min-width: 5px;
    display: inline-block;
    text-align: center;
    line-height: 14px;
    vertical-align: middle;
    text-indent: 0;
  }
</style>
<script>
  (function () {
    var config = JSON.parse('{$csmgrMenuBadgeConfig|escape:'javascript':'UTF-8'}');

    function getMenuAnchor(el) {
      if (!el) {
        return null;
      }

      if (el.matches && el.matches('a')) {
        return el;
      }

      return el.querySelector ? el.querySelector('a') : null;
    }

    function isPurchaseOrdersLink(link) {
      if (!link) {
        return false;
      }

      var href = link.getAttribute('href') || '';
      return href.indexOf(config.controller) !== -1 ||
        href.indexOf('_legacy_controller=' + config.controller) !== -1 ||
        (link.textContent || '').trim().indexOf(config.label) !== -1 ||
        (link.textContent || '').trim().indexOf('Zamówienia') !== -1 ||
        (link.textContent || '').trim().indexOf('Purchase orders') !== -1;
    }

    function findPurchaseOrdersMenuLink() {
      var tab = document.getElementById(config.tabId) ||
        document.querySelector('[id$="' + config.controller + '"]') ||
        document.querySelector('[data-submenu="' + config.controller + '"]');
      if (tab) {
        var tabLink = getMenuAnchor(tab);
        if (tabLink) {
          return tabLink;
        }
      }

      var controllerSelector = 'a[href*="controller=' + config.controller + '"]';
      var legacySelector = 'a[href*="_legacy_controller=' + config.controller + '"]';
      var controllerAnySelector = 'a[href*="' + config.controller + '"]';
      var links = Array.prototype.slice.call(document.querySelectorAll(controllerSelector + ',' + legacySelector + ',' + controllerAnySelector));
      for (var i = 0; i < links.length; i++) {
        if (isPurchaseOrdersLink(links[i])) {
          return links[i];
        }
      }

      links = Array.prototype.slice.call(document.querySelectorAll('#nav-sidebar a, .nav-bar a, .sidebar a, nav a'));
      for (var j = 0; j < links.length; j++) {
        if (isPurchaseOrdersLink(links[j])) {
          return links[j];
        }
      }

      return null;
    }

    function attachPurchaseOrdersBadge() {
      var link = findPurchaseOrdersMenuLink();
      if (!link) {
        return false;
      }

      Array.prototype.slice.call(document.querySelectorAll('.cargostockmanager-menu-badge')).forEach(function (badgeEl) {
        if (!link.contains(badgeEl) && badgeEl.parentNode) {
          badgeEl.parentNode.removeChild(badgeEl);
        }
      });

      Array.prototype.slice.call(link.querySelectorAll('.cargostockmanager-menu-badge')).forEach(function (badgeEl) {
        if (badgeEl.parentNode) {
          badgeEl.parentNode.removeChild(badgeEl);
        }
      });

      if (!config.badges || !config.badges.length) {
        return true;
      }

      config.badges.forEach(function (badgeConfig) {
        var badge = document.createElement('span');
        badge.className = 'cargostockmanager-menu-badge';
        badge.textContent = String(badgeConfig.count || 0);
        badge.style.backgroundColor = badgeConfig.color || '#f54c3e';
        badge.setAttribute('aria-label', String(badgeConfig.label || '') + ': ' + String(badgeConfig.count || 0));
        link.appendChild(badge);
      });

      return true;
    }

    if (!attachPurchaseOrdersBadge()) {
      document.addEventListener('DOMContentLoaded', function () {
        if (attachPurchaseOrdersBadge()) {
          return;
        }
        window.setTimeout(attachPurchaseOrdersBadge, 300);
      });
    }

    if ('MutationObserver' in window) {
      var attempts = 0;
      var observer = new MutationObserver(function () {
        attempts++;
        if (attachPurchaseOrdersBadge() || attempts > 20) {
          observer.disconnect();
        }
      });
      observer.observe(document.documentElement, { childList: true, subtree: true });
      window.setTimeout(function () { observer.disconnect(); }, 5000);
    }
  })();
</script>
