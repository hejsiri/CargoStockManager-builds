<?php
/**
 * CargoStock Manager module.
 *
 * @author    Prestino
 * @copyright 2026 Prestino
 * @license   Commercial
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_6_9(Module $module): bool
{
    if (method_exists($module, 'migrateLegacyModuleData')) {
        $module->migrateLegacyModuleData();
    }

    if (method_exists($module, 'ensureTabsAvailable')) {
        $module->ensureTabsAvailable();
    }

    return true;
}
