<?php
/**
 * CargoStock Manager module.
 *
 * @author    Prestino
 * @copyright 2026 Prestino
 * @license   Commercial
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_7_188($module)
{
    if (!is_object($module)) {
        return false;
    }

    if (method_exists($module, 'ensureTabsAvailable')) {
        $module->ensureTabsAvailable();
    }

    if (method_exists($module, 'ensureModuleRuntimeReady')) {
        $module->ensureModuleRuntimeReady();
    }

    return true;
}
