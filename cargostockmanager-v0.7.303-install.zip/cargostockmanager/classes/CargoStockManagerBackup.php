<?php
/**
 * CargoStock Manager module.
 *
 * @author    Prestino
 * @copyright 2026 Prestino
 * @license   Commercial
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

class CargoStockManagerBackup
{
    private const FORMAT = 'cargostockmanager-backup';
    private const FORMAT_VERSION = 1;
    private const BACKUP_DIR = 'uploads/backups';
    private const PURCHASE_ORDER_UPLOAD_DIR = 'uploads/purchase_orders';

    private const TABLES = [
        'product_logistics' => 'cargostockmanager_product_logistics',
        'supplier' => 'cargostockmanager_supplier',
        'carrier' => 'cargostockmanager_carrier',
        'document_type' => 'cargostockmanager_document_type',
        'purchase_order' => 'cargostockmanager_purchase_order',
        'purchase_order_item' => 'cargostockmanager_purchase_order_item',
        'purchase_order_file' => 'cargostockmanager_purchase_order_file',
        'purchase_order_note' => 'cargostockmanager_purchase_order_note',
    ];

    private const CONFIG_KEYS = [
        CargoStockManagerService::CONFIG_IGNORED_IDS,
        CargoStockManagerService::CONFIG_PURCHASE_DELIVERY_ADDRESS,
        CargoStockManagerService::CONFIG_PURCHASE_ACCOUNTING_EMAIL,
        CargoStockManagerService::CONFIG_PURCHASE_ORDER_STATUSES,
        CargoStockManagerUpdater::CONFIG_PRESTINO_BUILD,
    ];

    private string $modulePath;
    private $context;
    private Module $module;
    private ?PDO $pdo = null;

    public function __construct(string $modulePath, $context, Module $module)
    {
        $this->modulePath = rtrim($modulePath, '/') . '/';
        $this->context = $context;
        $this->module = $module;
    }

    public function createBackup(): string
    {
        $this->assertZipAvailable();
        $this->ensureInfrastructureReady();
        $this->ensureBackupDirectory();

        $createdAt = date('Y-m-d H:i:s');
        $filename = 'cargostockmanager-backup-' . date('Ymd-His') . '.zip';
        $path = $this->getBackupDirectory() . '/' . $filename;

        $manifest = [
            'format' => self::FORMAT,
            'format_version' => self::FORMAT_VERSION,
            'module' => $this->module->name,
            'module_version' => (string) $this->module->version,
            'created_at' => $createdAt,
            'db_prefix' => _DB_PREFIX_,
        ];

        $payload = [
            'tables' => $this->exportTables(),
            'configuration' => $this->exportConfiguration(),
        ];

        $zip = new ZipArchive();
        if ($zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new RuntimeException('Nie udało się utworzyć pliku kopii zapasowej.');
        }

        $zip->addFromString('manifest.json', $this->encodeJson($manifest));
        $zip->addFromString('database.json', $this->encodeJson($payload));
        $this->addPurchaseOrderFilesToZip($zip);
        $zip->close();

        return $filename;
    }

    public function listBackups(): array
    {
        $this->ensureBackupDirectory();
        $files = glob($this->getBackupDirectory() . '/*.zip') ?: [];
        $backups = [];

        foreach ($files as $file) {
            if (!is_file($file)) {
                continue;
            }

            $filename = basename($file);
            $mtime = (int) (@filemtime($file) ?: 0);
            $size = (int) (@filesize($file) ?: 0);
            $backups[] = [
                'filename' => $filename,
                'size' => $size,
                'size_label' => $this->formatBytes($size),
                'created_at' => $mtime > 0 ? date('Y-m-d H:i:s', $mtime) : '',
            ];
        }

        usort($backups, static function (array $a, array $b): int {
            return strcmp((string) $b['created_at'], (string) $a['created_at']);
        });

        return $backups;
    }

    public function getBackupPath(string $filename): string
    {
        $filename = $this->sanitizeBackupFilename($filename);
        $path = $this->getBackupDirectory() . '/' . $filename;
        if (!is_file($path)) {
            throw new RuntimeException('Nie znaleziono kopii zapasowej.');
        }

        return $path;
    }

    public function restoreBackup(string $filename): void
    {
        $this->restoreFromPath($this->getBackupPath($filename));
    }

    public function deleteBackup(string $filename): void
    {
        $path = $this->getBackupPath($filename);
        if (!unlink($path)) {
            throw new RuntimeException('Nie udało się usunąć kopii zapasowej.');
        }
    }

    /**
     * @param mixed $uploadedFile
     */
    public function importUploadedBackup($uploadedFile): string
    {
        $this->assertZipAvailable();
        $this->ensureBackupDirectory();

        if ($uploadedFile instanceof \Symfony\Component\HttpFoundation\File\UploadedFile) {
            return $this->importSymfonyUploadedBackup($uploadedFile);
        }

        if (!is_array($uploadedFile)) {
            throw new RuntimeException('Nieprawidłowy plik kopii zapasowej.');
        }

        $error = (int) ($uploadedFile['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($error !== UPLOAD_ERR_OK) {
            throw new RuntimeException($this->getUploadErrorMessage($error));
        }

        $tmpName = (string) ($uploadedFile['tmp_name'] ?? '');
        if ($tmpName === '' || !is_file($tmpName)) {
            throw new RuntimeException('Tymczasowy plik kopii zapasowej nie istnieje. Wgraj paczkę ponownie.');
        }

        $originalName = $this->sanitizeBackupFilename((string) ($uploadedFile['name'] ?? 'backup.zip'));
        $filename = 'imported-' . date('Ymd-His') . '-' . $originalName;
        $target = $this->getBackupDirectory() . '/' . $filename;

        if (!$this->copyUploadedFile($tmpName, $target)) {
            throw new RuntimeException('Nie udało się zapisać wgranego pliku kopii zapasowej.');
        }

        $this->restoreFromPath($target);

        return $filename;
    }

    private function importSymfonyUploadedBackup(Symfony\Component\HttpFoundation\File\UploadedFile $uploadedFile): string
    {
        $error = method_exists($uploadedFile, 'getError') ? (int) $uploadedFile->getError() : UPLOAD_ERR_OK;
        if ($error !== UPLOAD_ERR_OK) {
            throw new RuntimeException($this->getUploadErrorMessage($error));
        }

        $tmpName = (string) $uploadedFile->getPathname();
        if ($tmpName === '' || !is_file($tmpName)) {
            throw new RuntimeException('Tymczasowy plik kopii zapasowej nie istnieje. Wgraj paczkę ponownie.');
        }

        $originalName = $this->sanitizeBackupFilename((string) ($uploadedFile->getClientOriginalName() ?: 'backup.zip'));
        $filename = 'imported-' . date('Ymd-His') . '-' . $originalName;
        $target = $this->getBackupDirectory() . '/' . $filename;

        if (!$this->copyUploadedFile($tmpName, $target)) {
            throw new RuntimeException('Nie udało się zapisać wgranego pliku kopii zapasowej.');
        }

        $this->restoreFromPath($target);

        return $filename;
    }

    private function restoreFromPath(string $path): void
    {
        $this->assertZipAvailable();
        $this->ensureInfrastructureReady();

        $zip = new ZipArchive();
        if ($zip->open($path) !== true) {
            throw new RuntimeException('Nie udało się otworzyć pliku kopii zapasowej.');
        }

        try {
            $manifest = $this->readJsonFromZip($zip, 'manifest.json');
            if (($manifest['format'] ?? '') !== self::FORMAT) {
                throw new RuntimeException('Ten plik nie jest kopią zapasową Cargo Stock Manager.');
            }

            $payload = $this->readJsonFromZip($zip, 'database.json');
            $this->restoreTables(is_array($payload['tables'] ?? null) ? $payload['tables'] : []);
            $this->restoreConfiguration(is_array($payload['configuration'] ?? null) ? $payload['configuration'] : []);
            $this->restorePurchaseOrderFilesFromZip($zip);
        } finally {
            $zip->close();
        }
    }

    private function exportTables(): array
    {
        $tables = [];
        foreach (self::TABLES as $logicalName => $tableSuffix) {
            $table = _DB_PREFIX_ . $tableSuffix;
            if (!$this->tableExists($table)) {
                $tables[$logicalName] = [
                    'name' => $table,
                    'columns' => [],
                    'rows' => [],
                ];
                continue;
            }

            $columns = $this->getTableColumns($table);
            $rows = $this->getPdo()->query('SELECT * FROM `' . $table . '`')->fetchAll(PDO::FETCH_ASSOC);
            $tables[$logicalName] = [
                'name' => $table,
                'columns' => $columns,
                'rows' => $rows,
            ];
        }

        return $tables;
    }

    private function restoreTables(array $tables): void
    {
        $pdo = $this->getPdo();
        $pdo->beginTransaction();

        try {
            foreach (self::TABLES as $logicalName => $tableSuffix) {
                $table = _DB_PREFIX_ . $tableSuffix;
                if (!$this->tableExists($table)) {
                    continue;
                }

                $rows = is_array($tables[$logicalName]['rows'] ?? null) ? $tables[$logicalName]['rows'] : [];
                $columns = $this->getTableColumns($table);

                $pdo->exec('DELETE FROM `' . $table . '`');
                if (!$rows) {
                    continue;
                }

                foreach ($rows as $row) {
                    if (!is_array($row)) {
                        continue;
                    }

                    $insert = array_intersect_key($row, array_flip($columns));
                    if (!$insert) {
                        continue;
                    }

                    $fieldSql = implode(', ', array_map(static function (string $column): string {
                        return '`' . str_replace('`', '``', $column) . '`';
                    }, array_keys($insert)));
                    $placeholderSql = implode(', ', array_fill(0, count($insert), '?'));
                    $stmt = $pdo->prepare('INSERT INTO `' . $table . '` (' . $fieldSql . ') VALUES (' . $placeholderSql . ')');
                    $stmt->execute(array_values($insert));
                }
            }

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    private function exportConfiguration(): array
    {
        $configuration = [];
        foreach (self::CONFIG_KEYS as $key) {
            $configuration[$key] = (string) Configuration::get($key);
        }

        return $configuration;
    }

    private function restoreConfiguration(array $configuration): void
    {
        foreach (self::CONFIG_KEYS as $key) {
            if (!array_key_exists($key, $configuration)) {
                continue;
            }

            Configuration::updateValue($key, (string) $configuration[$key]);
        }
    }

    private function addPurchaseOrderFilesToZip(ZipArchive $zip): void
    {
        $baseDir = $this->getPurchaseOrderUploadDirectory();
        if (!is_dir($baseDir)) {
            return;
        }

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($baseDir, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($iterator as $fileInfo) {
            if (!$fileInfo instanceof SplFileInfo) {
                continue;
            }

            $path = $fileInfo->getPathname();
            $relativePath = ltrim(str_replace('\\', '/', substr($path, strlen($baseDir))), '/');
            if ($relativePath === '') {
                continue;
            }

            $zipPath = 'files/purchase_orders/' . $relativePath;
            if ($fileInfo->isDir()) {
                $zip->addEmptyDir($zipPath);
            } elseif ($fileInfo->isFile()) {
                $zip->addFile($path, $zipPath);
            }
        }
    }

    private function restorePurchaseOrderFilesFromZip(ZipArchive $zip): void
    {
        $targetDir = $this->getPurchaseOrderUploadDirectory();
        $this->clearDirectory($targetDir);
        $this->ensureDirectory($targetDir);

        for ($i = 0; $i < $zip->numFiles; ++$i) {
            $stat = $zip->statIndex($i);
            $zipName = is_array($stat) ? (string) $stat['name'] : '';
            if (strpos($zipName, 'files/purchase_orders/') !== 0 || substr($zipName, -1) === '/') {
                continue;
            }

            $relativePath = substr($zipName, strlen('files/purchase_orders/'));
            if (!$this->isSafeRelativePath($relativePath)) {
                throw new RuntimeException('Kopia zapasowa zawiera nieprawidłową ścieżkę pliku.');
            }

            $targetPath = $targetDir . '/' . $relativePath;
            $this->ensureDirectory(dirname($targetPath));
            $source = $zip->getStream($zipName);
            if (!is_resource($source)) {
                throw new RuntimeException('Nie udało się odczytać pliku z kopii zapasowej.');
            }

            $destination = fopen($targetPath, 'wb');
            if (!is_resource($destination)) {
                fclose($source);
                throw new RuntimeException('Nie udało się odtworzyć pliku z kopii zapasowej.');
            }

            stream_copy_to_stream($source, $destination);
            fclose($destination);
            fclose($source);
        }
    }

    private function readJsonFromZip(ZipArchive $zip, string $name): array
    {
        $contents = $zip->getFromName($name);
        if (!is_string($contents) || $contents === '') {
            throw new RuntimeException('Brakuje pliku ' . $name . ' w kopii zapasowej.');
        }

        $decoded = json_decode($contents, true);
        if (!is_array($decoded)) {
            throw new RuntimeException('Plik ' . $name . ' w kopii zapasowej jest nieprawidłowy.');
        }

        return $decoded;
    }

    private function copyUploadedFile(string $source, string $target): bool
    {
        if (is_uploaded_file($source)) {
            return move_uploaded_file($source, $target);
        }

        return copy($source, $target);
    }

    private function getUploadErrorMessage(int $errorCode): string
    {
        switch ($errorCode) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                return 'Plik kopii zapasowej jest za duży.';
            case UPLOAD_ERR_PARTIAL:
                return 'Plik kopii zapasowej został wgrany tylko częściowo.';
            case UPLOAD_ERR_NO_FILE:
                return 'Wybierz plik kopii zapasowej do wgrania.';
            case UPLOAD_ERR_NO_TMP_DIR:
                return 'Serwer nie ma katalogu tymczasowego dla uploadów.';
            case UPLOAD_ERR_CANT_WRITE:
                return 'Serwer nie może zapisać wgranego pliku kopii zapasowej.';
            case UPLOAD_ERR_EXTENSION:
                return 'Rozszerzenie PHP przerwało wgrywanie pliku kopii zapasowej.';
            default:
                return 'Nie udało się wgrać pliku kopii zapasowej.';
        }
    }

    private function ensureInfrastructureReady(): void
    {
        $service = new CargoStockManagerService($this->modulePath, $this->context, $this->module);
        $service->ensurePurchaseOrderInfrastructure();
    }

    private function tableExists(string $table): bool
    {
        $stmt = $this->getPdo()->prepare('SHOW TABLES LIKE ?');
        $stmt->execute([$table]);

        return (bool) $stmt->fetchColumn();
    }

    private function getTableColumns(string $table): array
    {
        $rows = $this->getPdo()->query('SHOW COLUMNS FROM `' . $table . '`')->fetchAll(PDO::FETCH_ASSOC);

        return array_map(static function (array $row): string {
            return (string) ($row['Field'] ?? '');
        }, $rows);
    }

    private function getPdo(): PDO
    {
        if ($this->pdo instanceof PDO) {
            return $this->pdo;
        }

        $this->pdo = new PDO(
            'mysql:host=' . _DB_SERVER_ . ';dbname=' . _DB_NAME_ . ';charset=utf8mb4',
            _DB_USER_,
            _DB_PASSWD_,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]
        );

        return $this->pdo;
    }

    private function encodeJson(array $data): string
    {
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) {
            throw new RuntimeException('Nie udało się przygotować danych kopii zapasowej.');
        }

        return $json;
    }

    private function sanitizeBackupFilename(string $filename): string
    {
        $filename = basename(str_replace('\\', '/', $filename));
        $filename = preg_replace('/[^A-Za-z0-9._-]/', '-', $filename) ?: '';
        if ($filename === '' || substr($filename, -4) !== '.zip') {
            throw new RuntimeException('Nieprawidłowa nazwa pliku kopii zapasowej.');
        }

        return $filename;
    }

    private function isSafeRelativePath(string $path): bool
    {
        return $path !== ''
            && $path[0] !== '/'
            && strpos($path, "\0") === false
            && !preg_match('#(^|/)\.\.(/|$)#', $path);
    }

    private function clearDirectory(string $directory): void
    {
        if (!is_dir($directory)) {
            return;
        }

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );

        foreach ($iterator as $fileInfo) {
            if (!$fileInfo instanceof SplFileInfo) {
                continue;
            }

            if ($fileInfo->isDir()) {
                @rmdir($fileInfo->getPathname());
            } else {
                @unlink($fileInfo->getPathname());
            }
        }
    }

    private function ensureBackupDirectory(): void
    {
        $this->ensureDirectory($this->getBackupDirectory());
    }

    private function ensureDirectory(string $directory): void
    {
        if (is_dir($directory)) {
            return;
        }

        if (!mkdir($directory, 0755, true) && !is_dir($directory)) {
            throw new RuntimeException('Nie udało się utworzyć katalogu: ' . $directory);
        }
    }

    private function getBackupDirectory(): string
    {
        return $this->modulePath . self::BACKUP_DIR;
    }

    private function getPurchaseOrderUploadDirectory(): string
    {
        return $this->modulePath . self::PURCHASE_ORDER_UPLOAD_DIR;
    }

    private function formatBytes(int $bytes): string
    {
        if ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 2, ',', ' ') . ' MB';
        }

        if ($bytes >= 1024) {
            return number_format($bytes / 1024, 2, ',', ' ') . ' KB';
        }

        return $bytes . ' B';
    }

    private function assertZipAvailable(): void
    {
        if (!class_exists('ZipArchive')) {
            throw new RuntimeException('Rozszerzenie PHP ZipArchive jest wymagane do obsługi kopii zapasowych.');
        }
    }
}
