<?php
/**
 * CargoStock Manager module.
 *
 * @author    Prestino
 * @copyright 2026 Prestino
 * @license   Commercial
 */
if (!defined('_PS_VERSION_')) {
    exit;
}
