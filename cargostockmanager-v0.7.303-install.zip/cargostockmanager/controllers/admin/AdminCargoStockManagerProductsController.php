<?php
/**
 * CargoStock Manager module.
 *
 * @author    Prestino
 * @copyright 2026 Prestino
 * @license   Commercial
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/AdminCargoStockManagerController.php';

class AdminCargoStockManagerProductsController extends AdminCargoStockManagerController
{
    public function initContent(): void
    {
        if (!Tools::getIsset('ajax') && !Tools::getIsset('exportPdf') && !Tools::getIsset('downloadProductLabel')) {
            Tools::redirectAdmin($this->context->link->getAdminLink('AdminCargoStockManager', true));
        }

        parent::initContent();
    }
}
