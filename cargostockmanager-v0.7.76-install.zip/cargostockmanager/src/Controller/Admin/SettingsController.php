<?php
declare(strict_types=1);

namespace PrestaShop\Module\CargoStockManager\Controller\Admin;

require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerService.php';
require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerLicense.php';

use PrestaShopBundle\Security\Annotation\AdminSecurity;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class SettingsController extends AbstractInventoryController
{
    /**
     * @AdminSecurity("is_granted('read', request.get('_legacy_controller'))")
     */
    public function indexAction(Request $request): Response
    {
        $module = \Module::getInstanceByName('cargostockmanager');
        $context = \Context::getContext();
        $service = new \CargoStockManagerService($module->getLocalPath(), $context, $module);
        $messages = [];
        $errors = [];

        if ($module instanceof \CargoStockManager) {
            $module->ensureTabsAvailable();
        }

        $licenseStatus = $this->getModuleLicenseStatus();

        if (!($licenseStatus['valid'] ?? false) && $request->isMethod('POST')) {
            $errors[] = (string) ($licenseStatus['message'] ?? $this->translate('license_missing_message'));
        }

        if (($licenseStatus['valid'] ?? false) && $request->isMethod('POST') && \Tools::isSubmit('submitCargoStockManagerRestoreHidden')) {
            try {
                $service->unhideProduct((int) \Tools::getValue('id_product'));
                $messages[] = $this->translate('product_restored');
            } catch (\Throwable $e) {
                $errors[] = $this->translate('product_restore_error');
                if (\defined('_PS_MODE_DEV_') && _PS_MODE_DEV_) {
                    $errors[] = $e->getMessage();
                }
            }
        }

        if (($licenseStatus['valid'] ?? false) && $request->isMethod('POST') && \Tools::isSubmit('submitCargoStockManagerSaveOrderSettings')) {
            try {
                $postedStatuses = \Tools::getValue('cargoStockManagerOrderStatuses', []);
                $service->savePurchaseOrderSettings(
                    (string) \Tools::getValue('cargoStockManagerDeliveryAddress', ''),
                    is_array($postedStatuses) ? $postedStatuses : []
                );
                $messages[] = 'Ustawienia zamówień zostały zapisane.';
            } catch (\Throwable $e) {
                $errors[] = 'Nie udało się zapisać ustawień zamówień.';
                if (\defined('_PS_MODE_DEV_') && _PS_MODE_DEV_) {
                    $errors[] = $e->getMessage();
                }
            }
        }

        $licenseDetails = is_array($licenseStatus['details'] ?? null) ? $licenseStatus['details'] : [];
        $licensePayload = is_array($licenseDetails['payload'] ?? null) ? $licenseDetails['payload'] : [];
        $licenseCustomer = trim((string) ($licensePayload['customer'] ?? ''));
        $licenseDomain = trim((string) ($licenseDetails['domain'] ?? $licensePayload['domain'] ?? ''));
        $licenseExpiresAt = trim((string) ($licenseDetails['expires_at'] ?? $licensePayload['expires_at'] ?? ''));

        return $this->renderInventoryPage(
            '@Modules/cargostockmanager/views/templates/admin-modern/settings.html.twig',
            'cargo_stock_manager_settings',
            'settings_tab',
            [
                'settingsUrl' => $this->generateUrl('cargo_stock_manager_settings'),
                'ignoredProducts' => $service->getIgnoredProducts(),
                'moduleVersionValue' => (string) $module->version,
                'licenseStatus' => $licenseStatus,
                'licenseSummary' => [
                    'customer' => $licenseCustomer !== '' ? $licenseCustomer : '—',
                    'domain' => $licenseDomain !== '' ? $licenseDomain : '—',
                    'expires_at' => $licenseExpiresAt !== '' ? $licenseExpiresAt : '—',
                ],
                'messages' => $messages,
                'errors' => $errors,
                'deliveryAddress' => $service->getConfiguredDeliveryAddress(),
                'orderStatuses' => $service->getConfiguredPurchaseOrderStatuses(),
                'carriers' => $service->getCarriers(),
                'documentTypes' => $service->getDocumentTypes(),
                'incotermOptions' => $service->getPurchaseOrderIncotermOptions(),
                'ajaxUrl' => $context->link->getAdminLink('AdminCargoStockManagerProducts', true, [], ['ajax' => 1]),
            ]
        );
    }
}
