<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_7_247(Module $module): bool
{
    return true;
}
