<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_7_258($module)
{
    return true;
}
