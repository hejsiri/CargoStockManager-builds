<?php
/**
 * CargoStock Manager module.
 *
 * @author    Prestino
 * @copyright 2026 Prestino
 * @license   Commercial
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/CargoStockManagerI18n.php';
require_once __DIR__ . '/CargoStockManagerLicense.php';

class CargoStockManagerUpdater
{
    private const LICENSE_PUBLIC_KEY_FILE = 'keys/license_public.pem';
    private const PRESTINO_API_URL = 'https://www.prestino.pl/prestino-update.php';
    public const CONFIG_PRESTINO_BUILD = 'CSMGR_PRESTINO_BUILD';
    private const RUNTIME_VERSION_CONFIG = 'CSMGR_RUNTIME_VERSION';

    private string $modulePath;
    private Module $module;
    private CargoStockManagerLicense $license;
    private ?array $cachedStatus = null;

    public function __construct(string $modulePath, Module $module)
    {
        $this->modulePath = rtrim($modulePath, '/') . '/';
        $this->module = $module;
        $this->license = new CargoStockManagerLicense($modulePath, Context::getContext(), $module);
    }

    public function checkForUpdates(): array
    {
        if ($this->cachedStatus !== null) {
            return $this->cachedStatus;
        }

        $response = $this->requestPrestinoApi('check');
        $data = json_decode((string) $response['body'], true);
        if (!is_array($data) || empty($data['status']) || empty($data['manifest'])) {
            throw new RuntimeException((string) ($data['message'] ?? CargoStockManagerI18n::translate($this->module, 'update_check_error_message')));
        }
        $payload = $this->verifyPrestinoManifest((string) $data['manifest'], 'prestino_update_check');
        $currentVersion = (string) ($payload['installed_version'] ?? $this->resolveCurrentVersion());

        $status = [
            'configured' => true,
            'available' => !empty($payload['available']),
            'updates_allowed' => !empty($payload['updates_allowed']),
            'current_version' => $currentVersion,
            'version' => (string) ($payload['latest_version'] ?? ''),
            'installed_build' => (int) ($payload['installed_build'] ?? $this->getInstalledBuild()),
            'latest_build' => (int) ($payload['latest_build'] ?? 0),
            'updates_until' => (string) ($payload['updates_until'] ?? ''),
        ];

        $this->cachedStatus = $status;

        return $status;
    }

    public function installAvailableUpdate(): array
    {
        $status = $this->checkForUpdates();
        if (empty($status['available'])) {
            throw new RuntimeException(CargoStockManagerI18n::translate($this->module, 'update_check_error_message'));
        }
        if (empty($status['updates_allowed'])) {
            throw new RuntimeException('Okres dostępu do aktualizacji wygasł.');
        }

        $temporary = tempnam(sys_get_temp_dir(), 'csmgr-prestino-update-');
        if ($temporary === false) {
            throw new RuntimeException(CargoStockManagerI18n::translate($this->module, 'update_install_error_message'));
        }
        $zipPath = $temporary . '.zip';
        @unlink($temporary);
        $backupPath = '';
        $installedVersion = $this->resolveCurrentVersion();
        $installedBuild = $this->getInstalledBuild();

        try {
            $response = $this->requestPrestinoApi('download', $zipPath);
            $manifest = (string) ($response['headers']['x-prestino-update-manifest'] ?? '');
            $payload = $this->verifyPrestinoManifest($manifest, 'prestino_update_download');
            $expectedHash = strtolower((string) ($payload['sha256'] ?? ''));
            $actualHash = strtolower((string) hash_file('sha256', $zipPath));
            if ($expectedHash === '' || !hash_equals($expectedHash, $actualHash)) {
                throw new RuntimeException('Suma kontrolna paczki aktualizacyjnej jest nieprawidłowa.');
            }

            $newVersion = (string) ($payload['version'] ?? '');
            $newBuild = (int) ($payload['build'] ?? 0);
            $this->validatePrestinoPackage($zipPath, $newVersion, $newBuild);
            $backupPath = $this->createModuleBackup();
            $this->extractPrestinoPackage($zipPath);

            if (version_compare($newVersion, $installedVersion, '<')) {
                throw new RuntimeException('Serwer aktualizacji zwrócił starszą wersję modułu.');
            }
            if (version_compare($newVersion, $installedVersion, '>')) {
                $this->module->version = $newVersion;
                $this->module->database_version = $installedVersion;
                if (Module::initUpgradeModule($this->module)) {
                    $upgrade = $this->module->runUpgradeModule();
                    if (empty($upgrade['success']) || !empty($upgrade['number_upgrade_left'])) {
                        throw new RuntimeException('PrestaShop nie zdołał zakończyć migracji modułu.');
                    }
                }
            }

            $this->runPrestinoMigrations($installedBuild, $newBuild);
            if (!Configuration::updateValue(self::CONFIG_PRESTINO_BUILD, $newBuild)
                || !Configuration::updateValue(self::RUNTIME_VERSION_CONFIG, $newVersion)
                || !Module::upgradeModuleVersion($this->module->name, $newVersion)
            ) {
                throw new RuntimeException('PrestaShop nie zdołał zapisać nowej wersji modułu.');
            }

            if (function_exists('opcache_reset')) {
                opcache_reset();
            }
            $this->clearRuntimeCaches();
            $this->cachedStatus = null;

            return ['ok' => true, 'version' => $newVersion, 'build' => $newBuild, 'backup' => $backupPath];
        } catch (Throwable $e) {
            if ($backupPath !== '') {
                $this->restoreModuleBackup($backupPath);
                Configuration::updateValue(self::CONFIG_PRESTINO_BUILD, $installedBuild);
                Configuration::updateValue(self::RUNTIME_VERSION_CONFIG, $installedVersion);
                Module::upgradeModuleVersion($this->module->name, $installedVersion);
            }
            throw $e;
        } finally {
            @unlink($zipPath);
        }
    }

    private function requestPrestinoApi(string $action, string $targetPath = ''): array
    {
        if (!function_exists('curl_init')) {
            throw new RuntimeException('Serwer nie udostępnia biblioteki cURL wymaganej do aktualizacji.');
        }

        $licenseStatus = $this->license->getStatus();
        if (empty($licenseStatus['valid'])) {
            throw new RuntimeException('Aktualizacja wymaga prawidłowej licencji Prestino.');
        }
        $token = $this->license->getLicenseKey();
        if ($token === '') {
            throw new RuntimeException('Nie można odczytać licencji modułu.');
        }

        $headers = [];
        $handle = curl_init(self::PRESTINO_API_URL);
        $file = null;
        if ($handle === false) {
            throw new RuntimeException('Nie udało się połączyć z serwerem aktualizacji.');
        }

        try {
            curl_setopt_array($handle, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => http_build_query([
                    'update_action' => $action,
                    'license_token' => $token,
                    'module' => $this->module->name,
                    'version' => $this->resolveCurrentVersion(),
                    'build' => $this->getInstalledBuild(),
                    'domain' => $this->currentDomain(),
                    'prestashop_version' => _PS_VERSION_,
                    'php_version' => PHP_VERSION,
                ]),
                CURLOPT_CONNECTTIMEOUT => 8,
                CURLOPT_TIMEOUT => $action === 'download' ? 120 : 15,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_USERAGENT => 'CargoStockManagerPrestinoUpdater/' . $this->resolveCurrentVersion(),
                CURLOPT_HEADERFUNCTION => static function ($curl, string $header) use (&$headers): int {
                    $length = strlen($header);
                    $parts = explode(':', $header, 2);
                    if (count($parts) === 2) {
                        $headers[strtolower(trim($parts[0]))] = trim($parts[1]);
                    }

                    return $length;
                },
            ]);

            if ($targetPath !== '') {
                $file = fopen($targetPath, 'wb');
                if ($file === false) {
                    throw new RuntimeException('Nie można zapisać pobieranej aktualizacji.');
                }
                curl_setopt($handle, CURLOPT_FILE, $file);
                $body = '';
            } else {
                curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
                $body = '';
            }

            $executed = curl_exec($handle);
            if ($executed === false) {
                throw new RuntimeException('Błąd połączenia z serwerem aktualizacji: ' . curl_error($handle));
            }
            if ($targetPath === '') {
                $body = (string) $executed;
            }

            $status = (int) curl_getinfo($handle, CURLINFO_HTTP_CODE);
            if ($status !== 200) {
                if ($file !== null) {
                    fclose($file);
                    $file = null;
                    $body = is_file($targetPath) ? (string) file_get_contents($targetPath) : '';
                }
                $error = json_decode($body, true);
                throw new RuntimeException((string) ($error['message'] ?? 'Serwer aktualizacji odrzucił żądanie.'));
            }

            return ['body' => $body, 'headers' => $headers];
        } finally {
            if (is_resource($file)) {
                fclose($file);
            }
            curl_close($handle);
        }
    }

    private function verifyPrestinoManifest(string $token, string $expectedType): array
    {
        $parts = explode('.', trim($token), 2);
        if (count($parts) !== 2) {
            throw new RuntimeException('Brak podpisu odpowiedzi serwera aktualizacji.');
        }

        $payloadJson = $this->base64UrlDecode($parts[0]);
        $signature = $this->base64UrlDecode($parts[1]);
        $payload = json_decode($payloadJson, true);
        $keyPath = $this->modulePath . self::LICENSE_PUBLIC_KEY_FILE;
        if (!is_array($payload) || $signature === '' || !is_readable($keyPath)
            || openssl_verify($parts[0], $signature, (string) file_get_contents($keyPath), OPENSSL_ALGO_SHA256) !== 1
        ) {
            throw new RuntimeException('Podpis odpowiedzi serwera aktualizacji jest nieprawidłowy.');
        }

        $licenseDetails = $this->license->getStatus()['details'] ?? [];
        if (($payload['type'] ?? '') !== $expectedType
            || ($payload['module'] ?? '') !== $this->module->name
            || ($payload['license_id'] ?? '') !== ($licenseDetails['license_id'] ?? '')
            || (int) ($payload['expires_at'] ?? 0) < time()
        ) {
            throw new RuntimeException('Odpowiedź serwera aktualizacji nie pasuje do tej licencji.');
        }

        return $payload;
    }

    private function validatePrestinoPackage(string $path, string $version, int $build): void
    {
        $zip = new ZipArchive();
        if ($zip->open($path) !== true) {
            throw new RuntimeException('Pobrana paczka aktualizacyjna jest uszkodzona.');
        }

        try {
            for ($index = 0; $index < $zip->numFiles; ++$index) {
                $entry = (string) $zip->getNameIndex($index);
                if ($entry === '' || strpos($entry, "\0") !== false || strpos($entry, '\\') !== false
                    || strpos($entry, '/') === 0 || strpos('/' . $entry, '/../') !== false
                    || strpos($entry, $this->module->name . '/') !== 0
                ) {
                    throw new RuntimeException('Paczka aktualizacyjna zawiera niedozwoloną ścieżkę.');
                }
            }

            $mainFile = $zip->getFromName($this->module->name . '/' . $this->module->name . '.php');
            $configXml = $zip->getFromName($this->module->name . '/config.xml');
            if (!is_string($configXml)) {
                $configXml = $zip->getFromName($this->module->name . '/config_pl.xml');
            }
            if (!is_string($mainFile) || !is_string($configXml)
                || !preg_match('~<version><!\\[CDATA\\[([^]]+)]]></version>~', $configXml, $matches)
                || (string) $matches[1] !== $version
                || $zip->locateName($this->module->name . '/license.php') === false
            ) {
                throw new RuntimeException('Paczka nie zawiera oczekiwanej wersji licencjonowanego modułu.');
            }

            $releaseJson = $zip->getFromName($this->module->name . '/prestino-release.json');
            if (is_string($releaseJson)) {
                $release = json_decode($releaseJson, true);
                if (!is_array($release)
                    || (string) ($release['upstream_version'] ?? '') !== $version
                    || (int) ($release['prestino_build'] ?? 0) !== $build
                ) {
                    throw new RuntimeException('Metadane paczki aktualizacyjnej są nieprawidłowe.');
                }
            }
        } finally {
            $zip->close();
        }
    }

    private function createModuleBackup(): string
    {
        $directory = _PS_ROOT_DIR_ . '/var/backups/prestino-modules';
        if (!is_dir($directory) && !@mkdir($directory, 0750, true) && !is_dir($directory)) {
            throw new RuntimeException('Nie udało się utworzyć katalogu kopii bezpieczeństwa.');
        }

        $path = $directory . '/' . $this->module->name . '-' . date('Ymd-His') . '.zip';
        $zip = new ZipArchive();
        if ($zip->open($path, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            throw new RuntimeException('Nie udało się utworzyć kopii bezpieczeństwa modułu.');
        }

        $source = rtrim($this->modulePath, '/\\');
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($source, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($iterator as $item) {
            $relative = $this->module->name . '/' . substr($item->getPathname(), strlen($source) + 1);
            if ($item->isDir()) {
                $zip->addEmptyDir($relative);
            } elseif ($item->isFile()) {
                $zip->addFile($item->getPathname(), $relative);
            }
        }
        $zip->close();

        return $path;
    }

    private function extractPrestinoPackage(string $path): void
    {
        $zip = new ZipArchive();
        if ($zip->open($path) !== true) {
            throw new RuntimeException('Nie udało się rozpakować zweryfikowanej aktualizacji modułu.');
        }

        try {
            // ZipArchive::extractTo() does not reliably overwrite every existing
            // module file on all hosting filesystems. The package was validated
            // before the backup was created, so remove only its regular files
            // and let extraction recreate them with the current contents.
            for ($index = 0; $index < $zip->numFiles; ++$index) {
                $entry = (string) $zip->getNameIndex($index);
                if ($entry === '' || substr($entry, -1) === '/') {
                    continue;
                }

                $destination = rtrim(_PS_MODULE_DIR_, '/\\') . DIRECTORY_SEPARATOR
                    . str_replace('/', DIRECTORY_SEPARATOR, $entry);
                if ((is_file($destination) || is_link($destination)) && !@unlink($destination)) {
                    throw new RuntimeException('Nie udało się zastąpić pliku modułu: ' . $entry);
                }
            }

            if (!$zip->extractTo(_PS_MODULE_DIR_)) {
                throw new RuntimeException('Nie udało się rozpakować zweryfikowanej aktualizacji modułu.');
            }
        } finally {
            $zip->close();
        }
    }

    private function runPrestinoMigrations(int $fromBuild, int $toBuild): void
    {
        if ($toBuild <= $fromBuild) {
            return;
        }

        $files = glob($this->modulePath . 'upgrade/prestino/upgrade-*.php') ?: [];
        $migrations = [];
        foreach ($files as $file) {
            if (preg_match('/upgrade-(\\d+)\\.php$/', $file, $matches) === 1) {
                $build = (int) $matches[1];
                if ($build > $fromBuild && $build <= $toBuild) {
                    $migrations[$build] = $file;
                }
            }
        }
        ksort($migrations, SORT_NUMERIC);
        foreach ($migrations as $build => $file) {
            require_once $file;
            $function = 'upgrade_cargostockmanager_prestino_' . $build;
            if (!is_callable($function) || !$function($this->module)) {
                throw new RuntimeException('Nie udało się wykonać migracji aktualizacji ' . $build . '.');
            }
        }
    }

    private function restoreModuleBackup(string $path): void
    {
        $zip = new ZipArchive();
        if ($zip->open($path) === true) {
            $zip->extractTo(_PS_MODULE_DIR_);
            $zip->close();
        }
    }

    private function getInstalledBuild(): int
    {
        return max(0, (int) Configuration::get(self::CONFIG_PRESTINO_BUILD));
    }

    private function currentDomain(): string
    {
        $context = Context::getContext();
        if (isset($context->shop) && method_exists($context->shop, 'getBaseURL')) {
            $host = parse_url((string) $context->shop->getBaseURL(true), PHP_URL_HOST);
            if (is_string($host)) {
                return $host;
            }
        }

        return (string) ($_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME'] ?? '');
    }

    private function base64UrlDecode(string $value): string
    {
        $value = strtr($value, '-_', '+/');
        $decoded = base64_decode($value . str_repeat('=', (4 - strlen($value) % 4) % 4), true);

        return is_string($decoded) ? $decoded : '';
    }

    private function clearRuntimeCaches(): void
    {
        try {
            if (class_exists('Tools')) {
                if (method_exists('Tools', 'clearSmartyCache')) {
                    Tools::clearSmartyCache();
                }
                if (method_exists('Tools', 'clearXMLCache')) {
                    Tools::clearXMLCache();
                }
            }

            if (class_exists('Media') && method_exists('Media', 'clearCache')) {
                Media::clearCache();
            }

            if (class_exists('Cache') && method_exists('Cache', 'clean')) {
                Cache::clean('*');
            }
        } catch (Throwable $e) {
            // Cache refresh is best-effort; the update itself must remain usable.
        }
    }

    private function resolveCurrentVersion(): string
    {
        $dbVersion = (string) Db::getInstance()->getValue(
            'SELECT `version` FROM `' . _DB_PREFIX_ . 'module` WHERE `name` = \'' . pSQL($this->module->name) . '\''
        );

        return $dbVersion !== '' ? $dbVersion : (string) $this->module->version;
    }

}
