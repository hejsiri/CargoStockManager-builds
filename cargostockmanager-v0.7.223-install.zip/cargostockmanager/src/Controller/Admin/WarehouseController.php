<?php
declare(strict_types=1);

namespace PrestaShop\Module\CargoStockManager\Controller\Admin;

require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerService.php';
require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerLicense.php';
require_once dirname(__DIR__, 3) . '/classes/CargoStockManagerUpdater.php';

use PrestaShopBundle\Security\Annotation\AdminSecurity;
use Symfony\Component\HttpFoundation\Response;

class WarehouseController extends AbstractInventoryController
{
    public const TAB_CLASS_NAME = 'AdminCargoStockManager';

    /**
     * @AdminSecurity("is_granted('read', request.get('_legacy_controller'))")
     */
    public function indexAction(): Response
    {
        $module = \Module::getInstanceByName('cargostockmanager');
        $context = \Context::getContext();
        $service = new \CargoStockManagerService($module->getLocalPath(), $context, $module);
        $updaterService = new \CargoStockManagerUpdater($module->getLocalPath(), $context, $module);

        if ($module instanceof \CargoStockManager) {
            $module->ensureTabsAvailable();
        }

        $translations = $service->getTranslations();
        $licenseStatus = $this->getModuleLicenseStatus();
        $assetsVersion = $module instanceof \CargoStockManager
            ? $module->getAssetVersion('views/js/chart.umd.min.js')
            : (string) $module->version;

        $context->smarty->assign([
            'inventoryCatalogUrl' => $context->link->getAdminLink('AdminProducts', true),
            'inventoryModuleUrl' => $context->link->getAdminLink('AdminCargoStockManager', true),
            'inventoryStatisticsUrl' => $context->link->getAdminLink('AdminCargoStockManagerStatistics', true),
            'inventorySuppliersUrl' => $context->link->getAdminLink('AdminCargoStockManagerSuppliers', true),
            'inventoryPurchaseOrdersUrl' => $context->link->getAdminLink('AdminCargoStockManagerPurchaseOrders', true),
            'inventoryModuleBaseUrl' => $module->getPathUri(),
            'inventoryAjaxUrl' => $context->link->getAdminLink('AdminCargoStockManager', true, [], [
                'ajax' => 1,
            ]),
            'inventoryExportUrl' => $context->link->getAdminLink('AdminCargoStockManager', true, [], [
                'exportPdf' => 1,
            ]),
            'inventoryConfigUrl' => $context->link->getAdminLink('AdminCargoStockManagerSettings', true),
            'inventoryLanguageIso' => (string) $context->language->iso_code,
            'inventoryCanEdit' => true,
            'inventoryTranslations' => $translations,
            'inventoryTranslationsJson' => json_encode($translations, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'inventoryModuleVersion' => (string) $module->version,
            'inventoryAssetsVersion' => $assetsVersion,
            'inventoryLicenseStatus' => $licenseStatus,
            'inventoryUpdateConfigured' => $updaterService->isConfigured(),
            'inventoryUpdateChannel' => $updaterService->getConfiguredChannel(),
            'inventoryEmbeddedInModernLayout' => true,
        ]);

        $legacyContent = '';
        if ($licenseStatus['valid'] ?? false) {
            $legacyContent = $module->display(
                $module->getLocalPath() . $module->name . '.php',
                'views/templates/admin/app.tpl'
            );
        }

        return $this->renderInventoryPage(
            '@Modules/cargostockmanager/views/templates/admin-modern/warehouse.html.twig',
            'cargo_stock_manager_products',
            'products_tab',
            [
                'legacyContent' => $legacyContent,
            ]
        );
    }
}
