Zmniejszenie wysokości paska zakładek BO o 6 px w nowoczesnym layoucie modułu.
