<?php
/**
 * CargoStock Manager module.
 *
 * @author    Prestino
 * @copyright 2026 Prestino
 * @license   Commercial
 */
require_once __DIR__ . '/classes/CargoStockManagerI18n.php';
require_once __DIR__ . '/classes/CargoStockManagerService.php';
require_once __DIR__ . '/classes/CargoStockManagerLicense.php';
require_once __DIR__ . '/classes/CargoStockManagerUpdater.php';

if (!defined('_PS_VERSION_')) {
    exit;
}

class cargostockmanager extends Module
{
    private const ADMIN_TAB_CLASS_NAME = 'AdminCargoStockManager';
    private const PRODUCTS_TAB_CLASS_NAME = 'AdminCargoStockManagerProducts';
    private const STATISTICS_TAB_CLASS_NAME = 'AdminCargoStockManagerStatistics';
    private const SUPPLIERS_TAB_CLASS_NAME = 'AdminCargoStockManagerSuppliers';
    private const PURCHASE_ORDERS_TAB_CLASS_NAME = 'AdminCargoStockManagerPurchaseOrders';
    private const SETTINGS_TAB_CLASS_NAME = 'AdminCargoStockManagerSettings';
    private const HELP_TAB_CLASS_NAME = 'AdminCargoStockManagerHelp';
    private const RUNTIME_VERSION_CONFIG = 'CSMGR_RUNTIME_VERSION';
    private const MAIN_TAB_ICON = 'directions_boat';

    public function __construct()
    {
        $this->name = 'cargostockmanager';
        $this->tab = 'administration';
        $this->version = '0.7.267';
        $this->author = 'Prestino';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->trans('CargoStock Manager', [], 'Modules.Cargostockmanager.Admin');
        $this->description = $this->trans('Back Office inventory view with purchase price editing and PDF export.', [], 'Modules.Cargostockmanager.Admin');
        $this->ps_versions_compliancy = ['min' => '8.2.0', 'max' => _PS_VERSION_];
    }

    public function install(): bool
    {
        $defaultIgnoredIds = '';
        $ignoreFilePath = __DIR__ . '/ignore.txt';
        if (is_file($ignoreFilePath)) {
            $defaultIgnoredIds = trim((string) file_get_contents($ignoreFilePath));
        }

        if (!parent::install()) {
            return false;
        }

        if (!$this->registerHook('displayBackOfficeHeader') || !$this->installTabs()) {
            parent::uninstall();

            return false;
        }

        $context = $this->context;
        $service = new CargoStockManagerService($this->getLocalPath(), $context, $this);
        $service->ensurePurchaseOrderInfrastructure();
        Configuration::updateValue(self::RUNTIME_VERSION_CONFIG, (string) $this->version);
        Configuration::updateValue(CargoStockManagerUpdater::CONFIG_UPDATE_CHANNEL, CargoStockManagerUpdater::UPDATE_CHANNEL_PUBLIC);

        if ($defaultIgnoredIds !== '') {
            Configuration::updateValue(CargoStockManagerService::CONFIG_IGNORED_IDS, $defaultIgnoredIds);
        }

        return true;
    }

    public function uninstall(): bool
    {
        Configuration::deleteByName(CargoStockManagerService::CONFIG_IGNORED_IDS);
        Configuration::deleteByName(CargoStockManagerService::CONFIG_PURCHASE_DELIVERY_ADDRESS);
        Configuration::deleteByName(CargoStockManagerService::CONFIG_PURCHASE_ACCOUNTING_EMAIL);
        Configuration::deleteByName(CargoStockManagerService::CONFIG_PURCHASE_ORDER_STATUSES);
        Configuration::deleteByName(CargoStockManagerService::CONFIG_PURCHASE_ORDER_MENU_BADGE_STATUS);
        Configuration::deleteByName(CargoStockManagerUpdater::CONFIG_UPDATE_CHANNEL);
        Configuration::deleteByName(self::RUNTIME_VERSION_CONFIG);

        return $this->uninstallTabs() && parent::uninstall();
    }

    public function getContent(): string
    {
        $this->ensureModuleRuntimeReady();
        $this->ensureTabsAvailable();

        $settingsUrl = $this->context->link->getAdminLink(self::SETTINGS_TAB_CLASS_NAME, true);
        Tools::redirectAdmin($settingsUrl);

        return '';
    }

    public function ensureTabsAvailable(): void
    {
        if (!$this->isRegisteredInHook('displayBackOfficeHeader')) {
            $this->registerHook('displayBackOfficeHeader');
        }

        $this->installTabs();
    }

    public function ensureModuleRuntimeReady(): void
    {
        $service = new CargoStockManagerService($this->getLocalPath(), $this->context, $this);
        $service->ensurePurchaseOrderInfrastructure();
        if (!$this->isRegisteredInHook('displayBackOfficeHeader')) {
            $this->registerHook('displayBackOfficeHeader');
        }

        $storedVersion = (string) Configuration::get(self::RUNTIME_VERSION_CONFIG);
        if ($storedVersion === (string) $this->version) {
            return;
        }

        Configuration::updateValue(self::RUNTIME_VERSION_CONFIG, (string) $this->version);
    }

    public function isUsingNewTranslationSystem(): bool
    {
        return true;
    }

    public function transModule(string $message, array $parameters = []): string
    {
        return $this->trans($message, $parameters, CargoStockManagerI18n::DOMAIN);
    }

    public function getAssetVersion(string $relativePath = ''): string
    {
        $baseVersion = (string) $this->version;
        $relativePath = ltrim($relativePath, '/');
        if ($relativePath === '') {
            return $baseVersion;
        }

        $fullPath = $this->getLocalPath() . $relativePath;
        if (!is_file($fullPath)) {
            return $baseVersion;
        }

        $mtime = @filemtime($fullPath);
        if ($mtime === false) {
            return $baseVersion;
        }

        return $baseVersion . '-' . (string) $mtime;
    }

    public function hookDisplayBackOfficeHeader(array $params): string
    {
        try {
            $context = $this->context;
            $service = new CargoStockManagerService($this->getLocalPath(), $context, $this);
            $badges = $service->getPurchaseOrderMenuBadges();
        } catch (Throwable $e) {
            return '';
        }

        $payload = json_encode([
            'badges' => $badges,
            'tabId' => 'subtab-' . self::PURCHASE_ORDERS_TAB_CLASS_NAME,
            'controller' => self::PURCHASE_ORDERS_TAB_CLASS_NAME,
            'label' => CargoStockManagerI18n::translate($this, 'purchase_orders_tab'),
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($payload === false) {
            return '';
        }

        $this->context->smarty->assign([
            'csmgrMenuBadgeConfig' => $payload,
        ]);

        return $this->fetch('module:' . $this->name . '/views/templates/hook/back_office_header.tpl');
    }

    public function getTranslationCatalogue(): array
    {
        return [
            'products_tab' => $this->trans('Products', [], CargoStockManagerI18n::DOMAIN),
            'suppliers_tab' => $this->trans('Suppliers', [], CargoStockManagerI18n::DOMAIN),
            'purchase_orders_tab' => $this->trans('Purchase orders', [], CargoStockManagerI18n::DOMAIN),
            'settings_tab' => $this->trans('Settings', [], CargoStockManagerI18n::DOMAIN),
            'inventory_report' => $this->trans('CargoStock Manager', [], CargoStockManagerI18n::DOMAIN),
            'new_products_view_scaffold' => $this->trans('New Products view scaffold for the Inventory module.', [], CargoStockManagerI18n::DOMAIN),
            'new_suppliers_view_scaffold' => $this->trans('New Suppliers view scaffold for the Inventory module.', [], CargoStockManagerI18n::DOMAIN),
            'new_purchase_orders_view_scaffold' => $this->trans('New Purchase orders view scaffold for the Inventory module.', [], CargoStockManagerI18n::DOMAIN),
            'new_settings_view_scaffold' => $this->trans('New Settings view scaffold for the Inventory module.', [], CargoStockManagerI18n::DOMAIN),
            'products_migration_notice' => $this->trans('This tab will become the new place for the inventory table after the migration to the PrestaShop 8.2+ / 9.x compatible architecture is completed.', [], CargoStockManagerI18n::DOMAIN),
            'suppliers_migration_notice' => $this->trans('This tab will become the new place for suppliers management after the migration is completed.', [], CargoStockManagerI18n::DOMAIN),
            'purchase_orders_migration_notice' => $this->trans('This tab will become the new place for purchase orders after the migration is completed.', [], CargoStockManagerI18n::DOMAIN),
            'settings_migration_notice' => $this->trans('This tab will become the new place for hidden products configuration and module settings after the migration is completed.', [], CargoStockManagerI18n::DOMAIN),
            'suppliers_empty' => $this->trans('No suppliers found.', [], CargoStockManagerI18n::DOMAIN),
            'supplier_products_count' => $this->trans('Products', [], CargoStockManagerI18n::DOMAIN),
            'supplier_open_native' => $this->trans('Open in PrestaShop', [], CargoStockManagerI18n::DOMAIN),
            'supplier_panel_note' => $this->trans('This list uses the default suppliers configured in PrestaShop.', [], CargoStockManagerI18n::DOMAIN),
            'supplier_add_button' => $this->trans('Add supplier', [], CargoStockManagerI18n::DOMAIN),
            'supplier_form_new_title' => $this->trans('New supplier', [], CargoStockManagerI18n::DOMAIN),
            'supplier_form_edit_title' => $this->trans('Edit supplier', [], CargoStockManagerI18n::DOMAIN),
            'supplier_description' => $this->trans('Description', [], CargoStockManagerI18n::DOMAIN),
            'supplier_edit_button' => $this->trans('Edit', [], CargoStockManagerI18n::DOMAIN),
            'supplier_back_to_list' => $this->trans('Back to list', [], CargoStockManagerI18n::DOMAIN),
            'supplier_created_message' => $this->trans('Supplier created.', [], CargoStockManagerI18n::DOMAIN),
            'supplier_updated_message' => $this->trans('Supplier updated.', [], CargoStockManagerI18n::DOMAIN),
            'supplier_deleted_message' => $this->trans('Supplier deleted.', [], CargoStockManagerI18n::DOMAIN),
            'supplier_save_error' => $this->trans('Could not save supplier.', [], CargoStockManagerI18n::DOMAIN),
            'supplier_delete_error' => $this->trans('Could not delete supplier.', [], CargoStockManagerI18n::DOMAIN),
            'supplier_delete_blocked' => $this->trans('Cannot delete supplier assigned to orders.', [], CargoStockManagerI18n::DOMAIN),
            'supplier_not_found' => $this->trans('Supplier not found.', [], CargoStockManagerI18n::DOMAIN),
            'purchase_orders_empty' => $this->trans('No purchase orders found.', [], CargoStockManagerI18n::DOMAIN),
            'purchase_order_number' => $this->trans('Order no.', [], CargoStockManagerI18n::DOMAIN),
            'purchase_order_supplier' => $this->trans('Supplier', [], CargoStockManagerI18n::DOMAIN),
            'purchase_order_date' => $this->trans('Order date', [], CargoStockManagerI18n::DOMAIN),
            'purchase_order_status' => $this->trans('Status', [], CargoStockManagerI18n::DOMAIN),
            'purchase_order_value' => $this->trans('Value', [], CargoStockManagerI18n::DOMAIN),
            'purchase_order_edit' => $this->trans('Edit', [], CargoStockManagerI18n::DOMAIN),
            'purchase_order_delete' => $this->trans('Delete', [], CargoStockManagerI18n::DOMAIN),
            'purchase_order_status_draft' => $this->trans('Draft', [], CargoStockManagerI18n::DOMAIN),
            'purchase_order_status_ordered' => $this->trans('Ordered', [], CargoStockManagerI18n::DOMAIN),
            'purchase_order_status_paid' => $this->trans('Paid', [], CargoStockManagerI18n::DOMAIN),
            'purchase_order_status_shipped' => $this->trans('Shipped', [], CargoStockManagerI18n::DOMAIN),
            'purchase_order_status_delivered' => $this->trans('Delivered', [], CargoStockManagerI18n::DOMAIN),
            'purchase_order_status_ready_for_accounting' => $this->trans('Ready for documents', [], CargoStockManagerI18n::DOMAIN),
            'purchase_order_status_finished' => $this->trans('Finished', [], CargoStockManagerI18n::DOMAIN),
            'purchase_order_status_sent' => $this->trans('Sent', [], CargoStockManagerI18n::DOMAIN),
            'purchase_order_status_confirmed' => $this->trans('Confirmed', [], CargoStockManagerI18n::DOMAIN),
            'purchase_order_status_completed' => $this->trans('Completed', [], CargoStockManagerI18n::DOMAIN),
            'created_at' => $this->trans('Created at', [], CargoStockManagerI18n::DOMAIN),
            'updated_at' => $this->trans('Updated at', [], CargoStockManagerI18n::DOMAIN),
            'phone' => $this->trans('Phone', [], CargoStockManagerI18n::DOMAIN),
            'email' => $this->trans('Email', [], CargoStockManagerI18n::DOMAIN),
            'address' => $this->trans('Address', [], CargoStockManagerI18n::DOMAIN),
            'address2' => $this->trans('Address (2)', [], CargoStockManagerI18n::DOMAIN),
            'postcode' => $this->trans('Postal code', [], CargoStockManagerI18n::DOMAIN),
            'city' => $this->trans('City', [], CargoStockManagerI18n::DOMAIN),
            'country' => $this->trans('Country', [], CargoStockManagerI18n::DOMAIN),
            'no_image' => $this->trans('None', [], CargoStockManagerI18n::DOMAIN),
            'no_data' => $this->trans('No data', [], CargoStockManagerI18n::DOMAIN),
            'combination_id' => $this->trans('Combination ID: %id%', ['%id%' => '{{ id }}'], CargoStockManagerI18n::DOMAIN),
            'actions' => $this->trans('Actions', [], CargoStockManagerI18n::DOMAIN),
            'hide_forever' => $this->trans('Hide permanently', [], CargoStockManagerI18n::DOMAIN),
            'total_purchase_value_net' => $this->trans('Total net purchase value:', [], CargoStockManagerI18n::DOMAIN),
            'total_retail_value_gross' => $this->trans('Total gross retail value:', [], CargoStockManagerI18n::DOMAIN),
            'no_results' => $this->trans('No results.', [], CargoStockManagerI18n::DOMAIN),
            'report_title' => $this->trans('Inventory status', [], CargoStockManagerI18n::DOMAIN),
            'show_only_active_products' => $this->trans('Show only active products', [], CargoStockManagerI18n::DOMAIN),
            'show_only_available_in_stock' => $this->trans('Show only available in stock', [], CargoStockManagerI18n::DOMAIN),
            'show_only_missing_purchase_price' => $this->trans('Show only with missing purchase price', [], CargoStockManagerI18n::DOMAIN),
            'show_product_weight' => $this->trans('Show product weight', [], CargoStockManagerI18n::DOMAIN),
            'show_only_missing_weight' => $this->trans('Show products without weight', [], CargoStockManagerI18n::DOMAIN),
            'show_retail_prices_gross' => $this->trans('Show retail gross prices', [], CargoStockManagerI18n::DOMAIN),
            'row_number' => $this->trans('No.', [], CargoStockManagerI18n::DOMAIN),
            'image' => $this->trans('Image', [], CargoStockManagerI18n::DOMAIN),
            'name' => $this->trans('Name', [], CargoStockManagerI18n::DOMAIN),
            'product_name' => $this->trans('Product name', [], CargoStockManagerI18n::DOMAIN),
            'product_weight' => $this->trans('Product weight', [], CargoStockManagerI18n::DOMAIN),
            'active' => $this->trans('Active', [], CargoStockManagerI18n::DOMAIN),
            'purchase_price_net' => $this->trans('Purchase price (net)', [], CargoStockManagerI18n::DOMAIN),
            'purchase_price_gross' => $this->trans('Purchase price (gross)', [], CargoStockManagerI18n::DOMAIN),
            'retail_price_gross' => $this->trans('Retail price (gross)', [], CargoStockManagerI18n::DOMAIN),
            'quantity' => $this->trans('Quantity', [], CargoStockManagerI18n::DOMAIN),
            'available_quantity' => $this->trans('Available quantity', [], CargoStockManagerI18n::DOMAIN),
            'purchase_value_net' => $this->trans('Purchase value (net)', [], CargoStockManagerI18n::DOMAIN),
            'retail_value_gross' => $this->trans('Retail value (gross)', [], CargoStockManagerI18n::DOMAIN),
            'products_per_page' => $this->trans('Products per page:', [], CargoStockManagerI18n::DOMAIN),
            'visible_range' => $this->trans('Showing %from%-%to% of %total% (page %page% / %total_pages%)', [
                '%from%' => '{{ from }}',
                '%to%' => '{{ to }}',
                '%total%' => '{{ total }}',
                '%page%' => '{{ page }}',
                '%total_pages%' => '{{ total_pages }}',
            ], CargoStockManagerI18n::DOMAIN),
            'current_page' => $this->trans('Current page', [], CargoStockManagerI18n::DOMAIN),
            'previous' => $this->trans('Previous', [], CargoStockManagerI18n::DOMAIN),
            'next' => $this->trans('Next', [], CargoStockManagerI18n::DOMAIN),
            'id' => $this->trans('ID', [], CargoStockManagerI18n::DOMAIN),
            'ean13' => $this->trans('EAN13', [], CargoStockManagerI18n::DOMAIN),
            'module_navigation' => $this->trans('Module navigation', [], CargoStockManagerI18n::DOMAIN),
            'filters' => $this->trans('Filters', [], CargoStockManagerI18n::DOMAIN),
            'clear' => $this->trans('Clear', [], CargoStockManagerI18n::DOMAIN),
            'search_placeholder' => $this->trans('Search table...', [], CargoStockManagerI18n::DOMAIN),
            'save' => $this->trans('Save', [], CargoStockManagerI18n::DOMAIN),
            'cancel' => $this->trans('Cancel', [], CargoStockManagerI18n::DOMAIN),
            'enter_qty' => $this->trans('e.g. 12', [], CargoStockManagerI18n::DOMAIN),
            'enter_price' => $this->trans('e.g. 12.34', [], CargoStockManagerI18n::DOMAIN),
            'enter_retail_price' => $this->trans('e.g. 99.99', [], CargoStockManagerI18n::DOMAIN),
            'enter_weight' => $this->trans('e.g. 1.250', [], CargoStockManagerI18n::DOMAIN),
            'error_save' => $this->trans('Save error', [], CargoStockManagerI18n::DOMAIN),
            'error_network' => $this->trans('Connection / server error while saving.', [], CargoStockManagerI18n::DOMAIN),
            'error_qty_save' => $this->trans('Could not save quantity.', [], CargoStockManagerI18n::DOMAIN),
            'error_weight_save' => $this->trans('Could not save weight.', [], CargoStockManagerI18n::DOMAIN),
            'error_hide' => $this->trans('Could not hide the product.', [], CargoStockManagerI18n::DOMAIN),
            'type_qty' => $this->trans('Enter an integer quantity.', [], CargoStockManagerI18n::DOMAIN),
            'type_price' => $this->trans('Enter a price.', [], CargoStockManagerI18n::DOMAIN),
            'type_weight' => $this->trans('Enter a valid weight.', [], CargoStockManagerI18n::DOMAIN),
            'error_toggle' => $this->trans('Could not change product status.', [], CargoStockManagerI18n::DOMAIN),
            'copied' => $this->trans('Copied', [], CargoStockManagerI18n::DOMAIN),
            'copy_error' => $this->trans('Could not copy EAN13.', [], CargoStockManagerI18n::DOMAIN),
            'load_error' => $this->trans('Loading error.', [], CargoStockManagerI18n::DOMAIN),
            'sales_chart' => $this->trans('Sales chart', [], CargoStockManagerI18n::DOMAIN),
            'profitability' => $this->trans('Profitability', [], CargoStockManagerI18n::DOMAIN),
            'store_price' => $this->trans('Store price', [], CargoStockManagerI18n::DOMAIN),
            'marketplace_price' => $this->trans('Marketplace price', [], CargoStockManagerI18n::DOMAIN),
            'store_channel' => $this->trans('Store', [], CargoStockManagerI18n::DOMAIN),
            'marketplace_channel' => $this->trans('Marketplace', [], CargoStockManagerI18n::DOMAIN),
            'profitability_markup' => $this->trans('Markup', [], CargoStockManagerI18n::DOMAIN),
            'profitability_margin' => $this->trans('Margin', [], CargoStockManagerI18n::DOMAIN),
            'profitability_profit' => $this->trans('Profit (net)', [], CargoStockManagerI18n::DOMAIN),
            'marketplace_markup' => $this->trans('Marketplace markup', [], CargoStockManagerI18n::DOMAIN),
            'marketplace_markup_description' => $this->trans('Enter the percentage value of how much higher the product price is on the marketplace compared to the store price.', [], CargoStockManagerI18n::DOMAIN),
            'marketplace_commission' => $this->trans('Marketplace commission', [], CargoStockManagerI18n::DOMAIN),
            'marketplace_commission_description' => $this->trans('Enter the percentage value of the total sales commission cost on the marketplace.', [], CargoStockManagerI18n::DOMAIN),
            'marketplace_settings' => $this->trans('Marketplace settings', [], CargoStockManagerI18n::DOMAIN),
            'license_required_title' => $this->trans('License required', [], CargoStockManagerI18n::DOMAIN),
            'license_missing_message' => $this->trans('The module requires a valid license key in the license.php file.', [], CargoStockManagerI18n::DOMAIN),
            'license_invalid_message' => $this->trans('The license key is invalid.', [], CargoStockManagerI18n::DOMAIN),
            'license_expired_message' => $this->trans('The license has expired.', [], CargoStockManagerI18n::DOMAIN),
            'license_domain_mismatch_message' => $this->trans('The license is not valid for this shop domain.', [], CargoStockManagerI18n::DOMAIN),
            'license_file_error_message' => $this->trans('The license file or public verification key could not be read.', [], CargoStockManagerI18n::DOMAIN),
            'update_available_button' => $this->trans('Update to %version%', ['%version%' => '{{ version }}'], CargoStockManagerI18n::DOMAIN),
            'update_checking_message' => $this->trans('Checking for updates...', [], CargoStockManagerI18n::DOMAIN),
            'update_installing_message' => $this->trans('Downloading and installing the update...', [], CargoStockManagerI18n::DOMAIN),
            'update_installed_message' => $this->trans('The module was updated. Refresh the page.', [], CargoStockManagerI18n::DOMAIN),
            'update_check_error_message' => $this->trans('Could not check for updates.', [], CargoStockManagerI18n::DOMAIN),
            'update_install_error_message' => $this->trans('Could not install the update.', [], CargoStockManagerI18n::DOMAIN),
            'enter_percentage' => $this->trans('e.g. 20', [], CargoStockManagerI18n::DOMAIN),
            'type_percentage' => $this->trans('Enter a valid percentage.', [], CargoStockManagerI18n::DOMAIN),
            'percent_short' => $this->trans('%', [], CargoStockManagerI18n::DOMAIN),
            'not_available' => $this->trans('—', [], CargoStockManagerI18n::DOMAIN),
            'sales_stats_title' => $this->trans('Monthly sales', [], CargoStockManagerI18n::DOMAIN),
            'sales_stats_loading' => $this->trans('Loading sales statistics...', [], CargoStockManagerI18n::DOMAIN),
            'sales_stats_empty' => $this->trans('No sales in selected period.', [], CargoStockManagerI18n::DOMAIN),
            'sales_months_range' => $this->trans('Last 12 months', [], CargoStockManagerI18n::DOMAIN),
            'sales_total_sold' => $this->trans('Total sold', [], CargoStockManagerI18n::DOMAIN),
            'sales_best_month' => $this->trans('Best month', [], CargoStockManagerI18n::DOMAIN),
            'sales_months_count' => $this->trans('Months', [], CargoStockManagerI18n::DOMAIN),
            'sales_units' => $this->trans('pcs', [], CargoStockManagerI18n::DOMAIN),
            'sales_revenue' => $this->trans('Wartość sprzedaży (brutto)', [], CargoStockManagerI18n::DOMAIN),
            'sales_revenue_short' => $this->trans('wartość sprzedaży (brutto)', [], CargoStockManagerI18n::DOMAIN),
            'sales_revenue_net' => $this->trans('Wartość sprzedaży (netto)', [], CargoStockManagerI18n::DOMAIN),
            'sales_revenue_net_short' => $this->trans('wartość sprzedaży (netto)', [], CargoStockManagerI18n::DOMAIN),
            'estimated_profit_net' => $this->trans('Szacowany zysk netto', [], CargoStockManagerI18n::DOMAIN),
            'estimated_profit_gross' => $this->trans('Szacowany zysk brutto', [], CargoStockManagerI18n::DOMAIN),
            'year' => $this->trans('Year', [], CargoStockManagerI18n::DOMAIN),
            'error_sales_stats' => $this->trans('Could not load sales statistics.', [], CargoStockManagerI18n::DOMAIN),
            'close' => $this->trans('Close', [], CargoStockManagerI18n::DOMAIN),
            'previous_year' => $this->trans('Previous year', [], CargoStockManagerI18n::DOMAIN),
            'next_year' => $this->trans('Next year', [], CargoStockManagerI18n::DOMAIN),
            'product_restored' => $this->trans('Product restored to the list.', [], CargoStockManagerI18n::DOMAIN),
            'product_restore_error' => $this->trans('Could not restore the product.', [], CargoStockManagerI18n::DOMAIN),
            'restore' => $this->trans('Restore', [], CargoStockManagerI18n::DOMAIN),
            'displayed' => $this->trans('Displayed', [], CargoStockManagerI18n::DOMAIN),
            'hidden_products_empty' => $this->trans('No hidden products.', [], CargoStockManagerI18n::DOMAIN),
            'module_parent_tab_error' => $this->trans('Could not resolve the parent Back Office tab for Inventory.', [], CargoStockManagerI18n::DOMAIN),
            'module_tab_create_error' => $this->trans('Could not create the Inventory tab in Back Office.', [], CargoStockManagerI18n::DOMAIN),
            'access_denied' => $this->trans('Access denied', [], CargoStockManagerI18n::DOMAIN),
            'db_update_error' => $this->trans('Database update error', [], CargoStockManagerI18n::DOMAIN),
            'stock_update_error' => $this->trans('Stock update error', [], CargoStockManagerI18n::DOMAIN),
            'hide_product_error' => $this->trans('Hide product error', [], CargoStockManagerI18n::DOMAIN),
            'missing_id_product' => $this->trans('Missing product ID', [], CargoStockManagerI18n::DOMAIN),
            'invalid_price' => $this->trans('Invalid price', [], CargoStockManagerI18n::DOMAIN),
            'price_must_be_greater_than_zero' => $this->trans('Price must be greater than 0', [], CargoStockManagerI18n::DOMAIN),
            'invalid_quantity' => $this->trans('Invalid quantity', [], CargoStockManagerI18n::DOMAIN),
            'invalid_weight' => $this->trans('Invalid weight', [], CargoStockManagerI18n::DOMAIN),
            'stock_api_not_available' => $this->trans('Stock API is not available.', [], CargoStockManagerI18n::DOMAIN),
            'product_not_found' => $this->trans('Product not found', [], CargoStockManagerI18n::DOMAIN),
            'pdf_filename' => $this->trans('Inventory_status_%date%', ['%date%' => '{{ date }}'], CargoStockManagerI18n::DOMAIN),
        ];
    }

    private function installTabs(): bool
    {
        $parentId = $this->resolveMainParentTabId();
        if ($parentId <= 0) {
            $this->_errors[] = CargoStockManagerI18n::translate($this, 'module_parent_tab_error');

            return false;
        }

        $mainTabId = $this->ensureTab(
            self::ADMIN_TAB_CLASS_NAME,
            $parentId,
            CargoStockManagerI18n::translate($this, 'inventory_menu'),
            true,
            self::MAIN_TAB_ICON
        );
        if ($mainTabId <= 0) {
            return false;
        }

        $productsTabId = $this->ensureTab(self::PRODUCTS_TAB_CLASS_NAME, $mainTabId, CargoStockManagerI18n::translate($this, 'products_tab'), true);
        if ($productsTabId <= 0) {
            return false;
        }

        $statisticsTabId = $this->ensureTab(self::STATISTICS_TAB_CLASS_NAME, $mainTabId, CargoStockManagerI18n::translate($this, 'statistics_tab'), true);
        if ($statisticsTabId <= 0) {
            return false;
        }

        $suppliersTabId = $this->ensureTab(self::SUPPLIERS_TAB_CLASS_NAME, $mainTabId, CargoStockManagerI18n::translate($this, 'suppliers_tab'), true);
        if ($suppliersTabId <= 0) {
            return false;
        }

        $purchaseOrdersTabId = $this->ensureTab(self::PURCHASE_ORDERS_TAB_CLASS_NAME, $mainTabId, CargoStockManagerI18n::translate($this, 'purchase_orders_tab'), true);
        if ($purchaseOrdersTabId <= 0) {
            return false;
        }

        $settingsTabId = $this->ensureTab(self::SETTINGS_TAB_CLASS_NAME, $mainTabId, CargoStockManagerI18n::translate($this, 'settings_tab'), true);
        if ($settingsTabId <= 0) {
            return false;
        }

        $helpTabId = $this->ensureTab(self::HELP_TAB_CLASS_NAME, $mainTabId, CargoStockManagerI18n::translate($this, 'help_tab'), true);
        if ($helpTabId <= 0) {
            return false;
        }

        return true;
    }

    private function uninstallTabs(): bool
    {
        $success = true;

        foreach ([self::HELP_TAB_CLASS_NAME, self::SETTINGS_TAB_CLASS_NAME, self::PURCHASE_ORDERS_TAB_CLASS_NAME, self::SUPPLIERS_TAB_CLASS_NAME, self::STATISTICS_TAB_CLASS_NAME, self::PRODUCTS_TAB_CLASS_NAME, self::ADMIN_TAB_CLASS_NAME] as $className) {
            $tabId = $this->findTabIdByClassName($className);
            if ($tabId <= 0) {
                continue;
            }

            $tab = new Tab($tabId);
            $success = (bool) $tab->delete() && $success;
        }

        return $success;
    }

    private function resolveMainParentTabId(): int
    {
        $candidates = [
            'SELL',
            'AdminCatalog',
            'AdminParentCatalog',
        ];

        foreach ($candidates as $className) {
            $tabId = $this->findTabIdByClassName($className);
            if ($tabId > 0) {
                return $tabId;
            }
        }

        return 0;
    }

    private function ensureTab(string $className, int $parentId, string $label, bool $active, string $icon = ''): int
    {
        $tabId = $this->findTabIdByClassName($className);
        $isNewTab = $tabId <= 0;
        $tab = $isNewTab ? new Tab() : new Tab($tabId);

        $tab->active = $active;
        $tab->class_name = $className;
        $tab->module = $this->name;
        $tab->id_parent = $parentId;
        $tab->icon = $icon;

        foreach (Language::getLanguages(false) as $language) {
            $tab->name[(int) $language['id_lang']] = $label;
        }

        $saved = $isNewTab ? $tab->add() : $tab->save();
        if (!$saved) {
            $this->_errors[] = CargoStockManagerI18n::translate($this, 'module_tab_create_error');

            return 0;
        }

        return (int) $tab->id;
    }

    private function findTabIdByClassName(string $className): int
    {
        $tabId = (int) Tab::getIdFromClassName($className);
        if ($tabId > 0) {
            return $tabId;
        }

        return (int) Db::getInstance()->getValue(
            'SELECT `id_tab` FROM `' . _DB_PREFIX_ . 'tab` WHERE `class_name` = \'' . pSQL($className) . '\''
        );
    }
}
