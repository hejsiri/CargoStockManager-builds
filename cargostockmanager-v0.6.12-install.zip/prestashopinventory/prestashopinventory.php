<?php

require_once __DIR__ . '/cargostockmanager.php';

class prestashopinventory extends CargoStockManager
{
}
