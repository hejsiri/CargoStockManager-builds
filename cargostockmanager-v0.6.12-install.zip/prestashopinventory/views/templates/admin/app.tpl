<div class="inventory-module-content{if !empty($inventoryEmbeddedInModernLayout)} inventory-module-content--embedded{/if}">
{if empty($inventoryEmbeddedInModernLayout)}
<div id="csmgr-head-tabs-source" class="page-head-tabs inventory-panel-tabs" role="tablist" aria-label="{$inventoryTranslations.module_navigation|escape:'html':'UTF-8'}">
  <ul class="nav nav-pills">
    <li class="nav-item">
      <a href="{$inventoryModuleUrl|escape:'html':'UTF-8'}" class="router-link-active router-link-exact-active nav-link active" aria-current="page" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">train</span><span>{$inventoryTranslations.products_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
    <li class="nav-item">
      <a href="{$inventorySuppliersUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">local_shipping</span><span>{$inventoryTranslations.suppliers_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
    <li class="nav-item">
      <a href="{$inventoryPurchaseOrdersUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">inventory_2</span><span>{$inventoryTranslations.purchase_orders_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
    <li class="nav-item">
      <a href="{$inventoryConfigUrl|escape:'html':'UTF-8'}" class="nav-link" role="tab"><span class="inventory-tab-link-content"><span class="menu-icon material-icons" aria-hidden="true">settings</span><span>{$inventoryTranslations.settings_tab|escape:'html':'UTF-8'}</span></span></a>
    </li>
  </ul>
  <div class="inventory-update-meta">
    <div id="inventoryUpdateMetaStatus" class="inventory-update-meta-status"></div>
  </div>
</div>
{/if}
<div class="card js-grid-panel cargo-stock-manager">
  <div class="card-header js-grid-header">
    <h3 class="d-inline-block card-header-title">{$inventoryTranslations.products_tab|escape:'html':'UTF-8'}</h3>
  </div>
  <div class="card-body">
  <div id="inventoryUpdateStatus" class="inventory-update-status" aria-live="polite"></div>

  {if !$inventoryLicenseStatus.valid}
    <div class="alert alert-danger inventory-license-alert" role="alert">
      <strong>{$inventoryTranslations.license_required_title|escape:'html':'UTF-8'}:</strong>
      <span>{$inventoryLicenseStatus.message|escape:'html':'UTF-8'}</span>
    </div>
  {/if}

  {if $inventoryLicenseStatus.valid}
  <div class="inventory-topbar">
    <div class="inventory-search">
      <div class="inventory-search-wrap">
        <div id="searchBox" class="inventory-tagbox">
          <div id="searchTags" class="inventory-tags"></div>
          <input type="text" id="searchInput" class="inventory-tag-input" autocomplete="off">
        </div>
        <button id="clearSearch" type="button" class="inventory-clear" aria-label="{$inventoryTranslations.clear|escape:'html':'UTF-8'}">&times;</button>
      </div>
    </div>

    <div class="inventory-toolbar">
      <div class="inventory-actions">
        <div class="inventory-actions-menu inventory-filters-menu">
          <button class="btn btn-outline-secondary inventory-toolbar-btn inventory-actions-toggle inventory-filter-toggle" type="button" aria-haspopup="true" aria-expanded="false" aria-label="{$inventoryTranslations.filters|escape:'html':'UTF-8'}">
            <i class="icon-tasks"></i>
            <span class="inventory-filter-toggle-label">{$inventoryTranslations.filters|escape:'html':'UTF-8'}</span>
            <span id="filterActiveCount" class="inventory-filter-badge">0</span>
          </button>
          <div class="inventory-actions-dropdown inventory-filter-dropdown">
            <div class="inventory-filter-columns">
              <div class="inventory-filter-col">
                <div class="inventory-filter-col-title">Pokaż kolumny</div>
                <label class="inventory-switch-row inventory-filter-row">
                  <span class="ios-switch">
                    <input type="checkbox" id="showWeight" data-filter-type="show-column">
                    <span class="slider"></span>
                  </span>
                  <span id="showWeightLabel"></span>
                </label>
                <label class="inventory-switch-row inventory-filter-row">
                  <span class="ios-switch">
                    <input type="checkbox" id="showUnitVolume" data-filter-type="show-column">
                    <span class="slider"></span>
                  </span>
                  <span id="showUnitVolumeLabel"></span>
                </label>
                <label class="inventory-switch-row inventory-filter-row">
                  <span class="ios-switch">
                    <input type="checkbox" id="showUnitsPerCarton" data-filter-type="show-column">
                    <span class="slider"></span>
                  </span>
                  <span id="showUnitsPerCartonLabel"></span>
                </label>
                <label class="inventory-switch-row inventory-filter-row">
                  <span class="ios-switch">
                    <input type="checkbox" id="showCartonDimensions" data-filter-type="show-column">
                    <span class="slider"></span>
                  </span>
                  <span id="showCartonDimensionsLabel"></span>
                </label>
                <label class="inventory-switch-row inventory-filter-row">
                  <span class="ios-switch">
                    <input type="checkbox" id="showMaterial" data-filter-type="show-column">
                    <span class="slider"></span>
                  </span>
                  <span>Materiał</span>
                </label>
                <label class="inventory-switch-row inventory-filter-row">
                  <span class="ios-switch">
                    <input type="checkbox" id="showHsCode" data-filter-type="show-column">
                    <span class="slider"></span>
                  </span>
                  <span>HS Code</span>
                </label>
                <label class="inventory-switch-row inventory-filter-row">
                  <span class="ios-switch">
                    <input type="checkbox" id="showCustomsDutyRate" data-filter-type="show-column">
                    <span class="slider"></span>
                  </span>
                  <span>Cło</span>
                </label>
                <label class="inventory-switch-row inventory-filter-row">
                  <span class="ios-switch">
                    <input type="checkbox" id="showBrutto" data-filter-type="show-column">
                    <span class="slider"></span>
                  </span>
                  <span id="showBruttoLabel"></span>
                </label>
              </div>
              <div class="inventory-filter-col">
                <div class="inventory-filter-col-title">Pokaż tylko</div>
                <label class="inventory-switch-row inventory-filter-row">
                  <span class="ios-switch">
                    <input type="checkbox" id="activeOnly" data-filter-type="show-only">
                    <span class="slider"></span>
                  </span>
                  <span id="activeOnlyLabel"></span>
                </label>
                <label class="inventory-switch-row inventory-filter-row">
                  <span class="ios-switch">
                    <input type="checkbox" id="onlyAvailable" data-filter-type="show-only">
                    <span class="slider"></span>
                  </span>
                  <span id="onlyAvailableLabel"></span>
                </label>
                <label class="inventory-switch-row inventory-filter-row">
                  <span class="ios-switch">
                    <input type="checkbox" id="missingPurchasePriceOnly" data-filter-type="show-only">
                    <span class="slider"></span>
                  </span>
                  <span id="missingPurchasePriceOnlyLabel"></span>
                </label>
                <label class="inventory-switch-row inventory-filter-row">
                  <span class="ios-switch">
                    <input type="checkbox" id="missingWeightOnly" data-filter-type="show-only">
                    <span class="slider"></span>
                  </span>
                  <span id="missingWeightOnlyLabel"></span>
                </label>
              </div>
            </div>
          </div>
        </div>

        <button id="btnPdf" class="btn btn-primary inventory-toolbar-btn" type="button">
          <span class="material-icons" aria-hidden="true">picture_as_pdf</span> PDF
        </button>

        <button id="btnScanner" class="btn btn-outline-secondary inventory-toolbar-btn inventory-scanner-btn" type="button" title="Skaner kodów kreskowych">
          <span class="material-icons" style="font-size:18px;vertical-align:middle;line-height:1;">qr_code_scanner</span>
        </button>

        <button id="inventoryUpdateButton" class="btn btn-outline-primary inventory-toolbar-btn inventory-update-btn" type="button" hidden data-version="">
          <span class="inventory-update-btn-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24" focusable="false">
              <path d="M6.5 18.5a4.5 4.5 0 0 1-.4-9 6.5 6.5 0 0 1 12.6 1.6h.8a3.5 3.5 0 1 1 0 7H6.5Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M12 9.5v7" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
              <path d="m9.25 13.75 2.75 2.75 2.75-2.75" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </span>
          <span class="inventory-update-btn-label"></span>
        </button>
      </div>
    </div>
  </div>

  <div class="table-responsive-row clearfix">
    <table id="productsTable" class="grid-table js-grid-table table">
      <thead class="thead-default">
        <tr>
          <th id="thNo" class="inventory-sortable" data-sort-field="id_product"><div class="ps-sortable-column inventory-sort-button" role="button" tabindex="0"><span role="columnheader" class="inventory-head-title">ID</span><span class="ps-sort inventory-sort-indicator" aria-hidden="true"></span></div></th>
          <th id="thPicture">{$inventoryTranslations.image|escape:'html':'UTF-8'}</th>
          <th id="thName" class="inventory-sortable" data-sort-field="product_name"><div class="ps-sortable-column inventory-sort-button" role="button" tabindex="0"><span role="columnheader"><span class="inventory-head-title">{$inventoryTranslations.product_name|escape:'html':'UTF-8'}</span><span class="inventory-head-subtitle">{$inventoryTranslations.ean13|escape:'html':'UTF-8'}</span></span><span class="ps-sort inventory-sort-indicator" aria-hidden="true"></span></div></th>
          <th id="thActive" class="text-center inventory-sortable" data-sort-field="active"><div class="ps-sortable-column inventory-sort-button inventory-sort-button-center" role="button" tabindex="0"><span role="columnheader" class="inventory-head-title">{$inventoryTranslations.active|escape:'html':'UTF-8'}</span><span class="ps-sort inventory-sort-indicator" aria-hidden="true"></span></div></th>
          <th id="thWeight" class="text-center inventory-sortable" data-sort-field="weight"><div class="ps-sortable-column inventory-sort-button inventory-sort-button-center" role="button" tabindex="0"><span role="columnheader" class="inventory-head-title">{$inventoryTranslations.product_weight|escape:'html':'UTF-8'}</span><span class="ps-sort inventory-sort-indicator" aria-hidden="true"></span></div></th>
          <th id="thUnitVolume" class="text-center">{$inventoryTranslations.unit_volume|escape:'html':'UTF-8'}</th>
          <th id="thUnitsPerCarton" class="text-center">{$inventoryTranslations.units_per_carton|escape:'html':'UTF-8'}</th>
          <th id="thCartonDimensions" class="text-center">{$inventoryTranslations.carton_dimensions|escape:'html':'UTF-8'}</th>
          <th id="thMaterial" class="text-center">Materiał</th>
          <th id="thHsCode" class="text-center">HS Code</th>
          <th id="thCustomsDutyRate" class="text-center">Cło</th>
          <th id="thPrice" class="text-center inventory-sortable" data-sort-field="purchase_price"><div class="ps-sortable-column inventory-sort-button inventory-sort-button-center" role="button" tabindex="0"><span role="columnheader" class="inventory-head-title">{$inventoryTranslations.purchase_price_net|escape:'html':'UTF-8'}</span><span class="ps-sort inventory-sort-indicator" aria-hidden="true"></span></div></th>
          <th id="thPriceBrutto" class="text-center inventory-sortable" data-sort-field="retail_price"><div class="ps-sortable-column inventory-sort-button inventory-sort-button-center" role="button" tabindex="0"><span role="columnheader" class="inventory-head-title">{$inventoryTranslations.retail_price_gross|escape:'html':'UTF-8'}</span><span class="ps-sort inventory-sort-indicator" aria-hidden="true"></span></div></th>
          <th id="thQty" class="text-center inventory-sortable" data-sort-field="quantity"><div class="ps-sortable-column inventory-sort-button inventory-sort-button-center" role="button" tabindex="0"><span role="columnheader" class="inventory-head-title">{$inventoryTranslations.available_quantity|escape:'html':'UTF-8'}</span><span class="ps-sort inventory-sort-indicator" aria-hidden="true"></span></div></th>
          <th id="thValue" class="text-center">{$inventoryTranslations.purchase_value_net|escape:'html':'UTF-8'}</th>
          <th id="thValueBrutto" class="text-center">{$inventoryTranslations.retail_value_gross|escape:'html':'UTF-8'}</th>
          <th id="thActions" class="text-center">{$inventoryTranslations.actions|escape:'html':'UTF-8'}</th>
        </tr>
      </thead>
      <tbody></tbody>
    </table>
  </div>

  <div id="inventoryPagination" class="inventory-pagination"></div>
  {/if}
  </div>
</div>

<div id="inventoryProfitModal" class="inventory-sales-modal inventory-profit-modal" aria-hidden="true">
  <div class="inventory-sales-modal-backdrop"></div>
  <div class="inventory-sales-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="inventoryProfitModalTitle">
    <button type="button" class="inventory-sales-modal-close inventory-profit-modal-close" aria-label="Close"></button>
    <div class="inventory-sales-modal-head">
      <div class="inventory-sales-modal-media">
        <div class="inventory-sales-modal-thumb-wrap">
          <img id="inventoryProfitModalImage" class="inventory-sales-modal-thumb" src="" alt="">
          <div id="inventoryProfitModalImageFallback" class="inventory-sales-modal-thumb-fallback"></div>
        </div>
        <div class="inventory-sales-modal-copy">
          <div id="inventoryProfitModalTitle" class="inventory-sales-modal-title"></div>
          <div id="inventoryProfitModalSubtitle" class="inventory-sales-modal-subtitle"></div>
        </div>
      </div>
    </div>
    <div id="inventoryProfitModalContent" class="inventory-sales-modal-content"></div>
  </div>
</div>
</div>

<div id="inventoryScannerBadge" class="inventory-scanner-badge" role="status">
  <span class="material-icons">qr_code_scanner</span>
  <span>Skaner aktywny — zeskanuj produkt</span>
  <span class="inventory-scanner-badge-close material-icons" title="Wyłącz skaner">close</span>
</div>

<div id="inventoryScannerModal" class="inventory-scanner-modal" aria-hidden="true">
  <div class="inventory-scanner-modal-backdrop"></div>
  <div class="inventory-scanner-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="inventoryScannerModalTitle">
    <button type="button" class="inventory-sales-modal-close inventory-scanner-modal-close" aria-label="Zamknij"></button>
    <div class="inventory-scanner-modal-head">
      <div class="inventory-sales-modal-media">
        <div class="inventory-sales-modal-thumb-wrap">
          <img id="inventoryScannerModalImage" class="inventory-sales-modal-thumb" src="" alt="">
          <div id="inventoryScannerModalImageFallback" class="inventory-sales-modal-thumb-fallback"></div>
        </div>
        <div class="inventory-sales-modal-copy">
          <div id="inventoryScannerModalTitle" class="inventory-sales-modal-title"></div>
          <div id="inventoryScannerModalSubtitle" class="inventory-sales-modal-subtitle"></div>
          <div id="inventoryScannerModalEan" class="inventory-scanner-modal-ean"></div>
        </div>
      </div>
    </div>
    <div id="inventoryScannerModalContent" class="inventory-scanner-modal-content"></div>
  </div>
</div>

<div id="inventorySalesModal" class="inventory-sales-modal" aria-hidden="true">
  <div class="inventory-sales-modal-backdrop"></div>
  <div class="inventory-sales-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="inventorySalesModalTitle">
    <button type="button" class="inventory-sales-modal-close" aria-label="Close"></button>
    <div class="inventory-sales-modal-head">
      <div class="inventory-sales-modal-media">
        <div class="inventory-sales-modal-thumb-wrap">
          <img id="inventorySalesModalImage" class="inventory-sales-modal-thumb" src="" alt="">
          <div id="inventorySalesModalImageFallback" class="inventory-sales-modal-thumb-fallback"></div>
        </div>
        <div class="inventory-sales-modal-copy">
          <div id="inventorySalesModalTitle" class="inventory-sales-modal-title"></div>
          <div id="inventorySalesModalSubtitle" class="inventory-sales-modal-subtitle"></div>
        </div>
      </div>
    </div>
    <div id="inventorySalesModalState" class="inventory-sales-modal-state"></div>
    <div id="inventorySalesModalContent" class="inventory-sales-modal-content"></div>
  </div>
</div>

<style>
  .inventory-module-content {
    padding-top: 60px;
    clear: both;
    position: relative;
  }

  .inventory-module-content--embedded {
    padding-top: 0;
  }

  .inventory-panel-tabs {
    margin: 0;
    flex: 1 1 auto;
  }

  .page-head > .inventory-panel-tabs {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 14px;
    min-height: 58px;
    margin: 0;
    padding: 0;
    border-top: 1px solid #eaebec;
    border-bottom: 1px solid #eaebec;
    background: #fff;
    box-shadow: none;
  }

  .page-head > .inventory-panel-tabs .nav.nav-pills {
    display: flex;
    flex: 1 1 auto;
    align-self: stretch;
    gap: 0;
    margin: 0;
    padding: 0;
  }

  .page-head > .inventory-panel-tabs .nav-item {
    display: flex;
    margin: 0;
  }

  .page-head > .inventory-panel-tabs .nav-link {
    position: relative;
    display: inline-flex;
    align-items: center;
    margin: 0;
    min-height: 56px;
    padding: 0 1.6rem;
    border: 0;
    border-radius: 0;
    background: transparent;
    color: #6c868e;
    font-size: 0.95rem;
    font-weight: 400;
    line-height: 1.3;
    transition: color .2s ease, background-color .2s ease;
    box-shadow: none;
  }

  .page-head > .inventory-panel-tabs .inventory-tab-link-content {
    display: inline-flex;
    align-items: center;
    gap: 12px;
  }

  .page-head > .inventory-panel-tabs .inventory-tab-link-content .menu-icon.material-icons {
    width: 22px;
    height: 22px;
    font-size: 22px;
    line-height: 1;
  }

  .page-head > .inventory-panel-tabs .nav-link:hover,
  .page-head > .inventory-panel-tabs .nav-link:focus {
    background: #fff;
    color: #25b9d7;
    box-shadow: none;
  }

  .page-head > .inventory-panel-tabs .nav-link::after {
    content: "";
    position: absolute;
    right: 0;
    bottom: 0;
    left: 0;
    height: 3px;
    background: #25b9d7;
    opacity: 0;
    transition: opacity .2s ease;
  }

  .page-head > .inventory-panel-tabs .nav-link:hover::after,
  .page-head > .inventory-panel-tabs .nav-link:focus::after,
  .page-head > .inventory-panel-tabs .nav-link.active::after,
  .page-head > .inventory-panel-tabs .nav-link[aria-current="page"]::after {
    opacity: 1;
  }

  .page-head > .inventory-panel-tabs .nav-link.active,
  .page-head > .inventory-panel-tabs .nav-link[aria-current="page"] {
    background: #eef8fd;
    color: #363a41;
    font-weight: 400;
    box-shadow: none;
  }

  .cargo-stock-manager.card {
    margin-bottom: 0;
    margin-top: 0 !important;
  }

  .cargo-stock-manager .card-header {
    padding: 1rem 1.25rem;
  }

  .cargo-stock-manager .card-body {
    padding: 20px 28px 24px;
  }

  .cargo-stock-manager .inventory-topbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px 24px;
    margin-bottom: 22px;
    padding-bottom: 18px;
    border-bottom: 1px solid #edf3f7;
  }

  .cargo-stock-manager .inventory-toolbar {
    display: flex;
    justify-content: flex-end;
    gap: 16px;
    align-items: center;
    flex-wrap: wrap;
    margin: 0 0 0 auto;
    flex: 0 0 auto;
  }

  .page-head > .inventory-panel-tabs .inventory-update-meta {
    display: flex;
    flex: 0 0 260px;
    align-items: center;
    justify-content: center;
    min-height: 56px;
    height: 56px;
    margin: 0 18px 0 0;
    text-align: right;
    overflow: hidden;
  }

  .page-head > .inventory-panel-tabs .inventory-update-meta-status {
    display: block;
    width: 100%;
    margin: 0;
    padding: 0;
    border: 0;
    background: transparent;
    font-size: 11px;
    font-weight: 600;
    color: #7a8f9d;
    line-height: 1.25;
    min-height: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .page-head > .inventory-panel-tabs .inventory-update-meta-status.is-error {
    color: #c05c67;
  }

  @media (max-width: 1100px) {
    .page-head > .inventory-panel-tabs .inventory-update-meta {
      flex-basis: 180px;
      margin-right: 12px;
    }
  }

  @media (max-width: 920px) {
    .page-head > .inventory-panel-tabs .inventory-update-meta {
      display: none;
    }
  }

  .cargo-stock-manager .inventory-actions {
    display: flex;
    gap: 16px;
    align-items: center;
    flex-wrap: wrap;
  }

  .cargo-stock-manager .inventory-search {
    margin: 0;
    flex: 1 1 620px;
    min-width: 280px;
  }

  .cargo-stock-manager .inventory-marketplace-settings {
    margin-bottom: 20px;
    padding: 14px 16px;
    border: 1px solid #dbe6ed;
    border-radius: 14px;
    background: linear-gradient(180deg, #fdfefe 0%, #f5f9fc 100%);
  }

  .cargo-stock-manager .inventory-marketplace-settings-title {
    margin-bottom: 10px;
    font-size: 12px;
    font-weight: 700;
    letter-spacing: .08em;
    text-transform: uppercase;
    color: #6f8594;
  }

  .cargo-stock-manager .inventory-marketplace-settings-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, max-content));
    gap: 12px;
  }

  .cargo-stock-manager .inventory-marketplace-setting {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    min-width: 0;
    padding: 10px 12px;
    border-radius: 12px;
    background: #fff;
    border: 1px solid #e2ecf2;
  }

  .cargo-stock-manager .inventory-marketplace-setting-label {
    font-size: 12px;
    color: #6f8594;
    white-space: nowrap;
  }

  .cargo-stock-manager .inventory-marketplace-setting-value {
    display: inline-flex;
    align-items: center;
    min-height: 24px;
    font-size: 13px;
    font-weight: 700;
    color: #1f3442;
    cursor: pointer;
    text-decoration: underline dotted;
    text-underline-offset: 3px;
    white-space: nowrap;
  }

  .cargo-stock-manager .inventory-toolbar-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    height: 42px;
    min-height: 42px;
    padding: 0 16px !important;
    border-radius: 8px !important;
    font-size: 14px !important;
    font-weight: 700 !important;
    line-height: 1 !important;
    white-space: nowrap;
  }

  .cargo-stock-manager .inventory-toolbar-btn:hover,
  .cargo-stock-manager .inventory-toolbar-btn:focus {
    text-decoration: none;
  }

  .cargo-stock-manager .inventory-toolbar-btn i {
    font-size: 15px;
    line-height: 1;
  }

  .cargo-stock-manager .inventory-toolbar-btn .material-icons {
    font-size: 18px;
    line-height: 1;
  }

  .cargo-stock-manager #btnPdf {
    min-width: 122px;
  }

  .cargo-stock-manager .inventory-update-btn[hidden] {
    display: none !important;
  }

  .cargo-stock-manager .inventory-update-status {
    display: none !important;
  }

  .cargo-stock-manager .inventory-update-status.is-error {
    color: #c05c67;
  }

  .cargo-stock-manager .inventory-license-alert {
    margin-bottom: 18px;
    border-radius: 12px;
  }

  .cargo-stock-manager .inventory-search-wrap {
    max-width: none;
    width: 100%;
    position: relative;
  }

  .cargo-stock-manager .inventory-tagbox {
    min-height: 42px;
    height: 42px;
    padding: 0 40px 0 4px;
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 6px;
    cursor: text;
    border: 1px solid #ccd9e2;
    border-radius: 8px;
    background: #fff;
    box-shadow: none;
  }

  .cargo-stock-manager .inventory-tagbox:focus-within {
    border-color: #25b9d7;
    box-shadow: 0 0 0 1px rgba(37, 185, 215, 0.2);
  }

  .cargo-stock-manager .inventory-tags {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 6px;
  }

  .cargo-stock-manager .inventory-tag {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    min-height: 26px;
    padding: 0 11px;
    background: linear-gradient(135deg, #25b9d7 0%, #31c0e3 100%);
    color: #fff;
    border-radius: 6px;
    font-weight: 600;
    font-size: 13px;
    line-height: 1;
    box-shadow: none;
  }

  .cargo-stock-manager .inventory-tag-remove {
    border: 0;
    background: transparent;
    padding: 0;
    line-height: 1;
    font-size: 18px;
    color: rgba(255, 255, 255, 0.96);
  }

  .cargo-stock-manager .inventory-tag-input {
    flex: 1 1 140px;
    min-width: 120px;
    border: 0 !important;
    outline: none !important;
    box-shadow: none !important;
    -webkit-box-shadow: none !important;
    height: 40px;
    padding: 0;
    margin: 0;
    background: transparent !important;
    appearance: none;
    -webkit-appearance: none;
    border-radius: 0;
  }

  .cargo-stock-manager .inventory-tag-input:focus,
  .cargo-stock-manager .inventory-tag-input:hover,
  .cargo-stock-manager .inventory-tag-input:active {
    border: 0 !important;
    outline: none !important;
    box-shadow: none !important;
    -webkit-box-shadow: none !important;
    background: transparent !important;
  }

  .cargo-stock-manager .inventory-clear {
    position: absolute;
    top: 50%;
    right: 12px;
    transform: translateY(-50%);
    border: 0;
    background: transparent;
    color: #888;
    font-size: 22px;
    line-height: 1;
    padding: 0;
  }

  .cargo-stock-manager .ios-switch {
    position: relative;
    display: inline-block;
    width: 28px;
    height: 16px;
  }

  .cargo-stock-manager .ios-switch input {
    opacity: 0;
    width: 0;
    height: 0;
  }

  .cargo-stock-manager .slider {
    position: absolute;
    inset: 0;
    cursor: pointer;
    background-color: #ccc;
    border-radius: 25px;
    transition: .4s;
  }

  .cargo-stock-manager .slider:before {
    content: "";
    position: absolute;
    width: 12px;
    height: 12px;
    top: 2px;
    left: 2px;
    background: #fff;
    border-radius: 50%;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.18);
    transition: .2s ease;
  }

  .cargo-stock-manager input:checked + .slider {
    background: #4f955d;
  }

  .cargo-stock-manager input:checked + .slider:before {
    transform: translateX(12px);
  }

  .cargo-stock-manager .inventory-switch-row {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    margin: 0;
    font-weight: 400;
  }

  .cargo-stock-manager .inventory-filters-menu {
    position: relative;
  }

  .cargo-stock-manager .inventory-filter-toggle {
    position: relative;
  }

  .cargo-stock-manager .table-responsive-row {
    overflow-x: auto;
  }

  .cargo-stock-manager .inventory-filter-badge {
    position: absolute;
    top: -6px;
    right: -6px;
    min-width: 18px;
    height: 18px;
    padding: 0 4px;
    border-radius: 999px;
    background: #d93025;
    color: #fff;
    font-size: 11px;
    font-weight: 700;
    line-height: 18px;
    text-align: center;
  }

  .cargo-stock-manager .inventory-filter-badge.is-hidden {
    display: none;
  }

  .cargo-stock-manager .inventory-filter-dropdown {
    width: max-content;
    min-width: 0;
    max-width: calc(100vw - 32px);
    padding: 8px 0;
  }

  .cargo-stock-manager .inventory-filter-columns {
    display: flex;
    gap: 0;
  }

  .cargo-stock-manager .inventory-filter-col {
    flex: 1 1 auto;
  }

  .cargo-stock-manager .inventory-filter-col + .inventory-filter-col {
    border-left: 1px solid #e8eef4;
  }

  .cargo-stock-manager .inventory-filter-col-title {
    font-size: 15px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.07em;
    color: #25b9d7;
    line-height: 1.2;
    padding: 14px 16px 10px;
    border-bottom: 1px solid #e8eef4;
    margin-bottom: 4px;
  }

  .cargo-stock-manager .inventory-filter-row {
    display: flex;
    width: 100%;
    padding: 10px 16px;
    gap: 12px;
    cursor: pointer;
  }

  .cargo-stock-manager .inventory-filter-row > span:last-child {
    flex: 1 1 auto;
    line-height: 1.3;
    white-space: nowrap;
  }

  .cargo-stock-manager .inventory-filter-row:hover {
    background: #f5f7fa;
  }

  .cargo-stock-manager img.img-thumbnail {
    width: 45px;
    height: 45px;
    min-width: 45px;
    min-height: 45px;
    flex: 0 0 45px;
    object-fit: cover;
    border: 1px solid #ddd;
    border-radius: 8px;
    background: #fff;
    padding: 2px;
    display: block;
  }

  .cargo-stock-manager .product-preview {
    position: relative;
    display: inline-flex;
    align-items: center;
    outline: none;
  }

  .cargo-stock-manager .product-preview-card {
    position: fixed;
    z-index: 99999;
    display: none;
    min-width: 260px;
    padding: 14px 16px;
    background-color: #fff;
    color: #111;
    border-radius: 14px;
    box-shadow: 0 12px 28px rgba(0, 0, 0, 0.18), 0 4px 10px rgba(0, 0, 0, 0.12);
    white-space: normal;
    pointer-events: none;
  }

  .cargo-stock-manager .product-preview:hover .product-preview-card,
  .cargo-stock-manager .product-preview:focus .product-preview-card,
  .cargo-stock-manager .product-preview:focus-within .product-preview-card {
    display: block;
  }

  .cargo-stock-manager .product-preview-title,
  .cargo-stock-manager .product-preview-subtitle {
    display: block;
    line-height: 1.35;
  }

  .cargo-stock-manager .product-preview-title {
    font-weight: 600;
  }

  .cargo-stock-manager .product-preview-subtitle {
    margin-top: 4px;
    color: #666;
  }

  .cargo-stock-manager .product-preview-image {
    display: block;
    width: 240px;
    max-width: min(240px, 70vw);
    height: auto;
    border-radius: 10px;
    margin-top: 10px;
  }

  .cargo-stock-manager #productsTable {
    margin-bottom: 0;
    background: #fff;
  }

  .cargo-stock-manager .inventory-pagination {
    margin-top: 18px;
    padding-top: 6px;
  }

  .cargo-stock-manager .inventory-pagination-inner {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-wrap: wrap;
    gap: 12px;
  }

  .cargo-stock-manager .inventory-pagination-pages {
    display: flex;
    align-items: center;
  }

  .cargo-stock-manager .inventory-pagination-pages .pagination {
    margin: 0;
  }

  .cargo-stock-manager .inventory-pagination-pages .page-item {
    margin-bottom: 0;
  }

  .cargo-stock-manager .inventory-pagination-pages .page-link {
    border: 1px solid #bbcdd5;
    background: #fff;
    box-shadow: none;
    border-radius: 4px;
    color: #6c868e;
    font-size: 14px;
    font-weight: 500;
    line-height: 1;
    min-width: 38px;
    height: 38px;
    padding: 0 10px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
  }

  .cargo-stock-manager .inventory-pagination-pages .page-link:hover,
  .cargo-stock-manager .inventory-pagination-pages .page-link:focus {
    background: #fff;
    box-shadow: none;
    color: #6c868e;
    border-color: #bbcdd5;
  }

  .cargo-stock-manager .inventory-pagination-pages .page-item.disabled .page-link,
  .cargo-stock-manager .inventory-pagination-pages .page-item.disabled .page-link:hover,
  .cargo-stock-manager .inventory-pagination-pages .page-item.disabled .page-link:focus {
    color: #c8d7df;
    background: #fff;
    border-color: #d9e4ea;
    opacity: 1;
    cursor: default;
  }

  .cargo-stock-manager .inventory-pagination-pages .inventory-page-nav span[aria-hidden="true"] {
    display: block;
    font-size: 24px;
    line-height: 1;
    font-weight: 400;
    margin-top: -2px;
  }

  .cargo-stock-manager .inventory-pagination-pages .inventory-page-edge {
    font-size: 14px;
    font-weight: 400;
    line-height: 1;
    min-width: auto;
    padding: 0 8px;
    border-color: transparent;
    background: transparent;
  }

  .cargo-stock-manager .inventory-pagination-pages .inventory-page-edge:hover,
  .cargo-stock-manager .inventory-pagination-pages .inventory-page-edge:focus {
    border-color: transparent;
    background: transparent;
    box-shadow: none;
  }

  .cargo-stock-manager .inventory-pagination-pages .page-item.disabled .inventory-page-edge,
  .cargo-stock-manager .inventory-pagination-pages .page-item.disabled .inventory-page-edge:hover,
  .cargo-stock-manager .inventory-pagination-pages .page-item.disabled .inventory-page-edge:focus {
    border-color: transparent;
    background: transparent;
    box-shadow: none;
  }

  .cargo-stock-manager .inventory-pagination-pages .page-item.previous .page-link::before,
  .cargo-stock-manager .inventory-pagination-pages .page-item.previous .page-link::after,
  .cargo-stock-manager .inventory-pagination-pages .page-item.next .page-link::before,
  .cargo-stock-manager .inventory-pagination-pages .page-item.next .page-link::after {
    content: none !important;
  }

  .cargo-stock-manager .inventory-pagination-pages .page-item.previous .page-link,
  .cargo-stock-manager .inventory-pagination-pages .page-item.next .page-link {
    border-color: transparent;
    background: transparent;
    min-width: 30px;
    padding: 0 4px;
  }

  .cargo-stock-manager .inventory-pagination-pages .page-item.previous .page-link:hover,
  .cargo-stock-manager .inventory-pagination-pages .page-item.previous .page-link:focus,
  .cargo-stock-manager .inventory-pagination-pages .page-item.next .page-link:hover,
  .cargo-stock-manager .inventory-pagination-pages .page-item.next .page-link:focus,
  .cargo-stock-manager .inventory-pagination-pages .page-item.previous.disabled .page-link,
  .cargo-stock-manager .inventory-pagination-pages .page-item.previous.disabled .page-link:hover,
  .cargo-stock-manager .inventory-pagination-pages .page-item.previous.disabled .page-link:focus,
  .cargo-stock-manager .inventory-pagination-pages .page-item.next.disabled .page-link,
  .cargo-stock-manager .inventory-pagination-pages .page-item.next.disabled .page-link:hover,
  .cargo-stock-manager .inventory-pagination-pages .page-item.next.disabled .page-link:focus {
    border-color: transparent;
    background: transparent;
    box-shadow: none;
  }

  .cargo-stock-manager .inventory-pagination-pages .page-item.current label {
    margin: 0;
  }

  .cargo-stock-manager .inventory-pagination-pages .page-item.current .jump-to-page,
  .cargo-stock-manager .inventory-page-current {
    width: 52px;
    min-width: 52px;
    height: 38px;
    border: 1px solid #bbcdd5;
    border-radius: 4px;
    background: #fff;
    color: #2e3b44;
    text-align: center;
    font-weight: 600;
    font-size: 14px;
    padding: 0 6px;
  }

  .cargo-stock-manager .inventory-page-current::-webkit-outer-spin-button,
  .cargo-stock-manager .inventory-page-current::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }

  .cargo-stock-manager .inventory-pagination-status {
    font-size: 14px;
    color: #576c76;
    white-space: nowrap;
  }

  .cargo-stock-manager .inventory-per-page {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    margin: 0;
    font-size: 14px;
    white-space: nowrap;
  }

  .cargo-stock-manager .inventory-per-page-label {
    white-space: nowrap;
    color: #576c76;
  }

  .cargo-stock-manager .inventory-per-page-select {
    min-width: 88px;
    height: 38px;
    border: 1px solid #bbcdd5;
    border-radius: 4px;
    background: #fff;
    color: #2e3b44;
    font-size: 16px;
    font-weight: 500;
    padding: 0 34px 0 12px;
  }

  .cargo-stock-manager #productsTable thead th {
    white-space: normal;
    vertical-align: middle;
  }

  .cargo-stock-manager .inventory-sort-button {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    width: 100%;
    padding: 0;
    text-align: left;
    color: inherit;
  }

  .cargo-stock-manager .inventory-sort-button-center {
    justify-content: center;
  }

  .cargo-stock-manager .inventory-sort-indicator {
    width: 14px;
    min-width: 14px;
    height: 14px;
    position: relative;
    opacity: .72;
    display: inline-block;
  }

  .cargo-stock-manager .inventory-sort-indicator:before {
    content: "";
    position: absolute;
    top: 4px;
    left: 3px;
    width: 6px;
    height: 6px;
    border-right: 1px solid #6c868e;
    border-bottom: 1px solid #6c868e;
    transform: rotate(135deg);
  }

  .cargo-stock-manager .inventory-sortable.is-active .inventory-sort-indicator {
    opacity: 1;
  }

  .cargo-stock-manager .inventory-sortable.sort-asc .inventory-sort-indicator:before {
    top: 2px;
    transform: rotate(-45deg);
  }

  .cargo-stock-manager #productsTable tbody td {
    padding: 8px 14px;
    border: 0;
    border-bottom: 1px solid #ececec;
    vertical-align: middle;
    font-size: 13px;
    color: #2b2b2b;
    background: #fff;
    transition: background-color .15s ease;
  }

  .cargo-stock-manager #productsTable tbody tr:hover td {
    background: #f4f8fb;
  }

  .cargo-stock-manager .inventory-col-id {
    width: 92px;
    font-weight: 400;
  }

  .cargo-stock-manager .inventory-col-image {
    width: 86px;
    min-width: 86px;
    text-align: center;
  }

  .cargo-stock-manager #thPicture {
    width: 86px;
    min-width: 86px;
    text-align: center;
  }

  .cargo-stock-manager .inventory-col-name {
    min-width: 360px;
  }

  .cargo-stock-manager .inventory-col-price,
  .cargo-stock-manager .inventory-col-metric,
  .cargo-stock-manager .inventory-col-active,
  .cargo-stock-manager .inventory-col-qty,
  .cargo-stock-manager .inventory-col-value {
    white-space: nowrap;
    font-variant-numeric: tabular-nums;
  }

  .cargo-stock-manager .inventory-col-metric {
    width: 112px;
  }

  .cargo-stock-manager .inventory-col-actions {
    width: 88px;
  }

  .cargo-stock-manager .inventory-col-active {
    width: 110px;
  }

  .cargo-stock-manager .inventory-product-name {
    font-size: 13px;
    font-weight: 500;
    line-height: 1.2;
  }

  .cargo-stock-manager .inventory-product-link {
    color: #2b2b2b;
    text-decoration: none;
  }

  .cargo-stock-manager .inventory-product-link:hover,
  .cargo-stock-manager .inventory-product-link:focus {
    color: #25b9d7;
    text-decoration: none;
    outline: none;
  }

  .cargo-stock-manager .inventory-product-meta {
    margin-top: 2px;
    color: #a0a0a0;
    font-size: 11px;
    line-height: 1.15;
  }

  .cargo-stock-manager .inventory-product-ean {
    margin-top: 2px;
    color: #6f6f6f;
    font-size: 11px;
    line-height: 1.15;
    font-variant-numeric: tabular-nums;
    border: 0;
    background: transparent;
    padding: 0;
    text-align: left;
    cursor: pointer;
  }

  .cargo-stock-manager .inventory-product-ean:hover,
  .cargo-stock-manager .inventory-product-ean:focus {
    color: #25b9d7;
    outline: none;
  }

  .cargo-stock-manager .inventory-product-ean.is-copied {
    color: #4f955d;
  }

  .cargo-stock-manager .inventory-calculated-metric {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 64px;
    color: #264355;
    font-weight: 700;
  }

  .cargo-stock-manager .inventory-calculated-metric.is-negative {
    color: #bb4d4d;
  }

  .cargo-stock-manager .inventory-no-image {
    color: #777;
  }

  .cargo-stock-manager .inline-editor {
    display: inline-flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
  }

  .cargo-stock-manager .inline-editor-input {
    width: 96px !important;
    min-width: 96px;
    text-align: center;
    margin: 0 auto;
  }

  .cargo-stock-manager .inline-editor input[type="number"] {
    -moz-appearance: textfield;
  }

  .cargo-stock-manager .inline-editor input[type="number"]::-webkit-outer-spin-button,
  .cargo-stock-manager .inline-editor input[type="number"]::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
  }

  .cargo-stock-manager .volume-editor-grid {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
    flex-wrap: nowrap;
  }

  .cargo-stock-manager .volume-editor-grid .volume-input-main {
    width: 84px !important;
    min-width: 84px;
  }

  .cargo-stock-manager .volume-editor-grid .volume-dimension-input {
    width: 58px !important;
    min-width: 58px;
  }

  .cargo-stock-manager .volume-editor-grid .carton-dimension-input {
    width: 58px !important;
    min-width: 58px;
  }

  .cargo-stock-manager .volume-editor-grid .volume-editor-equals,
  .cargo-stock-manager .volume-editor-grid .volume-editor-separator,
  .cargo-stock-manager .volume-editor-grid .volume-editor-unit {
    color: #8193a1;
    font-weight: 700;
    line-height: 1;
    user-select: none;
  }

  .cargo-stock-manager .inline-editor-actions {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    flex-wrap: nowrap;
  }

  .cargo-stock-manager .inline-editor-actions .btn {
    min-width: 88px;
    margin: 0;
  }

  .cargo-stock-manager .weight-editor .inline-editor-actions {
    gap: 6px;
  }

  .cargo-stock-manager .weight-editor .inline-editor-actions .btn {
    min-width: 0;
    padding: 6px 12px;
    line-height: 1.2;
  }

  .cargo-stock-manager .weight-editor .save-weight {
    min-width: 38px;
    padding: 6px 10px;
  }

  .cargo-stock-manager .save-price,
  .cargo-stock-manager .save-retail-price,
  .cargo-stock-manager .save-quantity {
    min-width: 38px;
    padding: 6px 10px;
  }

  .cargo-stock-manager .inventory-summary-row td {
    background: #fafafa !important;
    font-weight: 700;
  }

  .cargo-stock-manager .inventory-head-title,
  .cargo-stock-manager .inventory-head-subtitle {
    display: block;
  }

  .cargo-stock-manager .inventory-head-subtitle {
    margin-top: 2px;
  }

  .cargo-stock-manager .inventory-col-active .ps-switch {
    display: inline-block;
  }

  .cargo-stock-manager .inventory-actions-menu {
    position: relative;
    display: inline-flex;
    justify-content: center;
  }

  .cargo-stock-manager .inventory-actions-toggle {
    position: relative;
  }

  .cargo-stock-manager .inventory-filter-toggle {
    min-width: 132px;
    border: 1px solid #c9d2db !important;
    background: #f5f7fa !important;
    color: #51606d !important;
    box-shadow: none !important;
    transition: background .18s ease, border-color .18s ease, color .18s ease !important;
  }

  .cargo-stock-manager .inventory-filter-toggle:hover,
  .cargo-stock-manager .inventory-filter-toggle:focus {
    background: #eef2f6 !important;
    border-color: #bbc7d1 !important;
    color: #3f4d59 !important;
    box-shadow: none !important;
  }

  .cargo-stock-manager .inventory-filter-toggle i {
    font-size: 15px !important;
    line-height: 1;
  }

  .cargo-stock-manager .inventory-filter-toggle-label {
    display: inline-block;
    font-size: 14px !important;
    line-height: 1;
  }

  .cargo-stock-manager .inventory-update-btn {
    min-width: 154px;
    border: 1px solid #d94b56 !important;
    background: #e74c5b !important;
    color: #fff !important;
    box-shadow: none !important;
  }

  .cargo-stock-manager .inventory-update-btn:hover,
  .cargo-stock-manager .inventory-update-btn:focus {
    background: #d83c4c !important;
    border-color: #ca3242 !important;
    color: #fff !important;
    box-shadow: none !important;
  }

  .cargo-stock-manager .inventory-update-btn i,
  .cargo-stock-manager .inventory-update-btn-label {
    color: inherit !important;
  }

  .cargo-stock-manager .inventory-update-btn-icon {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 18px;
    height: 18px;
    color: inherit !important;
    flex: 0 0 18px;
  }

  .cargo-stock-manager .inventory-update-btn-icon svg {
    display: block;
    width: 18px;
    height: 18px;
  }

  .cargo-stock-manager .inventory-actions-dropdown {
    position: absolute;
    top: calc(100% + 8px);
    right: 0;
    z-index: 30;
    min-width: 220px;
    padding: 8px 0;
    border: 1px solid #e3e3e3;
    background: #fff;
    box-shadow: 0 8px 18px rgba(0, 0, 0, 0.12);
    display: none;
    text-align: left;
  }

  .cargo-stock-manager .inventory-actions-menu.is-open .inventory-actions-dropdown {
    display: block;
  }

  .cargo-stock-manager .inventory-actions-dropdown button {
    width: 100%;
    padding: 12px 16px;
    border: 0;
    background: transparent;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 15px;
    color: #222;
    text-align: left;
  }

  .cargo-stock-manager .inventory-actions-dropdown button:hover {
    background: #f5f7fa;
  }

  .cargo-stock-manager .inventory-actions-dropdown i {
    width: 18px;
    color: #8a8a8a;
    text-align: center;
  }

  .cargo-stock-manager .inventory-row-actions {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 4px;
  }

  .cargo-stock-manager .inventory-sales-trigger,
  .cargo-stock-manager .inventory-orders-trigger,
  .cargo-stock-manager .inventory-module-edit-trigger,
  .cargo-stock-manager .inventory-profit-trigger,
  .cargo-stock-manager .inventory-hide-product-icon {
    background: none;
    border: none;
    padding: 0;
    box-shadow: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: #6c7a8d;
    transition: color .15s ease;
    text-decoration: none;
  }

  .cargo-stock-manager .inventory-sales-trigger:hover,
  .cargo-stock-manager .inventory-sales-trigger:focus,
  .cargo-stock-manager .inventory-orders-trigger:hover,
  .cargo-stock-manager .inventory-orders-trigger:focus,
  .cargo-stock-manager .inventory-module-edit-trigger:hover,
  .cargo-stock-manager .inventory-module-edit-trigger:focus,
  .cargo-stock-manager .inventory-profit-trigger:hover,
  .cargo-stock-manager .inventory-profit-trigger:focus {
    color: #25b9d7;
    box-shadow: none;
    text-decoration: none;
  }

  .cargo-stock-manager .inventory-hide-product-icon:hover,
  .cargo-stock-manager .inventory-hide-product-icon:focus {
    color: #c0392b;
    box-shadow: none;
    text-decoration: none;
  }

  .cargo-stock-manager .inventory-sales-trigger .material-icons,
  .cargo-stock-manager .inventory-orders-trigger .material-icons,
  .cargo-stock-manager .inventory-module-edit-trigger .material-icons,
  .cargo-stock-manager .inventory-profit-trigger .material-icons,
  .cargo-stock-manager .inventory-hide-product-icon .material-icons {
    font-size: 22px;
    line-height: 1;
  }

  .inventory-profit-modal .inventory-marketplace-settings {
    margin-bottom: 14px;
    padding: 14px 16px;
    border: 1px solid #dbe6ed;
    border-radius: 14px;
    background: linear-gradient(180deg, #fdfefe 0%, #f5f9fc 100%);
  }

  .inventory-profit-modal .inventory-marketplace-settings-title {
    margin-bottom: 10px;
    font-size: 12px;
    font-weight: 700;
    letter-spacing: .08em;
    text-transform: uppercase;
    color: #6f8594;
  }

  .inventory-profit-modal .inventory-marketplace-settings-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 12px;
  }

  .inventory-profit-modal .inventory-marketplace-setting {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 10px;
    min-width: 0;
    padding: 10px 12px;
    border-radius: 12px;
    background: #fff;
    border: 1px solid #e2ecf2;
  }

  .inventory-profit-modal .inventory-marketplace-setting-label {
    font-size: 12px;
    color: #6f8594;
    white-space: nowrap;
  }

  .inventory-profit-modal .inventory-marketplace-setting-copy {
    display: grid;
    gap: 4px;
    min-width: 0;
  }

  .inventory-profit-modal .inventory-marketplace-setting-description {
    font-size: 11px;
    line-height: 1.45;
    color: #8ba0af;
    max-width: 360px;
  }

  .inventory-profit-modal .inventory-marketplace-setting-value {
    display: inline-flex;
    align-items: center;
    min-height: 24px;
    font-size: 13px;
    font-weight: 700;
    color: #1f3442;
    cursor: pointer;
    text-decoration: underline dotted;
    text-underline-offset: 3px;
    white-space: nowrap;
  }

  .inventory-profit-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 14px;
  }

  .inventory-profit-card {
    border: 1px solid rgba(208, 222, 234, 0.95);
    border-radius: 22px;
    padding: 16px;
    background: linear-gradient(180deg, #ffffff 0%, #f8fbfd 100%);
    box-shadow: 0 10px 24px rgba(17, 33, 45, 0.05);
  }

  .inventory-profit-card-label {
    display: inline-flex;
    align-items: center;
    min-height: 30px;
    padding: 0 11px;
    border-radius: 10px;
    font-size: 13px;
    font-weight: 800;
    color: #f5fbff;
    margin-bottom: 12px;
  }

  .inventory-profit-card.is-store .inventory-profit-card-label {
    background: linear-gradient(135deg, #1f8eaf 0%, #42bfdc 100%);
  }

  .inventory-profit-card.is-marketplace .inventory-profit-card-label {
    background: linear-gradient(135deg, #2f9666 0%, #3eb77d 100%);
  }

  .inventory-profit-price {
    margin-bottom: 12px;
    font-size: 24px;
    font-weight: 800;
    color: #20303b;
  }

  .inventory-profit-lines {
    display: grid;
    gap: 6px;
  }

  .inventory-profit-line {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    gap: 12px;
    padding-top: 6px;
    border-top: 1px solid rgba(208, 222, 234, 0.7);
    color: #5d7687;
    font-size: 13px;
  }

  .inventory-profit-line strong {
    color: #12232f;
    font-weight: 800;
  }

  .inventory-profit-line strong.inventory-profit-value {
    display: inline-flex;
    align-items: center;
    padding: 4px 10px;
    border-radius: 999px;
  }

  .inventory-profit-line strong.inventory-profit-value.is-positive {
    background: rgba(50, 168, 82, 0.14);
    color: #1f7a39;
  }

  .inventory-profit-line strong.inventory-profit-value.is-negative {
    background: rgba(212, 72, 72, 0.14);
    color: #a52d2d;
  }

  .inventory-profit-line strong.inventory-percent-value.is-negative {
    color: #a52d2d;
  }

  .inventory-sales-modal {
    position: fixed;
    inset: 0;
    z-index: 1050;
    display: none;
  }

  .inventory-sales-modal.is-open {
    display: block;
  }

  .inventory-sales-modal-backdrop {
    position: absolute;
    inset: 0;
    background: rgba(11, 20, 28, 0.58);
    backdrop-filter: blur(6px);
  }

  .inventory-sales-modal-dialog {
    position: relative;
    width: min(1120px, calc(100vw - 40px));
    margin: 34px auto;
    border-radius: 32px;
    background:
      radial-gradient(circle at top left, rgba(29, 141, 177, 0.08), transparent 24%),
      linear-gradient(180deg, #ffffff 0%, #f6f9fc 100%);
    box-shadow: 0 34px 90px rgba(11, 20, 28, 0.24);
    padding: 34px 32px 30px;
    overflow: hidden;
  }

  .inventory-sales-modal-dialog::before {
    content: "";
    position: absolute;
    inset: 0 0 auto 0;
    height: 6px;
    background: linear-gradient(90deg, #1d8db1 0%, #62c2b2 50%, #f2c14e 100%);
  }

  .inventory-sales-modal-close {
    position: absolute;
    top: 18px;
    right: 18px;
    width: 52px;
    height: 52px;
    border: 0;
    border-radius: 999px;
    background: linear-gradient(180deg, rgba(12, 32, 44, 0.05) 0%, rgba(12, 32, 44, 0.09) 100%);
    color: transparent;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 0;
    line-height: 1;
    padding: 0;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.85);
    transition: transform .18s ease, box-shadow .18s ease, background .18s ease;
  }

  .inventory-sales-modal-close::before,
  .inventory-sales-modal-close::after {
    content: "";
    position: absolute;
    width: 22px;
    height: 3px;
    border-radius: 999px;
    background: #60798a;
  }

  .inventory-sales-modal-close::before {
    transform: rotate(45deg);
  }

  .inventory-sales-modal-close::after {
    transform: rotate(-45deg);
  }

  .inventory-sales-modal-close:hover,
  .inventory-sales-modal-close:focus {
    background: linear-gradient(180deg, rgba(12, 32, 44, 0.09) 0%, rgba(12, 32, 44, 0.13) 100%);
    box-shadow: 0 10px 20px rgba(18, 48, 64, 0.12);
    transform: translateY(-1px);
  }

  .inventory-sales-modal-head {
    margin-bottom: 16px;
    padding: 10px 86px 8px 4px;
    border-bottom: 0;
  }

  .inventory-sales-modal-media {
    display: flex;
    align-items: flex-start;
    gap: 18px;
    min-width: 0;
  }

  .inventory-sales-modal-thumb-wrap {
    width: 84px;
    height: 84px;
    flex: 0 0 84px;
    position: relative;
    padding: 6px;
    border-radius: 22px;
    background: #ffffff;
    border: 1px solid rgba(198, 214, 227, 0.9);
    box-shadow: 0 14px 28px rgba(22, 52, 71, 0.08);
  }

  .inventory-sales-modal-thumb,
  .inventory-sales-modal-thumb-fallback {
    width: 100%;
    height: 100%;
    border-radius: 16px;
    display: block;
  }

  .inventory-sales-modal-thumb {
    object-fit: cover;
    background: #eef4f8;
  }

  .inventory-sales-modal-thumb.is-hidden {
    display: none;
  }

  .inventory-sales-modal-thumb-fallback {
    display: none;
    background: linear-gradient(135deg, #173548 0%, #2b6a84 100%);
  }

  .inventory-sales-modal-thumb-fallback.is-visible {
    display: block;
  }

  .inventory-sales-modal-copy {
    min-width: 0;
    padding-top: 4px;
    background: transparent;
  }

  .inventory-sales-modal-title {
    margin: 0;
    max-width: 860px;
    padding: 0 !important;
    font-size: clamp(16px, 1.15vw, 20px);
    line-height: 1.35;
    letter-spacing: -.01em;
    color: #60798a;
    font-weight: 600;
    word-break: break-word;
    text-wrap: pretty;
    text-decoration: none;
    background: transparent;
    border: 0 !important;
    border-bottom: 0 !important;
    box-shadow: none !important;
    outline: 0;
  }

  .inventory-sales-modal-subtitle {
    margin-top: 6px;
    font-size: clamp(16px, 1.15vw, 20px);
    line-height: 1.35;
    color: #60798a;
    font-weight: 600;
    word-break: break-word;
    text-wrap: pretty;
  }

  .inventory-sales-modal-subtitle:empty {
    display: none;
  }

  .inventory-sales-modal-state {
    display: none;
    padding: 24px;
    border-radius: 18px;
    background: #f4f7fa;
    color: #51606d;
    text-align: center;
    font-size: 15px;
    font-weight: 600;
  }

  .inventory-sales-modal-state.is-visible {
    display: block;
  }

  .inventory-sales-modal-content {
    display: none;
  }

  .inventory-sales-modal-content.is-visible {
    display: block;
  }

  /* ── Scanner button ── */
  .inventory-scanner-btn.scanner-active {
    background: #25b9d7;
    border-color: #25b9d7;
    color: #fff;
    box-shadow: 0 0 0 3px rgba(37, 185, 215, 0.28);
  }

  /* ── Scanner active badge (floating) ── */
  .inventory-scanner-badge {
    position: fixed;
    bottom: 28px;
    right: 28px;
    z-index: 1045;
    display: none;
    align-items: center;
    gap: 8px;
    background: #1d8db1;
    color: #fff;
    font-size: 13px;
    font-weight: 600;
    border-radius: 999px;
    padding: 10px 14px 10px 14px;
    box-shadow: 0 8px 28px rgba(18, 48, 64, 0.32);
    cursor: default;
    user-select: none;
  }

  .inventory-scanner-badge.is-active {
    display: flex;
  }

  .inventory-scanner-badge .material-icons:first-child {
    font-size: 20px;
    animation: scanner-pulse 1.6s ease-in-out infinite;
  }

  .inventory-scanner-badge-close {
    font-size: 18px !important;
    cursor: pointer;
    opacity: 0.7;
    margin-left: 4px;
    transition: opacity .15s;
  }

  .inventory-scanner-badge-close:hover {
    opacity: 1;
  }

  @keyframes scanner-pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.35; }
  }

  /* ── Scanner modal ── */
  .inventory-scanner-modal {
    position: fixed;
    inset: 0;
    z-index: 1050;
    display: none;
  }

  .inventory-scanner-modal.is-open {
    display: block;
  }

  .inventory-scanner-modal-backdrop {
    position: absolute;
    inset: 0;
    background: rgba(11, 20, 28, 0.55);
    backdrop-filter: blur(6px);
  }

  .inventory-scanner-modal-dialog {
    position: relative;
    width: min(860px, calc(100vw - 32px));
    max-height: calc(100vh - 24px);
    margin: 12px auto;
    border-radius: 28px;
    background: linear-gradient(180deg, #ffffff 0%, #f6f9fc 100%);
    border: 1px solid rgba(192, 212, 226, 0.86);
    box-shadow: 0 28px 78px rgba(11, 20, 28, 0.22);
    padding: 22px 22px 18px;
    overflow: hidden;
    display: flex;
    flex-direction: column;
  }

  .inventory-scanner-modal.is-battery-mode .inventory-scanner-modal-dialog {
    width: 100%;
    max-width: none;
    max-height: none;
    height: 100%;
    margin: 0;
    padding: 0;
    border: 0;
    border-radius: 0;
    background: transparent;
    box-shadow: none;
    overflow: visible;
  }

  .inventory-scanner-modal.is-battery-mode .inventory-scanner-modal-dialog::before {
    display: none;
  }

  .inventory-scanner-modal.is-battery-mode .inventory-scanner-modal-close {
    display: none;
  }

  .inventory-scanner-modal.is-battery-mode .inventory-scanner-modal-head {
    display: none;
  }

  .inventory-scanner-modal.is-battery-mode .inventory-scanner-modal-content {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100%;
    overflow: visible;
    padding: 0;
  }

  .inventory-scanner-modal-dialog::before {
    content: "";
    position: absolute;
    inset: 0 0 auto 0;
    height: 4px;
    background: linear-gradient(90deg, #1d8db1 0%, #62c2b2 100%);
    border-radius: 28px 28px 0 0;
  }

  .inventory-scanner-modal-head {
    margin-bottom: 14px;
    padding: 6px 52px 14px 2px;
    border-bottom: 1px solid rgba(198, 214, 227, 0.72);
  }

  #inventoryScannerModal .inventory-sales-modal-thumb-wrap {
    width: 104px;
    height: 104px;
    flex: 0 0 104px;
    border-radius: 20px;
    padding: 6px;
  }

  #inventoryScannerModal .inventory-sales-modal-thumb,
  #inventoryScannerModal .inventory-sales-modal-thumb-fallback {
    border-radius: 18px;
  }

  #inventoryScannerModal .inventory-sales-modal-title {
    font-size: clamp(16px, 1.45vw, 23px);
    line-height: 1.1;
    font-weight: 750;
    color: #577185;
  }

  #inventoryScannerModal .inventory-sales-modal-subtitle {
    font-size: clamp(12px, 0.95vw, 15px);
    line-height: 1.35;
    margin-top: 6px;
    color: #607a8e;
  }

  .inventory-scanner-modal-ean {
    margin-top: 10px;
    display: block;
    padding: 0;
    color: #233746;
  }

  .inventory-scanner-modal-ean-wrap {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    width: 150px;
    height: 50px;
    padding: 4px 3px;
    border: 1px solid rgba(192, 212, 226, 0.72);
    border-radius: 6px;
    background: #ffffff;
  }

  .inventory-scanner-modal-ean-barcode {
    width: 100%;
    height: 36px;
    display: block;
    background: transparent;
  }

  .inventory-scanner-modal-ean-text {
    font-size: 10px;
    line-height: 1;
    font-weight: 700;
    color: #111111;
    letter-spacing: 0.02em;
    text-align: center;
    width: 100%;
    font-variant-numeric: tabular-nums;
    font-family: "Courier New", Courier, monospace;
  }

  .inventory-scanner-modal-ean.is-fallback {
    align-items: center;
    min-height: 34px;
    padding: 4px 10px;
    font-size: clamp(13px, 0.95vw, 17px);
    line-height: 1.1;
    font-weight: 700;
    color: #7891a3;
    font-variant-numeric: tabular-nums;
    letter-spacing: 0.025em;
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  }

  .inventory-scanner-modal-content {
    display: block;
    align-content: start;
    overflow: auto;
    padding-right: 2px;
  }

  .inventory-scanner-modal-content.is-battery {
    display: flex;
    align-items: center;
    justify-content: center;
    padding-right: 0;
    overflow: visible;
  }

  .inventory-scanner-battery-card {
    padding: 10px 14px;
    text-align: center;
    color: #ffffff;
    text-shadow: 0 3px 14px rgba(4, 10, 16, 0.45);
  }

  .inventory-scanner-battery-glyph {
    position: relative;
    display: flex;
    align-items: center;
    gap: 4px;
    width: 74px;
    height: 36px;
    padding: 4px 6px;
    margin: 0 auto 10px;
    border: 3px solid rgba(255, 255, 255, 0.96);
    border-radius: 7px;
    box-sizing: border-box;
  }

  .inventory-scanner-battery-glyph::after {
    content: "";
    position: absolute;
    right: -7px;
    top: 9px;
    width: 5px;
    height: 12px;
    border-radius: 2px;
    background: rgba(255, 255, 255, 0.96);
  }

  .inventory-scanner-battery-bar {
    flex: 1 1 0;
    height: 100%;
    border-radius: 2px;
    background: rgba(255, 255, 255, 0.24);
  }

  .inventory-scanner-battery-bar.is-on {
    background: #ffffff;
  }

  .inventory-scanner-battery-level {
    font-size: 44px;
    line-height: 1.05;
    font-weight: 800;
    color: #ffffff;
    letter-spacing: -0.02em;
  }

  .inventory-scanner-battery-note {
    margin-top: 8px;
    font-size: 16px;
    line-height: 1.3;
    color: rgba(255, 255, 255, 0.96);
  }

  .inventory-scanner-modal-row {
    display: flex;
    flex-direction: column;
    gap: 6px;
    border: 1px solid rgba(196, 215, 229, 0.86);
    background: linear-gradient(180deg, rgba(255, 255, 255, 0.96) 0%, rgba(245, 250, 255, 0.88) 100%);
    border-radius: 14px;
    padding: 11px 12px 12px;
    box-shadow: 0 7px 16px rgba(23, 53, 72, 0.06);
  }

  .inventory-scanner-modal-row.full {
    grid-column: 1 / -1;
  }

  .inventory-scanner-modal-label {
    font-size: clamp(10px, 0.68vw, 12px);
    font-weight: 700;
    color: #8097a9;
    letter-spacing: 0.06em;
    text-transform: uppercase;
  }

  .inventory-scanner-modal-value {
    font-size: clamp(24px, 1.65vw, 32px);
    font-weight: 700;
    color: #1a2c38;
    line-height: 1.05;
    letter-spacing: -0.015em;
  }

  .inventory-scanner-modal-value.is-compact {
    font-size: clamp(14px, 0.95vw, 19px);
    line-height: 1.28;
    letter-spacing: 0;
    font-weight: 600;
  }

  .inventory-scanner-modal-value.is-compact .inventory-scanner-edit-value {
    font-size: inherit;
    line-height: inherit;
    font-weight: inherit;
    letter-spacing: inherit;
  }

  .inventory-scanner-modal-row.is-qty {
    background: linear-gradient(180deg, #173548 0%, #234b62 100%);
    border-color: rgba(26, 67, 92, 0.95);
    box-shadow: 0 10px 20px rgba(15, 38, 53, 0.22);
  }

  .inventory-scanner-modal-row.is-qty .inventory-scanner-modal-label {
    color: rgba(217, 234, 245, 0.9);
  }

  .inventory-scanner-modal-row.is-qty .inventory-scanner-modal-value,
  .inventory-scanner-modal-row.is-qty .inventory-scanner-modal-value .inventory-scanner-edit-value {
    color: #f2fbff;
  }

  .inventory-scanner-modal-row.is-qty .inventory-scanner-edit-value {
    border-bottom-color: rgba(228, 244, 251, 0.6);
  }

  .inventory-scanner-modal-row.is-qty .inventory-scanner-edit-value:hover {
    border-bottom-color: rgba(255, 255, 255, 0.9);
  }

  .inventory-scanner-modal-value.is-zero {
    color: #c0392b;
  }

  .inventory-scanner-edit-value {
    border: 0;
    background: transparent;
    padding: 0;
    margin: 0;
    text-align: left;
    color: inherit;
    font: inherit;
    cursor: pointer;
    border-bottom: 2px dotted rgba(95, 119, 138, 0.4);
  }

  .inventory-scanner-edit-value:hover {
    border-bottom-color: rgba(95, 119, 138, 0.8);
  }

  .inventory-scanner-edit-input {
    width: min(360px, 100%);
    font-size: clamp(18px, 1.4vw, 24px);
    line-height: 1.15;
    font-weight: 600;
    color: #1a2c38;
    border: 1px solid #c5d5e2;
    border-radius: 10px;
    padding: 6px 10px;
    background: #fff;
    outline: none;
  }

  .inventory-scanner-modal-not-found {
    grid-column: 1 / -1;
    text-align: center;
    padding: 20px 0 8px;
    color: #8a9db0;
    font-size: 15px;
  }

  .inventory-scanner-modal-not-found .material-icons {
    font-size: 52px;
    color: #d0d9e0;
    display: block;
    margin: 0 auto 12px;
  }

  #inventoryScannerModal .inventory-profit-grid {
    align-items: start;
  }

  #inventoryScannerModal .inventory-profit-card {
    min-height: 100%;
  }

  #inventoryScannerModal .inventory-profit-card.full {
    grid-column: 1 / -1;
  }

  #inventoryScannerModal .inventory-profit-card.is-logistics .inventory-profit-card-label {
    background: linear-gradient(135deg, #1f8eaf 0%, #42bfdc 100%);
  }

  #inventoryScannerModal .inventory-profit-card.is-details .inventory-profit-card-label {
    background: linear-gradient(135deg, #7f5f18 0%, #d3a63b 100%);
    color: #fffaf0;
  }

  #inventoryScannerModal .inventory-profit-card.is-additional .inventory-profit-card-label {
    background: linear-gradient(135deg, #2f9666 0%, #3eb77d 100%);
    color: #f3fff8;
  }

  #inventoryScannerModal .inventory-profit-card-header {
    margin-bottom: 12px;
    font-size: 20px;
    font-weight: 800;
    color: #20303b;
    line-height: 1.15;
  }

  #inventoryScannerModal .inventory-profit-lines {
    gap: 8px;
  }

  #inventoryScannerModal .inventory-profit-line.inventory-scanner-line {
    align-items: flex-start;
    padding-top: 8px;
  }

  #inventoryScannerModal .inventory-profit-line.inventory-scanner-line span {
    text-transform: uppercase;
    letter-spacing: .08em;
    font-size: 11px;
    color: #7b8f9e;
    flex: 0 0 auto;
  }

  #inventoryScannerModal .inventory-profit-line.inventory-scanner-line strong {
    text-align: right;
    font-size: 15px;
    line-height: 1.35;
    min-width: 0;
  }

  #inventoryScannerModal .inventory-profit-line.inventory-scanner-line strong.is-zero {
    color: #c0392b;
  }

  #inventoryScannerModal .inventory-profit-line.inventory-scanner-line.is-description {
    display: grid;
    gap: 8px;
  }

  #inventoryScannerModal .inventory-profit-line.inventory-scanner-line.is-description strong {
    text-align: left;
  }

  #inventoryScannerModal .inventory-profit-line.inventory-scanner-line .inventory-scanner-edit-value {
    display: inline-block;
    text-align: inherit;
    border-bottom: 2px dotted rgba(95, 119, 138, 0.4);
  }

  #inventoryScannerModal .inventory-profit-line.inventory-scanner-line .inventory-scanner-edit-input {
    width: min(420px, 100%);
    font-size: 15px;
    line-height: 1.35;
  }

  .inventory-sales-summary {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 12px;
    margin-bottom: 14px;
  }

  .inventory-sales-summary-card {
    min-height: 0;
    border-radius: 22px;
    padding: 14px 16px 12px;
    background:
      radial-gradient(circle at top right, rgba(29, 141, 177, 0.07), transparent 34%),
      linear-gradient(180deg, #ffffff 0%, #f8fbfd 100%);
    border: 1px solid rgba(208, 222, 234, 0.95);
    box-shadow: 0 10px 24px rgba(17, 33, 45, 0.05);
  }

  .inventory-sales-summary-label {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 30px;
    padding: 0 11px;
    border-radius: 10px;
    background: linear-gradient(135deg, #173548 0%, #234b62 100%);
    color: #f5fbff;
    font-size: 13px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .12em;
  }

  .inventory-sales-summary-card.is-earliest .inventory-sales-summary-label {
    background: linear-gradient(135deg, rgba(196, 144, 22, 1) 0%, rgba(224, 170, 40, 1) 100%);
    color: #fffaf0;
  }

  .inventory-sales-summary-card.is-previous .inventory-sales-summary-label {
    background: linear-gradient(135deg, #1f8eaf 0%, #42bfdc 100%);
    color: #f4fcff;
  }

  .inventory-sales-summary-card.is-current .inventory-sales-summary-label {
    background: linear-gradient(135deg, #2f9666 0%, #3eb77d 100%);
    color: #f3fff8;
  }

  .inventory-sales-summary-value {
    display: flex;
    align-items: center;
    gap: 10px;
    max-width: 100%;
    font-size: clamp(15px, 1.02vw, 18px);
    line-height: 1.2;
    font-weight: 800;
    letter-spacing: -.025em;
    color: #12232f;
  }

  .inventory-sales-summary-text {
    min-width: 0;
  }

  .inventory-sales-summary-note {
    margin-top: 10px;
  }

  .inventory-sales-summary-note strong {
    color: #12232f;
    font-weight: 800;
  }

  .inventory-sales-summary-lines {
    display: grid;
    gap: 4px;
  }

  .inventory-sales-summary-line {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    gap: 12px;
    color: #5d7687;
    font-size: 12px;
    line-height: 1.32;
    padding-top: 5px;
    border-top: 1px solid rgba(208, 222, 234, 0.7);
  }

  .inventory-sales-summary-line-label {
    text-transform: uppercase;
    letter-spacing: .08em;
    font-size: 11px;
    color: #7b8f9e;
    flex: 0 0 auto;
  }

  .inventory-sales-summary-line-value {
    text-align: right;
  }

  .inventory-sales-summary-line-value .inventory-sales-channel-profit {
    display: block;
  }

  .inventory-sales-chart {
    border-radius: 24px;
    padding: 14px 14px;
    background:
      radial-gradient(circle at top right, rgba(61, 198, 228, 0.12), transparent 28%),
      radial-gradient(circle at bottom left, rgba(245, 197, 92, 0.12), transparent 24%),
      linear-gradient(180deg, #f9fcff 0%, #eef5fb 100%);
    color: #19374a;
    box-shadow: 0 16px 32px rgba(24, 50, 68, 0.08);
  }

  .inventory-sales-chart-layout {
    display: grid;
    grid-template-columns: 42px minmax(0, 1fr) 42px;
    gap: 8px;
    align-items: center;
  }

  .inventory-sales-chart-panel {
    min-width: 0;
  }

  .inventory-sales-chart-meta {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    margin-bottom: 8px;
  }

  .inventory-sales-chart-range {
    font-size: 13px;
    text-transform: uppercase;
    letter-spacing: .12em;
    line-height: 1.3;
    color: rgba(56, 97, 121, 0.72);
  }

  .inventory-sales-chart-year {
    font-size: 15px;
    line-height: 1;
    font-weight: 800;
    letter-spacing: .02em;
    color: #1c3f52;
  }

  .inventory-sales-chart-surface {
    border-radius: 18px;
    background:
      linear-gradient(180deg, rgba(255, 255, 255, 0.98) 0%, rgba(244, 249, 253, 0.98) 100%);
    padding: 10px 10px 8px;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.92), 0 8px 18px rgba(27, 59, 77, 0.04);
    border: 1px solid rgba(194, 214, 229, 0.78);
  }

  .inventory-sales-chart-canvas {
    width: 100%;
    height: 220px;
    position: relative;
  }

  .inventory-sales-chart-canvas canvas {
    width: 100% !important;
    height: 100% !important;
    display: block;
  }

  .inventory-sales-chart-footnote {
    display: none;
  }

  .inventory-sales-nav {
    align-self: center;
    width: 48px;
    height: 48px;
    border: 0;
    border-radius: 999px;
    background: rgba(255, 255, 255, 0.94);
    color: #60798a;
    box-shadow: 0 12px 24px rgba(12, 32, 44, 0.18);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    font-weight: 600;
    line-height: 1;
    transition: transform .18s ease, box-shadow .18s ease, opacity .18s ease;
  }

  .inventory-sales-nav span[aria-hidden="true"] {
    display: block;
    font-size: 36px;
    font-family: Arial, sans-serif;
    font-weight: 400;
    line-height: .7;
    transform: translateY(-1px);
    color: #60798a;
  }

  .inventory-sales-nav:hover,
  .inventory-sales-nav:focus {
    transform: translateY(-1px) scale(1.02);
    box-shadow: 0 16px 30px rgba(12, 32, 44, 0.22);
  }

  .inventory-sales-nav.is-disabled {
    opacity: .35;
    pointer-events: none;
  }

  @media (max-width: 900px) {
    .cargo-stock-manager .inventory-marketplace-settings-grid {
      grid-template-columns: 1fr;
    }

    .cargo-stock-manager .inventory-marketplace-setting {
      justify-content: space-between;
    }

    .inventory-sales-summary {
      grid-template-columns: 1fr;
    }

    .inventory-sales-chart-layout {
      grid-template-columns: 1fr;
      gap: 10px;
    }

    .inventory-sales-modal-dialog {
      width: calc(100vw - 20px);
      margin: 24px auto;
      padding: 26px 18px 18px;
    }

    .inventory-sales-modal-head {
      padding: 4px 56px 8px 0;
    }

    .inventory-sales-modal-title {
      font-size: 18px;
    }

    .inventory-sales-modal-thumb-wrap {
      width: 64px;
      height: 64px;
    }

    .inventory-sales-nav {
      width: 42px;
      height: 42px;
      justify-self: center;
    }

    .inventory-sales-summary-line {
      flex-direction: column;
      align-items: flex-start;
      gap: 4px;
    }

    .inventory-sales-summary-line-value {
      text-align: left;
    }

    .inventory-sales-chart {
      padding: 12px 10px;
    }

    .inventory-sales-chart-canvas {
      height: 190px;
    }

    .inventory-scanner-modal-dialog {
      width: calc(100vw - 16px);
      max-height: calc(100vh - 16px);
      margin: 8px auto;
      padding: 18px 12px 12px;
      border-radius: 22px;
    }

    .inventory-scanner-modal-head {
      padding: 4px 44px 12px 0;
      margin-bottom: 10px;
    }

    #inventoryScannerModal .inventory-sales-modal-media {
      gap: 10px;
    }

    #inventoryScannerModal .inventory-sales-modal-thumb-wrap {
      width: 76px;
      height: 76px;
      flex: 0 0 76px;
      border-radius: 16px;
    }

    #inventoryScannerModal .inventory-sales-modal-thumb,
    #inventoryScannerModal .inventory-sales-modal-thumb-fallback {
      border-radius: 12px;
    }

    #inventoryScannerModal .inventory-sales-modal-title {
      font-size: 16px;
      line-height: 1.15;
    }

    #inventoryScannerModal .inventory-sales-modal-subtitle {
      font-size: 12px;
    }

    .inventory-scanner-modal-ean {
      margin-top: 8px;
      padding: 0;
    }

    .inventory-scanner-modal-ean-wrap {
      width: 150px;
      height: 50px;
    }

    .inventory-scanner-modal-ean-barcode {
      width: 100%;
      height: 36px;
    }

    .inventory-scanner-modal-ean-text {
      font-size: 10px;
    }

    .inventory-scanner-modal-ean.is-fallback {
      min-height: 30px;
      font-size: 12px;
    }

    .inventory-scanner-modal-content {
      grid-template-columns: 1fr;
      gap: 10px;
    }

    .inventory-scanner-modal.is-battery-mode .inventory-scanner-modal-dialog {
      width: 100%;
      padding: 0;
    }

    .inventory-scanner-battery-glyph {
      width: 66px;
      height: 32px;
    }

    .inventory-scanner-battery-level {
      font-size: 38px;
    }

    .inventory-scanner-battery-note {
      font-size: 14px;
    }

    .inventory-scanner-modal-row {
      padding: 10px 10px 11px;
      border-radius: 12px;
    }

    .inventory-scanner-modal-value {
      font-size: 30px;
      line-height: 1.02;
    }

    .inventory-scanner-modal-value.is-compact {
      font-size: 15px;
      line-height: 1.3;
    }
  }
</style>

<script src="{$inventoryModuleBaseUrl|escape:'html':'UTF-8'}views/js/chart.umd.min.js?v={$inventoryAssetsVersion|default:$inventoryModuleVersion|escape:'url'}"></script>
<script src="{$inventoryModuleBaseUrl|escape:'html':'UTF-8'}views/js/JsBarcode.all.min.js?v={$inventoryAssetsVersion|default:$inventoryModuleVersion|escape:'url'}"></script>
<script>
  {if empty($inventoryEmbeddedInModernLayout)}
  (function () {
    function syncBreadcrumb(currentLabel) {
      var breadcrumb = document.querySelector('.header-toolbar .breadcrumb');
      if (!breadcrumb) {
        return;
      }

      while (breadcrumb.firstChild) {
        breadcrumb.removeChild(breadcrumb.firstChild);
      }

      var catalogItem = document.createElement('li');
      catalogItem.className = 'breadcrumb-item';
      var catalogIcon = document.createElement('i');
      catalogIcon.className = 'material-icons';
      catalogIcon.textContent = 'store';
      catalogItem.appendChild(catalogIcon);
      catalogItem.appendChild(document.createTextNode('Katalog'));
      breadcrumb.appendChild(catalogItem);

      var moduleItem = document.createElement('li');
      moduleItem.className = 'breadcrumb-item';
      var moduleLink = document.createElement('a');
      moduleLink.href = '{$inventoryModuleUrl|escape:'javascript'}';
      moduleLink.textContent = 'Inventory';
      moduleItem.appendChild(moduleLink);
      breadcrumb.appendChild(moduleItem);

      var currentItem = document.createElement('li');
      currentItem.className = 'breadcrumb-item active breadcrumb-item--inventory-current';
      var currentSpan = document.createElement('span');
      currentSpan.textContent = currentLabel;
      currentItem.appendChild(currentSpan);
      breadcrumb.appendChild(currentItem);
    }

    function getDirectContainerFluid(headerToolbar) {
      if (!headerToolbar) {
        return null;
      }

      var children = headerToolbar.children || [];
      for (var i = 0; i < children.length; i++) {
        if (children[i].classList && children[i].classList.contains('container-fluid')) {
          return children[i];
        }
      }

      return headerToolbar.querySelector('.container-fluid');
    }

    function mountBoTabs(sourceId, attempt) {
      var source = document.getElementById(sourceId);
      var pageHead = document.querySelector('.page-head');
      var pageHeadWrapper = pageHead ? pageHead.querySelector('.wrapper.clearfix') : null;
      var contentDiv = document.querySelector('#main-div > .content-div');

      if (!source || !pageHead) {
        if ((attempt || 0) < 100) {
          window.setTimeout(function () {
            mountBoTabs(sourceId, (attempt || 0) + 1);
          }, 100);
          return false;
        }

        if (source) {
          source.hidden = false;
        }
        return false;
      }

      var mounted = document.getElementById('head_tabs');
      if (mounted && mounted !== source && mounted.parentNode) {
        mounted.parentNode.removeChild(mounted);
      }

      if (pageHeadWrapper) {
        if (source.parentNode !== pageHead || source.previousElementSibling !== pageHeadWrapper) {
          pageHeadWrapper.insertAdjacentElement('afterend', source);
        }
      } else if (source.parentNode !== pageHead) {
        pageHead.appendChild(source);
      }

      if (contentDiv) {
        contentDiv.classList.add('with-tabs');
      }

      syncBreadcrumb('Magazyn');

      source.hidden = false;
      return false;
    }

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', function () {
        mountBoTabs('csmgr-head-tabs-source', 0);
      });
    } else {
      mountBoTabs('csmgr-head-tabs-source', 0);
    }

    window.addEventListener('load', function () {
      mountBoTabs('csmgr-head-tabs-source', 0);
    });

    var mountObserver = new MutationObserver(function () {
      mountBoTabs('csmgr-head-tabs-source', 0);
    });
    mountObserver.observe(document.documentElement, {ldelim}childList: true, subtree: true{rdelim});
  window.setTimeout(function () {
      mountObserver.disconnect();
    }, 10000);
  })();
  {/if}

  window.cargoStockManagerConfig = {
    ajaxUrl: '{$inventoryAjaxUrl|escape:'javascript'}',
    exportUrl: '{$inventoryExportUrl|escape:'javascript'}',
    languageIso: '{$inventoryLanguageIso|escape:'javascript'}',
    canEdit: {$inventoryCanEdit|intval},
    moduleVersion: '{$inventoryModuleVersion|escape:'javascript'}',
    licenseValid: {$inventoryLicenseStatus.valid|intval},
    updateConfigured: {$inventoryUpdateConfigured|intval}
  };

  (function () {
    var sourceTranslations = {$inventoryTranslationsJson nofilter};
    var translations = {
      no: sourceTranslations.id,
      title: sourceTranslations.report_title,
      activeOnly: 'Aktywne produkty',
      onlyAvailable: 'Dostępne w magazynie',
      missingPurchasePriceOnly: 'Bez ceny zakupu',
      showWeight: sourceTranslations.product_weight,
      showUnitVolume: sourceTranslations.unit_volume,
      showUnitsPerCarton: sourceTranslations.units_per_carton,
      showCartonDimensions: sourceTranslations.carton_dimensions,
      missingWeightOnly: 'Bez wagi',
      showBrutto: sourceTranslations.retail_price_gross,
      searchPlaceholder: sourceTranslations.search_placeholder,
      picture: sourceTranslations.image,
      name: sourceTranslations.product_name,
      active: sourceTranslations.active,
      weight: sourceTranslations.product_weight,
      unitVolume: sourceTranslations.unit_volume,
      unitsPerCarton: sourceTranslations.units_per_carton,
      cartonDimensions: sourceTranslations.carton_dimensions,
      price: sourceTranslations.purchase_price_net,
      purchasePriceGross: sourceTranslations.purchase_price_gross,
      priceBrutto: sourceTranslations.retail_price_gross,
      qty: sourceTranslations.available_quantity,
      value: sourceTranslations.purchase_value_net,
      valueBrutto: sourceTranslations.retail_value_gross,
      save: sourceTranslations.save,
      cancel: sourceTranslations.cancel,
      enterQty: sourceTranslations.enter_qty,
      enterPrice: sourceTranslations.enter_price,
      enterRetailPrice: sourceTranslations.enter_retail_price,
      enterWeight: sourceTranslations.enter_weight,
      enterUnitVolume: sourceTranslations.enter_unit_volume,
      enterUnitsPerCarton: sourceTranslations.enter_units_per_carton,
      enterCartonDimensions: sourceTranslations.enter_carton_dimensions,
      errorSave: sourceTranslations.error_save,
      errorNetwork: sourceTranslations.error_network,
      errorQtySave: sourceTranslations.error_qty_save,
      errorWeightSave: sourceTranslations.error_weight_save,
      errorHide: sourceTranslations.error_hide,
      hideForever: sourceTranslations.hide_forever,
      typeQty: sourceTranslations.type_qty,
      typePrice: sourceTranslations.type_price,
      typeWeight: sourceTranslations.type_weight,
      typeUnitVolume: sourceTranslations.type_unit_volume,
      typeUnitsPerCarton: sourceTranslations.type_units_per_carton,
      typeCartonDimensions: sourceTranslations.type_carton_dimensions,
      errorToggle: sourceTranslations.error_toggle,
      copied: sourceTranslations.copied,
      copyError: sourceTranslations.copy_error,
      loadError: sourceTranslations.load_error,
      salesChart: sourceTranslations.sales_chart,
      salesStatsTitle: sourceTranslations.sales_stats_title,
      salesStatsLoading: sourceTranslations.sales_stats_loading,
      salesStatsEmpty: sourceTranslations.sales_stats_empty,
      salesMonthsRange: sourceTranslations.sales_months_range,
      salesTotalSold: sourceTranslations.sales_total_sold,
      salesBestMonth: sourceTranslations.sales_best_month,
      salesMonthsCount: sourceTranslations.sales_months_count,
      salesUnits: sourceTranslations.sales_units,
      salesRevenue: sourceTranslations.sales_revenue,
      salesRevenueShort: sourceTranslations.sales_revenue_short,
      salesRevenueNet: sourceTranslations.sales_revenue_net,
      salesRevenueNetShort: sourceTranslations.sales_revenue_net_short,
      estimatedProfitNet: sourceTranslations.estimated_profit_net,
      estimatedProfitGross: sourceTranslations.estimated_profit_gross,
      year: sourceTranslations.year,
      errorSalesStats: sourceTranslations.error_sales_stats,
      close: sourceTranslations.close,
      previousYear: sourceTranslations.previous_year,
      nextYear: sourceTranslations.next_year,
      profitability: sourceTranslations.profitability,
      storePrice: sourceTranslations.store_price,
      marketplacePrice: sourceTranslations.marketplace_price,
      storeChannel: sourceTranslations.store_channel,
      marketplaceChannel: sourceTranslations.marketplace_channel,
      profitabilityMarkup: sourceTranslations.profitability_markup,
      profitabilityMargin: sourceTranslations.profitability_margin,
      profitabilityProfit: sourceTranslations.profitability_profit,
      marketplaceMarkup: sourceTranslations.marketplace_markup,
      marketplaceMarkupDescription: sourceTranslations.marketplace_markup_description,
      marketplaceCommission: sourceTranslations.marketplace_commission,
      marketplaceCommissionDescription: sourceTranslations.marketplace_commission_description,
      marketplaceSettings: sourceTranslations.marketplace_settings,
      licenseRequiredTitle: sourceTranslations.license_required_title,
      licenseMissingMessage: sourceTranslations.license_missing_message,
      licenseInvalidMessage: sourceTranslations.license_invalid_message,
      licenseExpiredMessage: sourceTranslations.license_expired_message,
      licenseDomainMismatchMessage: sourceTranslations.license_domain_mismatch_message,
      licenseFileErrorMessage: sourceTranslations.license_file_error_message,
      updateAvailableButton: sourceTranslations.update_available_button,
      updateCheckingMessage: sourceTranslations.update_checking_message,
      updateInstallingMessage: sourceTranslations.update_installing_message,
      updateInstalledMessage: sourceTranslations.update_installed_message,
      updateCheckErrorMessage: sourceTranslations.update_check_error_message,
      updateInstallErrorMessage: sourceTranslations.update_install_error_message,
      enterPercentage: sourceTranslations.enter_percentage,
      typePercentage: sourceTranslations.type_percentage,
      notAvailable: sourceTranslations.not_available
    };

    var LS_QUERY = 'ps_inventory_query';
    var LS_ACTIVE_ONLY = 'ps_inventory_activeOnly';
    var LS_ONLY = 'ps_inventory_onlyAvailable';
    var LS_MISSING_PURCHASE = 'ps_inventory_missingPurchasePriceOnly';
    var LS_SHOW_WEIGHT = 'ps_inventory_showWeight';
    var LS_SHOW_UNIT_VOLUME = 'ps_inventory_showUnitVolume';
    var LS_SHOW_UNITS_PER_CARTON = 'ps_inventory_showUnitsPerCarton';
    var LS_SHOW_CARTON_DIMENSIONS = 'ps_inventory_showCartonDimensions';
    var LS_MISSING_WEIGHT = 'ps_inventory_missingWeightOnly';
    var LS_BRUTTO = 'ps_inventory_showBrutto';
    var LS_SHOW_MATERIAL = 'ps_inventory_showMaterial';
    var LS_SHOW_HS_CODE = 'ps_inventory_showHsCode';
    var LS_SHOW_CUSTOMS_DUTY_RATE = 'ps_inventory_showCustomsDutyRate';
    var LS_PAGE = 'ps_inventory_page';
    var LS_PER_PAGE = 'ps_inventory_per_page';
    var LS_SORT_FIELD = 'ps_inventory_sort_field';
    var LS_SORT_DIR = 'ps_inventory_sort_dir';
    var LS_MARKETPLACE_MARKUP = 'ps_inventory_marketplace_markup';
    var LS_MARKETPLACE_COMMISSION = 'ps_inventory_marketplace_commission';
    var currentPage = Math.max(parseInt(localStorage.getItem(LS_PAGE) || '1', 10), 1);
    var currentPerPage = parseInt(localStorage.getItem(LS_PER_PAGE) || '20', 10);
    if ([20, 50, 100, 200].indexOf(currentPerPage) === -1) {
      currentPerPage = 20;
    }
    var currentSortField = localStorage.getItem(LS_SORT_FIELD) || 'id_product';
    var currentSortDir = localStorage.getItem(LS_SORT_DIR) || 'DESC';
    var salesModalState = {
      productId: 0,
      productAttributeId: 0,
      productName: '',
      combinationName: '',
      imageSrc: '',
      cost: 0,
      costGross: 0,
      retailNet: 0,
      retail: 0,
      months: 12,
      offsetMonths: 0,
      selectedYear: 0,
      previousYear: 0,
      earliestYear: 0
    };
    var profitModalState = {
      productName: '',
      combinationName: '',
      imageSrc: '',
      cost: 0,
      costGross: 0,
      retailNet: 0,
      retail: 0
    };
    var marketplaceSettingsState = {
      marketplaceMarkup: 20,
      marketplaceCommission: 10
    };
    var salesChartInstance = null;

    function t(key) {
      return translations[key] ? translations[key] : key;
    }

    function setUpdateStatus(message, isError) {
      var el = document.getElementById('inventoryUpdateStatus');
      var metaEl = document.getElementById('inventoryUpdateMetaStatus');
      if (!el && !metaEl) {
        return;
      }

      if (el) {
        el.textContent = message || '';
        el.classList.toggle('is-error', !!isError);
      }

      if (metaEl) {
        metaEl.textContent = message || '';
        metaEl.classList.toggle('is-error', !!isError);
      }
    }

    function formatUpdateButtonLabel(version) {
      return String(t('updateAvailableButton') || '')
        .replace('{{ version }}', version)
        .replace('%version%', version)
        .trim();
    }

    function updateButtonVisibility(version) {
      var button = document.getElementById('inventoryUpdateButton');
      var label = button ? button.querySelector('.inventory-update-btn-label') : null;
      if (!button || !label) {
        return;
      }

      if (!version) {
        button.hidden = true;
        button.removeAttribute('data-version');
        label.textContent = '';
        return;
      }

      button.hidden = false;
      button.setAttribute('data-version', version);
      label.textContent = formatUpdateButtonLabel(version);
    }

    function normalizePercentValue(value, fallbackValue) {
      var parsed = Number(String(value == null ? '' : value).replace(',', '.').trim());
      if (!isFinite(parsed) || parsed < 0) {
        return fallbackValue;
      }

      return parsed;
    }

    function formatPercentValue(value) {
      if (!isFinite(value)) {
        return t('notAvailable');
      }

      return Number(value).toFixed(1).replace(/\.0$/, '') + '%';
    }

    function calculateChannelMetrics(cost, sellPrice, commissionPercent) {
      if (!(cost > 0) || !(sellPrice > 0)) {
        return null;
      }

      var commissionValue = sellPrice * (commissionPercent / 100);
      var profit = sellPrice - cost - commissionValue;

      return {
        profit: profit,
        markup: (profit / cost) * 100,
        margin: (profit / sellPrice) * 100
      };
    }

    function buildEstimatedSalesProfit(totalQuantity) {
      var qty = Number(totalQuantity || 0);
      if (!(qty > 0)) {
        return null;
      }

      var marketplaceGrossPrice = salesModalState.retail > 0 ? salesModalState.retail * (1 + (marketplaceSettingsState.marketplaceMarkup / 100)) : 0;
      var marketplaceNetPrice = salesModalState.retailNet > 0 ? salesModalState.retailNet * (1 + (marketplaceSettingsState.marketplaceMarkup / 100)) : 0;
      var marketplaceGrossCommission = marketplaceGrossPrice * (marketplaceSettingsState.marketplaceCommission / 100);
      var marketplaceNetCommission = marketplaceNetPrice * (marketplaceSettingsState.marketplaceCommission / 100);

      return {
        storeNet: salesModalState.retailNet > 0 ? qty * (salesModalState.retailNet - salesModalState.cost) : NaN,
        marketplaceNet: marketplaceNetPrice > 0 ? qty * (marketplaceNetPrice - salesModalState.cost - marketplaceNetCommission) : NaN,
        storeGross: salesModalState.retail > 0 ? qty * (salesModalState.retail - salesModalState.costGross) : NaN,
        marketplaceGross: marketplaceGrossPrice > 0 ? qty * (marketplaceGrossPrice - salesModalState.costGross - marketplaceGrossCommission) : NaN
      };
    }

    function renderEstimatedProfitValue(storeValue, marketplaceValue) {
      var storeText = isFinite(storeValue) ? formatCurrencyAmount(storeValue) : t('notAvailable');
      var marketplaceText = isFinite(marketplaceValue) ? formatCurrencyAmount(marketplaceValue) : t('notAvailable');

      return '<span class="inventory-sales-channel-profit">' + escapeHtml(t('storeChannel')) + ': <strong>' + escapeHtml(storeText) + '</strong></span>' +
        '<span class="inventory-sales-channel-profit">' + escapeHtml(t('marketplaceChannel')) + ': <strong>' + escapeHtml(marketplaceText) + '</strong></span>';
    }

    function syncMarketplaceSettingsUi() {
      $('.editable-marketplace-setting').each(function () {
        var key = String($(this).data('setting-key') || '');
        var value = marketplaceSettingsState[key];
        $(this).text(formatPercentValue(value)).attr('data-current-value', String(value));
      });
    }

    function formatMoneyValue(value) {
      if (!isFinite(value) || value <= 0) {
        return t('notAvailable');
      }

      return formatCurrencyAmount(value);
    }

    function formatCurrencyAmount(value) {
      if (!isFinite(value)) {
        return t('notAvailable');
      }

      var integerPart = '';

      try {
        integerPart = new Intl.NumberFormat('pl-PL', {
          minimumFractionDigits: 0,
          maximumFractionDigits: 0,
          useGrouping: true
        }).format(Math.round(Number(value)));
      } catch (error) {
        var rounded = String(Math.round(Number(value)));
        integerPart = rounded.replace(/\B(?=(\d{3})+(?!\d))/g, '\u00A0');
      }

      integerPart = String(integerPart).replace(/\s/g, '\u00A0');

      return integerPart + '\u00A0zł';
    }

    function renderProfitabilityCard(label, toneClass, priceLabel, metrics) {
      var costText = formatMoneyValue(profitModalState.cost);
      var costGrossText = formatMoneyValue(profitModalState.costGross);
      var markupText = metrics ? formatPercentValue(metrics.markup) : t('notAvailable');
      var marginText = metrics ? formatPercentValue(metrics.margin) : t('notAvailable');
      var profitText = metrics ? formatCurrencyAmount(metrics.profit) : t('notAvailable');
      var profitValueClass = 'inventory-profit-value';
      var markupValueClass = 'inventory-percent-value';
      var marginValueClass = 'inventory-percent-value';

      if (metrics) {
        if (metrics.markup < 0) {
          markupValueClass += ' is-negative';
        }

        if (metrics.margin < 0) {
          marginValueClass += ' is-negative';
        }

        if (metrics.profit < 0) {
          profitValueClass += ' is-negative';
        } else {
          profitValueClass += ' is-positive';
        }
      }

      return '' +
        '<div class="inventory-profit-card ' + toneClass + '">' +
          '<div class="inventory-profit-card-label">' + escapeHtml(label) + '</div>' +
          '<div class="inventory-profit-price">' + escapeHtml(priceLabel) + '</div>' +
          '<div class="inventory-profit-lines">' +
            '<div class="inventory-profit-line"><span>' + escapeHtml(t('price')) + '</span><strong>' + escapeHtml(costText) + '</strong></div>' +
            '<div class="inventory-profit-line"><span>' + escapeHtml(t('purchasePriceGross')) + '</span><strong>' + escapeHtml(costGrossText) + '</strong></div>' +
            '<div class="inventory-profit-line"><span>' + escapeHtml(t('profitabilityMarkup')) + '</span><strong class="' + escapeHtml(markupValueClass) + '">' + escapeHtml(markupText) + '</strong></div>' +
            '<div class="inventory-profit-line"><span>' + escapeHtml(t('profitabilityMargin')) + '</span><strong class="' + escapeHtml(marginValueClass) + '">' + escapeHtml(marginText) + '</strong></div>' +
            '<div class="inventory-profit-line"><span>' + escapeHtml(t('profitabilityProfit')) + '</span><strong class="' + escapeHtml(profitValueClass) + '">' + escapeHtml(profitText) + '</strong></div>' +
          '</div>' +
        '</div>';
    }

    function updateProfitModalHeading() {
      document.getElementById('inventoryProfitModalTitle').textContent = profitModalState.productName || '';
      document.getElementById('inventoryProfitModalSubtitle').textContent = profitModalState.combinationName || '';
    }

    function renderProfitabilityModal() {
      var marketplacePrice = profitModalState.retail > 0 ? profitModalState.retail * (1 + (marketplaceSettingsState.marketplaceMarkup / 100)) : 0;
      var storeMetrics = calculateChannelMetrics(profitModalState.cost, profitModalState.retail, 0);
      var marketplaceMetrics = calculateChannelMetrics(profitModalState.cost, marketplacePrice, marketplaceSettingsState.marketplaceCommission);
      var storeProfitNet = profitModalState.retailNet > 0 ? profitModalState.retailNet - profitModalState.cost : NaN;
      var marketplaceRetailNet = profitModalState.retailNet > 0 ? profitModalState.retailNet * (1 + (marketplaceSettingsState.marketplaceMarkup / 100)) : 0;
      var marketplaceCommissionNet = marketplaceRetailNet * (marketplaceSettingsState.marketplaceCommission / 100);
      var marketplaceProfitNet = marketplaceRetailNet > 0 ? marketplaceRetailNet - profitModalState.cost - marketplaceCommissionNet : NaN;

      if (storeMetrics) {
        storeMetrics.profit = storeProfitNet;
      }

      if (marketplaceMetrics) {
        marketplaceMetrics.profit = marketplaceProfitNet;
      }

      var html = '' +
        '<div class="inventory-marketplace-settings">' +
          '<div class="inventory-marketplace-settings-title">' + escapeHtml(t('marketplaceSettings')) + '</div>' +
          '<div class="inventory-marketplace-settings-grid">' +
            '<div class="inventory-marketplace-setting">' +
              '<div class="inventory-marketplace-setting-copy">' +
                '<span class="inventory-marketplace-setting-label">' + escapeHtml(t('marketplaceMarkup')) + '</span>' +
                '<span class="inventory-marketplace-setting-description">' + escapeHtml(t('marketplaceMarkupDescription')) + '</span>' +
              '</div>' +
              '<span class="inventory-marketplace-setting-value editable-marketplace-setting" data-setting-key="marketplaceMarkup" data-current-value="' + escapeHtml(String(marketplaceSettingsState.marketplaceMarkup)) + '"></span>' +
            '</div>' +
            '<div class="inventory-marketplace-setting">' +
              '<div class="inventory-marketplace-setting-copy">' +
                '<span class="inventory-marketplace-setting-label">' + escapeHtml(t('marketplaceCommission')) + '</span>' +
                '<span class="inventory-marketplace-setting-description">' + escapeHtml(t('marketplaceCommissionDescription')) + '</span>' +
              '</div>' +
              '<span class="inventory-marketplace-setting-value editable-marketplace-setting" data-setting-key="marketplaceCommission" data-current-value="' + escapeHtml(String(marketplaceSettingsState.marketplaceCommission)) + '"></span>' +
            '</div>' +
          '</div>' +
        '</div>' +
        '<div class="inventory-profit-grid">' +
          renderProfitabilityCard(t('storeChannel'), 'is-store', t('storePrice') + ': ' + formatMoneyValue(profitModalState.retail), storeMetrics) +
          renderProfitabilityCard(t('marketplaceChannel'), 'is-marketplace', t('marketplacePrice') + ': ' + formatMoneyValue(marketplacePrice), marketplaceMetrics) +
        '</div>';

      document.getElementById('inventoryProfitModalContent').innerHTML = html;
      document.getElementById('inventoryProfitModalContent').classList.add('is-visible');
      syncMarketplaceSettingsUi();
    }

    function openProfitModal() {
      var modal = document.getElementById('inventoryProfitModal');
      var modalImage = document.getElementById('inventoryProfitModalImage');
      var modalFallback = document.getElementById('inventoryProfitModalImageFallback');
      updateProfitModalHeading();
      if (profitModalState.imageSrc) {
        modalImage.setAttribute('src', profitModalState.imageSrc);
        modalImage.classList.remove('is-hidden');
        modalFallback.classList.remove('is-visible');
      } else {
        modalImage.setAttribute('src', '');
        modalImage.classList.add('is-hidden');
        modalFallback.classList.add('is-visible');
      }
      renderProfitabilityModal();
      modal.classList.add('is-open');
      modal.setAttribute('aria-hidden', 'false');
    }

    function closeProfitModal() {
      var modal = document.getElementById('inventoryProfitModal');
      var modalImage = document.getElementById('inventoryProfitModalImage');
      var modalFallback = document.getElementById('inventoryProfitModalImageFallback');
      document.getElementById('inventoryProfitModalTitle').textContent = '';
      document.getElementById('inventoryProfitModalSubtitle').textContent = '';
      document.getElementById('inventoryProfitModalContent').innerHTML = '';
      document.getElementById('inventoryProfitModalContent').classList.remove('is-visible');
      modalImage.setAttribute('src', '');
      modalImage.classList.remove('is-hidden');
      modalFallback.classList.remove('is-visible');
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden', 'true');
    }

    function refreshCalculatedMetrics() {
      $('.inventory-calculated-metric').each(function () {
        var $metric = $(this);
        var cost = Number($metric.data('cost') || 0);
        var retail = Number($metric.data('retail') || 0);
        var marketplaceMarkupPercent = marketplaceSettingsState.marketplaceMarkup;
        var marketplaceCommissionPercent = marketplaceSettingsState.marketplaceCommission;
        var marketplacePrice = retail > 0 ? retail * (1 + (marketplaceMarkupPercent / 100)) : 0;
        var result = null;

        if ($metric.hasClass('inventory-store-markup')) {
          result = calculateChannelMetrics(cost, retail, 0);
          result = result ? result.markup : null;
        } else if ($metric.hasClass('inventory-store-margin')) {
          result = calculateChannelMetrics(cost, retail, 0);
          result = result ? result.margin : null;
        } else if ($metric.hasClass('inventory-marketplace-markup-result')) {
          result = calculateChannelMetrics(cost, marketplacePrice, marketplaceCommissionPercent);
          result = result ? result.markup : null;
        } else if ($metric.hasClass('inventory-marketplace-margin')) {
          result = calculateChannelMetrics(cost, marketplacePrice, marketplaceCommissionPercent);
          result = result ? result.margin : null;
        }

        $metric
          .text(result == null ? t('notAvailable') : formatPercentValue(result))
          .toggleClass('is-negative', result != null && result < 0);
      });
    }

    function parseKeywords(raw) {
      return (raw || '').trim().split(/[,\s]+/g).map(function (item) {
        return item.trim();
      }).filter(Boolean);
    }

    function applyLanguage() {
      document.querySelector('#thNo .inventory-head-title').textContent = t('no');
      document.getElementById('activeOnlyLabel').textContent = t('activeOnly');
      document.getElementById('onlyAvailableLabel').textContent = t('onlyAvailable');
      document.getElementById('missingPurchasePriceOnlyLabel').textContent = t('missingPurchasePriceOnly');
      document.getElementById('showWeightLabel').textContent = t('showWeight');
      document.getElementById('showUnitVolumeLabel').textContent = t('showUnitVolume');
      document.getElementById('showUnitsPerCartonLabel').textContent = t('showUnitsPerCarton');
      document.getElementById('showCartonDimensionsLabel').textContent = t('showCartonDimensions');
      document.getElementById('missingWeightOnlyLabel').textContent = t('missingWeightOnly');
      document.getElementById('showBruttoLabel').textContent = t('showBrutto');
      document.getElementById('searchInput').setAttribute('placeholder', t('searchPlaceholder'));
      document.getElementById('thPicture').textContent = t('picture');
      document.querySelector('#thName .inventory-head-title').textContent = t('name');
      document.querySelector('#thActive .inventory-head-title').textContent = t('active');
      document.querySelector('#thWeight .inventory-head-title').textContent = t('weight');
      document.getElementById('thUnitVolume').textContent = t('unitVolume');
      document.getElementById('thUnitsPerCarton').textContent = t('unitsPerCarton');
      document.getElementById('thCartonDimensions').textContent = t('cartonDimensions');
      document.querySelector('#thPrice .inventory-head-title').textContent = t('price');
      document.querySelector('#thPriceBrutto .inventory-head-title').textContent = t('priceBrutto');
      document.querySelector('#thQty .inventory-head-title').textContent = t('qty');
      document.getElementById('thValue').textContent = t('value');
      document.getElementById('thValueBrutto').textContent = t('valueBrutto');
      renderSortState();
    }

    function toggleWeightColumns(show, shouldReload) {
      document.getElementById('thWeight').style.display = show ? '' : 'none';
      if (shouldReload === false) {
        return;
      }

      currentPage = 1;
      localStorage.setItem(LS_PAGE, String(currentPage));
      loadTable(getSearchQuery(), document.getElementById('activeOnly').checked, document.getElementById('onlyAvailable').checked, document.getElementById('missingPurchasePriceOnly').checked, document.getElementById('missingWeightOnly').checked);
    }

    function toggleUnitVolumeColumns(show, shouldReload) {
      document.getElementById('thUnitVolume').style.display = show ? '' : 'none';
      if (shouldReload === false) {
        return;
      }

      currentPage = 1;
      localStorage.setItem(LS_PAGE, String(currentPage));
      loadTable(getSearchQuery(), document.getElementById('activeOnly').checked, document.getElementById('onlyAvailable').checked, document.getElementById('missingPurchasePriceOnly').checked, document.getElementById('missingWeightOnly').checked);
    }

    function toggleUnitsPerCartonColumns(show, shouldReload) {
      document.getElementById('thUnitsPerCarton').style.display = show ? '' : 'none';
      if (shouldReload === false) {
        return;
      }

      currentPage = 1;
      localStorage.setItem(LS_PAGE, String(currentPage));
      loadTable(getSearchQuery(), document.getElementById('activeOnly').checked, document.getElementById('onlyAvailable').checked, document.getElementById('missingPurchasePriceOnly').checked, document.getElementById('missingWeightOnly').checked);
    }

    function toggleCartonDimensionsColumns(show, shouldReload) {
      document.getElementById('thCartonDimensions').style.display = show ? '' : 'none';
      if (shouldReload === false) {
        return;
      }

      currentPage = 1;
      localStorage.setItem(LS_PAGE, String(currentPage));
      loadTable(getSearchQuery(), document.getElementById('activeOnly').checked, document.getElementById('onlyAvailable').checked, document.getElementById('missingPurchasePriceOnly').checked, document.getElementById('missingWeightOnly').checked);
    }

function toggleBruttoColumns(show, shouldReload) {
      var display = show ? '' : 'none';
      document.getElementById('thPriceBrutto').style.display = display;
      document.getElementById('thValueBrutto').style.display = display;
      if (shouldReload === false) {
        return;
      }

      currentPage = 1;
      localStorage.setItem(LS_PAGE, String(currentPage));
      loadTable(getSearchQuery(), document.getElementById('activeOnly').checked, document.getElementById('onlyAvailable').checked, document.getElementById('missingPurchasePriceOnly').checked, document.getElementById('missingWeightOnly').checked);
    }

    function toggleMaterialColumn(show, shouldReload) {
      document.getElementById('thMaterial').style.display = show ? '' : 'none';
      if (shouldReload === false) { return; }
      currentPage = 1;
      localStorage.setItem(LS_PAGE, String(currentPage));
      loadTable(getSearchQuery(), document.getElementById('activeOnly').checked, document.getElementById('onlyAvailable').checked, document.getElementById('missingPurchasePriceOnly').checked, document.getElementById('missingWeightOnly').checked);
    }

    function toggleHsCodeColumn(show, shouldReload) {
      document.getElementById('thHsCode').style.display = show ? '' : 'none';
      if (shouldReload === false) { return; }
      currentPage = 1;
      localStorage.setItem(LS_PAGE, String(currentPage));
      loadTable(getSearchQuery(), document.getElementById('activeOnly').checked, document.getElementById('onlyAvailable').checked, document.getElementById('missingPurchasePriceOnly').checked, document.getElementById('missingWeightOnly').checked);
    }

    function toggleCustomsDutyRateColumn(show, shouldReload) {
      document.getElementById('thCustomsDutyRate').style.display = show ? '' : 'none';
      if (shouldReload === false) { return; }
      currentPage = 1;
      localStorage.setItem(LS_PAGE, String(currentPage));
      loadTable(getSearchQuery(), document.getElementById('activeOnly').checked, document.getElementById('onlyAvailable').checked, document.getElementById('missingPurchasePriceOnly').checked, document.getElementById('missingWeightOnly').checked);
    }

    function normalizeKeywords(value) {
      return (value || []).map(function (item) {
        return item.trim();
      }).filter(Boolean);
    }

    function getSearchKeywords() {
      return normalizeKeywords($('#searchTags').data('keywords') || []);
    }

    function setSearchKeywords(keywords) {
      $('#searchTags').data('keywords', normalizeKeywords(keywords));
      renderSearchTags();
    }

    function getSearchQuery() {
      return getSearchKeywords().join(' ');
    }

    function renderSearchTags() {
      var keywords = getSearchKeywords();
      var $tags = $('#searchTags');

      $tags.empty();
      keywords.forEach(function (keyword, index) {
        var $tag = $('<span class="inventory-tag"></span>');
        $tag.append($('<span></span>').text(keyword));
        $tag.append($('<button type="button" class="inventory-tag-remove" aria-label="Remove">&times;</button>').attr('data-index', index));
        $tags.append($tag);
      });
    }

    function persistAndLoadKeywords(keywords) {
      setSearchKeywords(keywords);
      localStorage.setItem(LS_QUERY, getSearchQuery());
      updateFilterBadge();
      currentPage = 1;
      localStorage.setItem(LS_PAGE, String(currentPage));
      loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
    }

    function appendKeywordsFromInput() {
      var current = $('#searchInput').val();
      var inputKeywords = parseKeywords(current);
      if (!inputKeywords.length) {
        return false;
      }

      var merged = getSearchKeywords().concat(inputKeywords);
      persistAndLoadKeywords(merged);
      $('#searchInput').val('');

      return true;
    }

    function loadTable(query, activeOnly, onlyAvailable, missingPurchasePriceOnly, missingWeightOnly) {
      if (!window.cargoStockManagerConfig.licenseValid) {
        $('#productsTable tbody').empty();
        $('#inventoryPagination').empty();
        return;
      }

      var keywords = parseKeywords(query);
      var showWeight = document.getElementById('showWeight').checked;
      var showUnitVolume = document.getElementById('showUnitVolume').checked;
      var showUnitsPerCarton = document.getElementById('showUnitsPerCarton').checked;
      var showCartonDimensions = document.getElementById('showCartonDimensions').checked;
      var showMaterial = document.getElementById('showMaterial').checked;
      var showHsCode = document.getElementById('showHsCode').checked;
      var showCustomsDutyRate = document.getElementById('showCustomsDutyRate').checked;
      var showBrutto = document.getElementById('showBrutto').checked;

      $.post(window.cargoStockManagerConfig.ajaxUrl + '&action=FetchProducts', {
        query: query || '',
        keywords: keywords,
        activeOnly: activeOnly ? 1 : 0,
        onlyAvailable: onlyAvailable ? 1 : 0,
        missingPurchasePriceOnly: missingPurchasePriceOnly ? 1 : 0,
        missingWeightOnly: missingWeightOnly ? 1 : 0,
        showWeight: showWeight ? 1 : 0,
        showUnitVolume: showUnitVolume ? 1 : 0,
        showUnitsPerCarton: showUnitsPerCarton ? 1 : 0,
        showCartonDimensions: showCartonDimensions ? 1 : 0,
        showMaterial: showMaterial ? 1 : 0,
        showHsCode: showHsCode ? 1 : 0,
        showCustomsDutyRate: showCustomsDutyRate ? 1 : 0,
        showBrutto: showBrutto ? 1 : 0,
        lang: window.cargoStockManagerConfig.languageIso || 'en',
        sort_field: currentSortField,
        sort_dir: currentSortDir,
        page: currentPage,
        per_page: currentPerPage
      }, null, 'json').done(function (resp) {
        $('#productsTable tbody').html(resp && resp.tbody ? resp.tbody : '');
        refreshCalculatedMetrics();
        $('#inventoryPagination').html(resp && resp.pagination ? resp.pagination : '');
        if (resp && resp.meta) {
          currentPage = Math.max(parseInt(resp.meta.current_page || 1, 10), 1);
          currentPerPage = parseInt(resp.meta.per_page || currentPerPage, 10);
          localStorage.setItem(LS_PAGE, String(currentPage));
          localStorage.setItem(LS_PER_PAGE, String(currentPerPage));
        }
      }).fail(function () {
        var colspan = 8
          + (document.getElementById('showWeight').checked ? 1 : 0)
          + (document.getElementById('showUnitVolume').checked ? 1 : 0)
          + (document.getElementById('showUnitsPerCarton').checked ? 1 : 0)
          + (document.getElementById('showCartonDimensions').checked ? 1 : 0)
          + (document.getElementById('showMaterial').checked ? 1 : 0)
          + (document.getElementById('showHsCode').checked ? 1 : 0)
          + (document.getElementById('showCustomsDutyRate').checked ? 1 : 0)
          + (document.getElementById('showBrutto').checked ? 2 : 0);
        $('#productsTable tbody').html('<tr><td colspan="' + colspan + '" class="text-center text-danger">' + t('loadError') + '</td></tr>');
        $('#inventoryPagination').empty();
      });
    }

    function renderSortState() {
      $('.inventory-sortable').removeClass('is-active sort-asc sort-desc');
      var $active = $('.inventory-sortable[data-sort-field="' + currentSortField + '"]');
      $active.addClass('is-active ' + (currentSortDir === 'DESC' ? 'sort-desc' : 'sort-asc'));
    }

    function updateFilterBadge() {
      var count = 0;

      document.querySelectorAll('input[data-filter-type="show-only"]').forEach(function (input) {
        if (input.checked) { count += 1; }
      });

      var badge = document.getElementById('filterActiveCount');
      if (badge) {
        badge.textContent = String(count);
        badge.classList.toggle('is-hidden', count === 0);
      }
    }

    function copyTextToClipboard(text) {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        return navigator.clipboard.writeText(text);
      }

      return new Promise(function (resolve, reject) {
        var input = document.createElement('textarea');
        input.value = text;
        input.setAttribute('readonly', '');
        input.style.position = 'absolute';
        input.style.left = '-9999px';
        document.body.appendChild(input);
        input.select();

        try {
          document.execCommand('copy');
          document.body.removeChild(input);
          resolve();
        } catch (error) {
          document.body.removeChild(input);
          reject(error);
        }
      });
    }

    function escapeHtml(value) {
      return String(value == null ? '' : value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
    }

    function formatSalesMonth(monthDate) {
      var date = new Date(monthDate + 'T00:00:00');

      try {
        return new Intl.DateTimeFormat(window.cargoStockManagerConfig.languageIso || 'en', {
          month: 'short',
          year: 'numeric'
        }).format(date);
      } catch (error) {
        return monthDate;
      }
    }

    function formatSalesMonthShort(monthDate) {
      var date = new Date(monthDate + 'T00:00:00');

      try {
        return new Intl.DateTimeFormat(window.cargoStockManagerConfig.languageIso || 'en', {
          month: 'short'
        }).format(date);
      } catch (error) {
        return monthDate;
      }
    }

    function formatSalesMonthName(monthDate, grammaticalCase) {
      var date = new Date(monthDate + 'T00:00:00');
      var iso = String(window.cargoStockManagerConfig.languageIso || 'en').toLowerCase();
      var monthIndex = date.getMonth();

      if (iso.indexOf('pl') === 0) {
        var polishMonthsStandalone = ['styczeń', 'luty', 'marzec', 'kwiecień', 'maj', 'czerwiec', 'lipiec', 'sierpień', 'wrzesień', 'październik', 'listopad', 'grudzień'];
        var polishMonthsLocative = ['styczniu', 'lutym', 'marcu', 'kwietniu', 'maju', 'czerwcu', 'lipcu', 'sierpniu', 'wrześniu', 'październiku', 'listopadzie', 'grudniu'];

        return grammaticalCase === 'locative'
          ? polishMonthsLocative[monthIndex]
          : polishMonthsStandalone[monthIndex];
      }

      try {
        return new Intl.DateTimeFormat(window.cargoStockManagerConfig.languageIso || 'en', {
          month: 'long'
        }).format(date);
      } catch (error) {
        return monthDate;
      }
    }

    function buildYearSummary(year, quantities, values, valuesNet) {
      var today = new Date();
      var currentYear = today.getFullYear();
      var currentMonthIndex = today.getMonth();
      var currentDay = today.getDate();
      var daysInCurrentMonth = new Date(currentYear, currentMonthIndex + 1, 0).getDate();
      var lastIncludedMonthIndex = year === currentYear ? Math.min(currentMonthIndex, quantities.length - 1) : (quantities.length - 1);
      var elapsedMonthUnits = quantities.length;
      var total = 0;
      var totalValue = 0;
      var totalValueNet = 0;
      var minValue = null;
      var maxValue = null;
      var minMonthIndex = 0;
      var maxMonthIndex = 0;

      quantities.forEach(function (qty, index) {
        if (index > lastIncludedMonthIndex) {
          return;
        }

        var value = Number(qty || 0);
        total += value;
        totalValue += Number((values || [])[index] || 0);
        totalValueNet += Number((valuesNet || [])[index] || 0);

        if (minValue === null || value < minValue) {
          minValue = value;
          minMonthIndex = index;
        }

        if (maxValue === null || value > maxValue) {
          maxValue = value;
          maxMonthIndex = index;
        }
      });

      if (year === currentYear) {
        elapsedMonthUnits = currentMonthIndex + (daysInCurrentMonth > 0 ? (currentDay / daysInCurrentMonth) : 0);
      }

      if (!isFinite(elapsedMonthUnits) || elapsedMonthUnits <= 0) {
        elapsedMonthUnits = Math.max(lastIncludedMonthIndex + 1, 1);
      }

      return {
        year: year,
        total: total,
        totalValue: totalValue,
        totalValueNet: totalValueNet,
        average: total / elapsedMonthUnits,
        averageValue: totalValue / elapsedMonthUnits,
        averageValueNet: totalValueNet / elapsedMonthUnits,
        minValue: minValue === null ? 0 : minValue,
        maxValue: maxValue === null ? 0 : maxValue,
        minMonthDate: year + '-' + String(minMonthIndex + 1).padStart(2, '0') + '-01',
        maxMonthDate: year + '-' + String(maxMonthIndex + 1).padStart(2, '0') + '-01'
      };
    }

    function renderYearSummaryCard(summary, toneClass) {
      var averageLabel = Number(summary.average || 0).toFixed(1).replace(/\.0$/, '');
      var averageValueLabel = formatCurrencyAmount(Number(summary.averageValue || 0));
      var averageValueNetLabel = formatCurrencyAmount(Number(summary.averageValueNet || 0));
      var estimatedProfit = buildEstimatedSalesProfit(summary.total);
      var title = 'łącznie sprzedano ' + summary.total + ' ' + t('salesUnits');
      var revenueLine = '<span class="inventory-sales-summary-line-label">' + escapeHtml(t('salesRevenue')) + '</span><span class="inventory-sales-summary-line-value"><strong>' + escapeHtml(formatCurrencyAmount(Number(summary.totalValue || 0))) + '</strong></span>';
      var revenueNetLine = '<span class="inventory-sales-summary-line-label">' + escapeHtml(t('salesRevenueNet')) + '</span><span class="inventory-sales-summary-line-value"><strong>' + escapeHtml(formatCurrencyAmount(Number(summary.totalValueNet || 0))) + '</strong></span>';
      var estimatedNetLine = '<span class="inventory-sales-summary-line-label">' + escapeHtml(t('estimatedProfitNet')) + '</span><span class="inventory-sales-summary-line-value">' + (estimatedProfit ? renderEstimatedProfitValue(estimatedProfit.storeNet, estimatedProfit.marketplaceNet) : escapeHtml(t('notAvailable'))) + '</span>';
      var estimatedGrossLine = '<span class="inventory-sales-summary-line-label">' + escapeHtml(t('estimatedProfitGross')) + '</span><span class="inventory-sales-summary-line-value">' + (estimatedProfit ? renderEstimatedProfitValue(estimatedProfit.storeGross, estimatedProfit.marketplaceGross) : escapeHtml(t('notAvailable'))) + '</span>';
      var minLine = '<span class="inventory-sales-summary-line-label">Min</span><span class="inventory-sales-summary-line-value"><strong>' + summary.minValue + ' ' + escapeHtml(t('salesUnits')) + '</strong> w ' + escapeHtml(formatSalesMonthName(summary.minMonthDate, 'locative')) + '</span>';
      var maxLine = '<span class="inventory-sales-summary-line-label">Max</span><span class="inventory-sales-summary-line-value"><strong>' + summary.maxValue + ' ' + escapeHtml(t('salesUnits')) + '</strong> w ' + escapeHtml(formatSalesMonthName(summary.maxMonthDate, 'locative')) + '</span>';
      var avgLine = '<span class="inventory-sales-summary-line-label">Średnio</span><span class="inventory-sales-summary-line-value"><strong>' + escapeHtml(averageLabel) + ' ' + escapeHtml(t('salesUnits')) + '</strong> w miesiącu</span>';
      var avgValueLine = '<span class="inventory-sales-summary-line-label">' + escapeHtml(t('salesRevenue')) + ' / mies.</span><span class="inventory-sales-summary-line-value"><strong>' + escapeHtml(averageValueLabel) + '</strong></span>';
      var avgValueNetLine = '<span class="inventory-sales-summary-line-label">' + escapeHtml(t('salesRevenueNet')) + ' / mies.</span><span class="inventory-sales-summary-line-value"><strong>' + escapeHtml(averageValueNetLabel) + '</strong></span>';

      return '' +
        '<div class="inventory-sales-summary-card ' + escapeHtml(toneClass || '') + '">' +
          '<div class="inventory-sales-summary-value"><span class="inventory-sales-summary-label">' + escapeHtml(String(summary.year)) + '</span><span class="inventory-sales-summary-text">' + escapeHtml(title) + '</span></div>' +
          '<div class="inventory-sales-summary-note inventory-sales-summary-lines">' +
            '<div class="inventory-sales-summary-line">' + revenueLine + '</div>' +
            '<div class="inventory-sales-summary-line">' + revenueNetLine + '</div>' +
            '<div class="inventory-sales-summary-line">' + estimatedNetLine + '</div>' +
            '<div class="inventory-sales-summary-line">' + estimatedGrossLine + '</div>' +
            '<div class="inventory-sales-summary-line">' + minLine + '</div>' +
            '<div class="inventory-sales-summary-line">' + maxLine + '</div>' +
            '<div class="inventory-sales-summary-line">' + avgLine + '</div>' +
            '<div class="inventory-sales-summary-line">' + avgValueLine + '</div>' +
            '<div class="inventory-sales-summary-line">' + avgValueNetLine + '</div>' +
          '</div>' +
        '</div>';
    }

    function destroySalesChart() {
      if (salesChartInstance && typeof salesChartInstance.destroy === 'function') {
        salesChartInstance.destroy();
      }

      salesChartInstance = null;
    }

    function renderSalesChart(months) {
      var canvas = document.getElementById('inventorySalesChartCanvas');
      if (!canvas || typeof Chart === 'undefined') {
        return;
      }

      destroySalesChart();

      var ctx = canvas.getContext('2d');
      var currentGradient = ctx.createLinearGradient(0, 0, 0, canvas.height || 220);
      currentGradient.addColorStop(0, 'rgba(62, 183, 125, 0.48)');
      currentGradient.addColorStop(0.5, 'rgba(62, 183, 125, 0.2)');
      currentGradient.addColorStop(1, 'rgba(62, 183, 125, 0.05)');
      var previousGradient = ctx.createLinearGradient(0, 0, 0, canvas.height || 220);
      previousGradient.addColorStop(0, 'rgba(66, 191, 220, 0.46)');
      previousGradient.addColorStop(0.5, 'rgba(66, 191, 220, 0.2)');
      previousGradient.addColorStop(1, 'rgba(66, 191, 220, 0.05)');
      var earliestGradient = ctx.createLinearGradient(0, 0, 0, canvas.height || 220);
      earliestGradient.addColorStop(0, 'rgba(224, 170, 40, 0.4)');
      earliestGradient.addColorStop(0.5, 'rgba(224, 170, 40, 0.16)');
      earliestGradient.addColorStop(1, 'rgba(224, 170, 40, 0.04)');

      salesChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
          labels: months.map(function (item) {
            return formatSalesMonthShort(item.month_date || item.month);
          }),
          datasets: [{
            label: String(salesModalState.earliestYear || ''),
            data: months.map(function (item) {
              return Number(item.earliest_quantity || 0);
            }),
            borderColor: 'rgba(224, 170, 40, 0.96)',
            backgroundColor: earliestGradient,
            borderWidth: 2.25,
            fill: true,
            tension: 0.34,
            pointRadius: 2.75,
            pointHoverRadius: 4,
            pointBackgroundColor: '#ffffff',
            pointBorderColor: 'rgba(224, 170, 40, 0.96)',
            pointBorderWidth: 2.5,
            pointHoverBackgroundColor: '#ffffff',
            pointHoverBorderColor: 'rgba(255, 216, 128, 1)'
          }, {
            label: String(salesModalState.previousYear || ''),
            data: months.map(function (item) {
              return Number(item.previous_quantity || 0);
            }),
            borderColor: '#42bfdc',
            backgroundColor: previousGradient,
            borderWidth: 2.5,
            fill: true,
            tension: 0.34,
            pointRadius: 3,
            pointHoverRadius: 4,
            pointBackgroundColor: '#ffffff',
            pointBorderColor: '#42bfdc',
            pointBorderWidth: 3,
            pointHoverBackgroundColor: '#ffffff',
            pointHoverBorderColor: '#42bfdc'
          }, {
            label: String(salesModalState.selectedYear || ''),
            data: months.map(function (item) {
              return Number(item.quantity || 0);
            }),
            borderColor: '#3eb77d',
            backgroundColor: currentGradient,
            borderWidth: 3,
            fill: true,
            tension: 0.38,
            pointRadius: 3.5,
            pointHoverRadius: 4.5,
            pointBackgroundColor: '#ffffff',
            pointBorderColor: '#3eb77d',
            pointBorderWidth: 3,
            pointHoverBackgroundColor: '#ffffff',
            pointHoverBorderColor: '#3eb77d'
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          animation: {
            duration: 380,
            easing: 'easeOutCubic'
          },
          interaction: {
            mode: 'index',
            intersect: false
          },
          plugins: {
            legend: {
              display: true,
              position: 'top',
              align: 'start',
              labels: {
                color: 'rgba(28, 63, 82, 0.78)',
                usePointStyle: true,
                pointStyle: 'circle',
                boxWidth: 10,
                boxHeight: 10,
                padding: 20,
                font: {
                  size: 13,
                  weight: '700'
                }
              }
            },
            tooltip: {
              displayColors: false,
              backgroundColor: 'rgba(255, 255, 255, 0.98)',
              titleColor: '#1b3b4d',
              bodyColor: '#35586b',
              borderColor: 'rgba(194, 214, 229, 0.9)',
              borderWidth: 1,
              padding: 12,
              callbacks: {
                title: function () {
                  return '';
                },
                labelTextColor: function (context) {
                  return context && context.dataset && context.dataset.borderColor ? context.dataset.borderColor : '#35586b';
                },
                label: function (context) {
                  var item = months[context.dataIndex] || {};
                  var datasetYear = context.datasetIndex === 0
                    ? salesModalState.earliestYear
                    : (context.datasetIndex === 1 ? salesModalState.previousYear : salesModalState.selectedYear);
                  var monthDate = context.datasetIndex === 2
                    ? (item.month_date || item.month || (String(datasetYear || '') + '-' + String(context.dataIndex + 1).padStart(2, '0') + '-01'))
                    : String(datasetYear || '') + '-' + String(context.dataIndex + 1).padStart(2, '0') + '-01';
                  var datasetValue = context.datasetIndex === 0
                    ? Number(item.earliest_value || 0)
                    : (context.datasetIndex === 1 ? Number(item.previous_value || 0) : Number(item.value || 0));

                  var revenueShortLabel = t('salesRevenueShort');
                  if (!revenueShortLabel || revenueShortLabel === 'sales value') {
                    revenueShortLabel = 'wartość sprzedaży (brutto)';
                  }

                  return [
                    formatSalesMonth(monthDate) + ': ' + String(context.parsed.y || 0) + ' ' + t('salesUnits'),
                    revenueShortLabel + ': ' + formatCurrencyAmount(datasetValue)
                  ];
                }
              }
            }
          },
          scales: {
            x: {
              grid: {
                color: 'rgba(188, 210, 225, 0.3)',
                drawTicks: false
              },
              border: {
                display: false
              },
              ticks: {
                color: 'rgba(70, 103, 123, 0.8)',
                maxRotation: 0,
                autoSkip: false,
                font: {
                  size: 10,
                  weight: '600'
                }
              }
            },
            y: {
              beginAtZero: true,
              grace: '10%',
              border: {
                display: false
              },
              grid: {
                color: 'rgba(188, 210, 225, 0.58)',
                drawTicks: false
              },
              ticks: {
                precision: 0,
                color: 'rgba(82, 113, 131, 0.78)',
                font: {
                  size: 9,
                  weight: '600'
                }
              }
            }
          }
        }
      });
    }

    function setSalesModalState(message, visible) {
      var state = document.getElementById('inventorySalesModalState');
      state.textContent = message || '';
      state.classList.toggle('is-visible', !!visible);
    }

    function setSalesModalContent(html, visible) {
      var content = document.getElementById('inventorySalesModalContent');
      content.innerHTML = html || '';
      content.classList.toggle('is-visible', !!visible);
    }

    function updateSalesModalNav() {
      var prev = document.querySelector('.inventory-sales-nav-prev');
      var next = document.querySelector('.inventory-sales-nav-next');
      if (!prev || !next) {
        return;
      }

      prev.classList.toggle('is-disabled', false);
      next.classList.toggle('is-disabled', salesModalState.offsetMonths <= 0);
    }

    function updateSalesModalHeading() {
      document.getElementById('inventorySalesModalTitle').textContent = salesModalState.productName || '';
      document.getElementById('inventorySalesModalSubtitle').textContent = salesModalState.combinationName || '';
    }

    function closeSalesModal() {
      var modal = document.getElementById('inventorySalesModal');
      var modalImage = document.getElementById('inventorySalesModalImage');
      var modalFallback = document.getElementById('inventorySalesModalImageFallback');
      document.getElementById('inventorySalesModalTitle').textContent = '';
      document.getElementById('inventorySalesModalSubtitle').textContent = '';
      destroySalesChart();
      modalImage.setAttribute('src', '');
      modalImage.classList.remove('is-hidden');
      modalFallback.classList.remove('is-visible');
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden', 'true');
      setSalesModalState('', false);
      setSalesModalContent('', false);
    }

    function openSalesModal() {
      var modal = document.getElementById('inventorySalesModal');
      var modalImage = document.getElementById('inventorySalesModalImage');
      var modalFallback = document.getElementById('inventorySalesModalImageFallback');
      updateSalesModalHeading();
      if (salesModalState.imageSrc) {
        modalImage.setAttribute('src', salesModalState.imageSrc);
        modalImage.classList.remove('is-hidden');
        modalFallback.classList.remove('is-visible');
      } else {
        modalImage.setAttribute('src', '');
        modalImage.classList.add('is-hidden');
        modalFallback.classList.add('is-visible');
      }
      modal.classList.add('is-open');
      modal.setAttribute('aria-hidden', 'false');
      updateSalesModalNav();
      setSalesModalState(t('salesStatsLoading'), true);
      setSalesModalContent('', false);
    }

    function fetchSalesStats() {
      openSalesModal();

      $.post(window.cargoStockManagerConfig.ajaxUrl + '&action=GetSalesStats', {
        id_product: salesModalState.productId,
        id_product_attribute: salesModalState.productAttributeId,
        months: salesModalState.months,
        offset_months: salesModalState.offsetMonths
      }, null, 'json').done(function (resp) {
        if (!resp || !resp.ok || !resp.stats) {
          setSalesModalState(resp && resp.error ? resp.error : t('errorSalesStats'), true);
          setSalesModalContent('', false);
          return;
        }

        renderSalesStats(salesModalState.productName, resp.stats);
        updateSalesModalNav();
      }).fail(function (xhr) {
        var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorSalesStats');
        setSalesModalState(error, true);
        setSalesModalContent('', false);
      });
    }

    function renderSalesStats(productName, stats) {
      var months = stats && stats.months ? stats.months : [];
      var comparison = stats && stats.comparison ? stats.comparison : {};
      var rangeLabel = '—';
      var yearLabel = '—';

      if (!months.length) {
        setSalesModalState(t('salesStatsEmpty'), true);
        setSalesModalContent('', false);
        return;
      }

      salesModalState.selectedYear = Number(comparison.current_year || 0);
      salesModalState.previousYear = Number(comparison.previous_year || 0);
      salesModalState.earliestYear = Number(comparison.earliest_year || 0);
      rangeLabel = 'Porównanie roczne';
      yearLabel = String(comparison.current_year || '—') + ' / ' + String(comparison.previous_year || '—') + ' / ' + String(comparison.earliest_year || '—');
      var currentSummary = buildYearSummary(salesModalState.selectedYear, months.map(function (item) {
        return Number(item.quantity || 0);
      }), months.map(function (item) {
        return Number(item.value || 0);
      }), months.map(function (item) {
        return Number(item.value_net || 0);
      }));
      var previousSummary = buildYearSummary(salesModalState.previousYear, months.map(function (item) {
        return Number(item.previous_quantity || 0);
      }), months.map(function (item) {
        return Number(item.previous_value || 0);
      }), months.map(function (item) {
        return Number(item.previous_value_net || 0);
      }));
      var earliestSummary = buildYearSummary(salesModalState.earliestYear, months.map(function (item) {
        return Number(item.earliest_quantity || 0);
      }), months.map(function (item) {
        return Number(item.earliest_value || 0);
      }), months.map(function (item) {
        return Number(item.earliest_value_net || 0);
      }));

      var html = '' +
        '<div class="inventory-sales-summary">' +
          renderYearSummaryCard(earliestSummary, 'is-earliest') +
          renderYearSummaryCard(previousSummary, 'is-previous') +
          renderYearSummaryCard(currentSummary, 'is-current') +
        '</div>' +
        '<div class="inventory-sales-chart">' +
          '<div class="inventory-sales-chart-layout">' +
            '<button type="button" class="inventory-sales-nav inventory-sales-nav-prev" aria-label="' + escapeHtml(t('previousYear')) + '" title="' + escapeHtml(t('previousYear')) + '">' +
              '<span aria-hidden="true">&#8249;</span>' +
            '</button>' +
            '<div class="inventory-sales-chart-panel">' +
              '<div class="inventory-sales-chart-meta">' +
                '<div class="inventory-sales-chart-range">' + escapeHtml(rangeLabel) + '</div>' +
                '<div class="inventory-sales-chart-year">' + escapeHtml(yearLabel) + '</div>' +
              '</div>' +
              '<div class="inventory-sales-chart-surface">' +
                '<div class="inventory-sales-chart-canvas"><canvas id="inventorySalesChartCanvas"></canvas></div>' +
                '<div class="inventory-sales-chart-footnote">' + escapeHtml(productName) + '</div>' +
              '</div>' +
            '</div>' +
            '<button type="button" class="inventory-sales-nav inventory-sales-nav-next" aria-label="' + escapeHtml(t('nextYear')) + '" title="' + escapeHtml(t('nextYear')) + '">' +
              '<span aria-hidden="true">&#8250;</span>' +
            '</button>' +
          '</div>' +
        '</div>';

      updateSalesModalHeading();
      setSalesModalState('', false);
      setSalesModalContent(html, true);
      renderSalesChart(months);
    }

    function checkForUpdates() {
      if (!window.cargoStockManagerConfig.updateConfigured) {
        updateButtonVisibility('');
        return;
      }

      setUpdateStatus(t('updateCheckingMessage'), false);

      $.post(window.cargoStockManagerConfig.ajaxUrl + '&action=CheckForUpdates', {}, null, 'json').done(function (resp) {
        var status = resp && resp.ok ? (resp.status || {}) : null;
        if (!status || !status.configured) {
          updateButtonVisibility('');
          setUpdateStatus('', false);
          return;
        }

        if (status.available && status.version) {
          updateButtonVisibility(String(status.version));
          setUpdateStatus('', false);
          return;
        }

        updateButtonVisibility('');
        setUpdateStatus('', false);
      }).fail(function (xhr) {
        var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('updateCheckErrorMessage');
        updateButtonVisibility('');
        setUpdateStatus(error, true);
      });
    }

    function installUpdate() {
      var button = document.getElementById('inventoryUpdateButton');
      if (!button || button.hidden) {
        return;
      }

      button.disabled = true;
      setUpdateStatus(t('updateInstallingMessage'), false);

      $.post(window.cargoStockManagerConfig.ajaxUrl + '&action=InstallUpdate', {}, null, 'json').done(function (resp) {
        var message = resp && resp.message ? resp.message : t('updateInstalledMessage');
        setUpdateStatus(message, false);
        updateButtonVisibility('');
        window.setTimeout(function () {
          window.location.reload();
        }, 1200);
      }).fail(function (xhr) {
        var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('updateInstallErrorMessage');
        setUpdateStatus(error, true);
        button.disabled = false;
      });
    }

    $(document).ready(function () {
      var savedQuery = localStorage.getItem(LS_QUERY) || '';
      var savedActiveOnly = localStorage.getItem(LS_ACTIVE_ONLY) === '1';
      var savedOnly = localStorage.getItem(LS_ONLY) === '1';
      var savedMissingPurchaseOnly = localStorage.getItem(LS_MISSING_PURCHASE) === '1';
      var savedShowWeight = localStorage.getItem(LS_SHOW_WEIGHT) === '1';
      var savedShowUnitVolume = localStorage.getItem(LS_SHOW_UNIT_VOLUME) === '1';
      var savedShowUnitsPerCarton = localStorage.getItem(LS_SHOW_UNITS_PER_CARTON) === '1';
      var savedShowCartonDimensions = localStorage.getItem(LS_SHOW_CARTON_DIMENSIONS) === '1';
      var savedMissingWeightOnly = localStorage.getItem(LS_MISSING_WEIGHT) === '1';
      var savedBrutto = localStorage.getItem(LS_BRUTTO) === '1';
      var savedShowMaterial = localStorage.getItem(LS_SHOW_MATERIAL) === '1';
      var savedShowHsCode = localStorage.getItem(LS_SHOW_HS_CODE) === '1';
      var savedShowCustomsDutyRate = localStorage.getItem(LS_SHOW_CUSTOMS_DUTY_RATE) === '1';
      marketplaceSettingsState.marketplaceMarkup = normalizePercentValue(localStorage.getItem(LS_MARKETPLACE_MARKUP), 20);
      marketplaceSettingsState.marketplaceCommission = normalizePercentValue(localStorage.getItem(LS_MARKETPLACE_COMMISSION), 10);

      applyLanguage();
      syncMarketplaceSettingsUi();
      renderSortState();

      setSearchKeywords(parseKeywords(savedQuery));
      $('#activeOnly').prop('checked', savedActiveOnly);
      $('#onlyAvailable').prop('checked', savedOnly);
      $('#missingPurchasePriceOnly').prop('checked', savedMissingPurchaseOnly);
      $('#showWeight').prop('checked', savedShowWeight);
      $('#showUnitVolume').prop('checked', savedShowUnitVolume);
      $('#showUnitsPerCarton').prop('checked', savedShowUnitsPerCarton);
      $('#showCartonDimensions').prop('checked', savedShowCartonDimensions);
      $('#missingWeightOnly').prop('checked', savedMissingWeightOnly);
      $('#showBrutto').prop('checked', savedBrutto);
      $('#showMaterial').prop('checked', savedShowMaterial);
      $('#showHsCode').prop('checked', savedShowHsCode);
      $('#showCustomsDutyRate').prop('checked', savedShowCustomsDutyRate);
      updateFilterBadge();
      toggleWeightColumns(savedShowWeight, false);
      toggleUnitVolumeColumns(savedShowUnitVolume, false);
      toggleUnitsPerCartonColumns(savedShowUnitsPerCarton, false);
      toggleCartonDimensionsColumns(savedShowCartonDimensions, false);
      toggleBruttoColumns(savedBrutto, false);
      toggleMaterialColumn(savedShowMaterial, false);
      toggleHsCodeColumn(savedShowHsCode, false);
      toggleCustomsDutyRateColumn(savedShowCustomsDutyRate, false);
      $('.inventory-sales-modal-close').attr('aria-label', t('close'));

      if (window.cargoStockManagerConfig.updateConfigured) {
        checkForUpdates();
      }

      $('#searchBox').on('click', function () {
        $('#searchInput').trigger('focus');
      });

      $('#searchInput').on('keydown', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          appendKeywordsFromInput();
          return;
        }

        if (e.key === 'Backspace' && !this.value) {
          var keywords = getSearchKeywords();
          if (keywords.length) {
            keywords.pop();
            persistAndLoadKeywords(keywords);
          }
        }
      });

      $('#activeOnly').on('change', function () {
        localStorage.setItem(LS_ACTIVE_ONLY, this.checked ? '1' : '0');
        updateFilterBadge();
        currentPage = 1;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), this.checked, $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      });

      $('#onlyAvailable').on('change', function () {
        localStorage.setItem(LS_ONLY, this.checked ? '1' : '0');
        updateFilterBadge();
        currentPage = 1;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), this.checked, $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      });

      $('#missingPurchasePriceOnly').on('change', function () {
        localStorage.setItem(LS_MISSING_PURCHASE, this.checked ? '1' : '0');
        updateFilterBadge();
        currentPage = 1;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), this.checked, $('#missingWeightOnly').is(':checked'));
      });

      $('#showWeight').on('change', function () {
        localStorage.setItem(LS_SHOW_WEIGHT, this.checked ? '1' : '0');
        updateFilterBadge();
        toggleWeightColumns(this.checked);
      });

      $('#showUnitVolume').on('change', function () {
        localStorage.setItem(LS_SHOW_UNIT_VOLUME, this.checked ? '1' : '0');
        updateFilterBadge();
        toggleUnitVolumeColumns(this.checked);
      });

      $('#showUnitsPerCarton').on('change', function () {
        localStorage.setItem(LS_SHOW_UNITS_PER_CARTON, this.checked ? '1' : '0');
        updateFilterBadge();
        toggleUnitsPerCartonColumns(this.checked);
      });

      $('#showCartonDimensions').on('change', function () {
        localStorage.setItem(LS_SHOW_CARTON_DIMENSIONS, this.checked ? '1' : '0');
        updateFilterBadge();
        toggleCartonDimensionsColumns(this.checked);
      });

      $('#missingWeightOnly').on('change', function () {
        localStorage.setItem(LS_MISSING_WEIGHT, this.checked ? '1' : '0');
        updateFilterBadge();
        currentPage = 1;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), this.checked);
      });

      $('#showBrutto').on('change', function () {
        localStorage.setItem(LS_BRUTTO, this.checked ? '1' : '0');
        updateFilterBadge();
        toggleBruttoColumns(this.checked);
      });

      $('#showMaterial').on('change', function () {
        localStorage.setItem(LS_SHOW_MATERIAL, this.checked ? '1' : '0');
        updateFilterBadge();
        toggleMaterialColumn(this.checked);
      });

      $('#showHsCode').on('change', function () {
        localStorage.setItem(LS_SHOW_HS_CODE, this.checked ? '1' : '0');
        updateFilterBadge();
        toggleHsCodeColumn(this.checked);
      });

      $('#showCustomsDutyRate').on('change', function () {
        localStorage.setItem(LS_SHOW_CUSTOMS_DUTY_RATE, this.checked ? '1' : '0');
        updateFilterBadge();
        toggleCustomsDutyRateColumn(this.checked);
      });

      $(document).on('click', '.inventory-sortable .inventory-sort-button', function () {
        var field = $(this).closest('.inventory-sortable').data('sort-field');
        if (!field) {
          return;
        }

        if (currentSortField === field) {
          currentSortDir = currentSortDir === 'ASC' ? 'DESC' : 'ASC';
        } else {
          currentSortField = field;
          currentSortDir = 'ASC';
        }

        localStorage.setItem(LS_SORT_FIELD, currentSortField);
        localStorage.setItem(LS_SORT_DIR, currentSortDir);
        renderSortState();
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      });

      $(document).on('keydown', '.inventory-sortable .inventory-sort-button', function (event) {
        if (event.key !== 'Enter' && event.key !== ' ') {
          return;
        }

        event.preventDefault();
        $(this).trigger('click');
      });

      $(document).on('click', '.inventory-tag-remove', function () {
        var keywords = getSearchKeywords();
        var index = Number($(this).attr('data-index'));
        keywords.splice(index, 1);
        persistAndLoadKeywords(keywords);
      });

      $('#clearSearch').on('click', function () {
        $('#searchInput').val('');
        setSearchKeywords([]);
        localStorage.setItem(LS_QUERY, '');
        updateFilterBadge();
        currentPage = 1;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable('', $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      });

      $('#btnPdf').on('click', function () {
        appendKeywordsFromInput();
        var q = getSearchQuery();
        var activeOnly = $('#activeOnly').is(':checked') ? '1' : '0';
        var only = $('#onlyAvailable').is(':checked') ? '1' : '0';
        var missingPurchasePriceOnly = $('#missingPurchasePriceOnly').is(':checked') ? '1' : '0';
        var showWeight = $('#showWeight').is(':checked') ? '1' : '0';
        var showUnitVolume = $('#showUnitVolume').is(':checked') ? '1' : '0';
        var showUnitsPerCarton = $('#showUnitsPerCarton').is(':checked') ? '1' : '0';
        var showCartonDimensions = $('#showCartonDimensions').is(':checked') ? '1' : '0';
        var missingWeightOnly = $('#missingWeightOnly').is(':checked') ? '1' : '0';
        var showBrutto = $('#showBrutto').is(':checked') ? '1' : '0';
        window.location.href = window.cargoStockManagerConfig.exportUrl + '&lang=' + encodeURIComponent(window.cargoStockManagerConfig.languageIso || 'en') + '&activeOnly=' + encodeURIComponent(activeOnly) + '&onlyAvailable=' + encodeURIComponent(only) + '&missingPurchasePriceOnly=' + encodeURIComponent(missingPurchasePriceOnly) + '&showWeight=' + encodeURIComponent(showWeight) + '&showUnitVolume=' + encodeURIComponent(showUnitVolume) + '&showUnitsPerCarton=' + encodeURIComponent(showUnitsPerCarton) + '&showCartonDimensions=' + encodeURIComponent(showCartonDimensions) + '&missingWeightOnly=' + encodeURIComponent(missingWeightOnly) + '&showBrutto=' + encodeURIComponent(showBrutto) + '&query=' + encodeURIComponent(q);
      });

      $('#inventoryUpdateButton').on('click', function () {
        installUpdate();
      });

      function closeInlineEditor($td) {
        $td.find('.price-editor, .qty-editor, .weight-editor, .volume-editor, .carton-qty-editor, .carton-dimensions-editor, .carton-weight-editor, .material-editor, .hs-code-editor, .customs-duty-rate-editor').remove();
        $td.find('.editable-price, .editable-retail-price, .editable-quantity, .editable-weight, .editable-unit-volume, .editable-units-per-carton, .editable-carton-dimensions, .editable-carton-gross-weight, .editable-material, .editable-hs-code, .editable-customs-duty-rate').show();
      }

      function closeMarketplaceSettingEditor($container) {
        $container.find('.marketplace-setting-editor').remove();
        $container.find('.editable-marketplace-setting').show();
      }

      function focusEditorInput($td, selector) {
        window.setTimeout(function () {
          var $input = $td.find(selector).first();
          if ($input.length) {
            $input.trigger('focus');
            $input.select();
          }
        }, 0);
      }

      function startInlineEditor($el, editorClass, inputHtml) {
        var $td = $el.closest('td');
        if ($td.find('.price-editor, .qty-editor, .weight-editor, .volume-editor, .carton-qty-editor, .carton-dimensions-editor, .carton-weight-editor, .material-editor, .hs-code-editor, .customs-duty-rate-editor').length) {
          return;
        }

        $el.hide().after('<div class="' + editorClass + ' inline-editor">' + inputHtml + '</div>');
      }

      function startMarketplaceSettingEditor($el) {
        var $container = $el.closest('.inventory-marketplace-setting');
        if ($container.find('.marketplace-setting-editor').length) {
          return;
        }

        $el.hide().after('<div class="marketplace-setting-editor inline-editor"><input type="text" class="form-control input-sm marketplace-setting-input inline-editor-input" placeholder="' + t('enterPercentage') + '" value="' + (($el.data('current-value') || '').toString()) + '"></div>');
        focusEditorInput($container, '.marketplace-setting-input');
      }

      function submitMarketplaceSetting($input) {
        var $container = $input.closest('.inventory-marketplace-setting');
        var $editor = $input.closest('.marketplace-setting-editor');
        var $el = $container.find('.editable-marketplace-setting');
        var settingKey = String($el.data('setting-key') || '');
        var value = normalizePercentValue($input.val(), NaN);

        if (!isFinite(value)) {
          alert(t('typePercentage'));
          focusEditorInput($container, '.marketplace-setting-input');
          return;
        }

        if (settingKey === 'marketplaceMarkup') {
          marketplaceSettingsState.marketplaceMarkup = value;
          localStorage.setItem(LS_MARKETPLACE_MARKUP, String(value));
        } else if (settingKey === 'marketplaceCommission') {
          marketplaceSettingsState.marketplaceCommission = value;
          localStorage.setItem(LS_MARKETPLACE_COMMISSION, String(value));
        }

        closeMarketplaceSettingEditor($container);
        if ($('#inventoryProfitModal').hasClass('is-open')) {
          renderProfitabilityModal();
        } else {
          syncMarketplaceSettingsUi();
          refreshCalculatedMetrics();
        }
      }

      function submitPrice($input, isRetail) {
        var $td = $input.closest('td');
        var $editor = $input.closest('.price-editor');
        var $el = $td.find(isRetail ? '.editable-retail-price' : '.editable-price');
        var priceVal = $input.val().trim();

        if ($editor.data('isSubmitting')) {
          return;
        }

        if (!priceVal) {
          alert(t('typePrice'));
          focusEditorInput($td, '.price-input');
          return;
        }

        $editor.data('isSubmitting', true);
        $input.prop('disabled', true);

        $.post(window.cargoStockManagerConfig.ajaxUrl + '&action=' + (isRetail ? 'SaveRetailPrice' : 'SavePrice'), {
          id_product: $el.data('id-product'),
          id_product_attribute: $el.data('id-attr'),
          price: priceVal
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorSave'));
            $editor.data('isSubmitting', false);
            $input.prop('disabled', false);
            focusEditorInput($td, '.price-input');
            return;
          }

          var priceNumber = Number(resp.price || 0);
          $el.text(priceNumber.toFixed(2).replace('.', ',') + ' zł').removeClass('text-danger').attr('data-current-price', priceNumber.toFixed(2));
          closeInlineEditor($td);
          loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
        }).fail(function (xhr) {
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorNetwork');
          alert(error);
          $editor.data('isSubmitting', false);
          $input.prop('disabled', false);
          focusEditorInput($td, '.price-input');
        });
      }

      function submitQuantity($input) {
        var $td = $input.closest('td');
        var $editor = $input.closest('.qty-editor');
        var $el = $td.find('.editable-quantity');
        var quantityVal = $input.val().trim();

        if ($editor.data('isSubmitting')) {
          return;
        }

        if (!/^-?\d+$/.test(quantityVal)) {
          alert(t('typeQty'));
          focusEditorInput($td, '.qty-input');
          return;
        }

        $editor.data('isSubmitting', true);
        $input.prop('disabled', true);

        $.post(window.cargoStockManagerConfig.ajaxUrl + '&action=SaveQuantity', {
          id_product: $el.data('id-product'),
          id_product_attribute: $el.data('id-attr'),
          quantity: quantityVal
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorQtySave'));
            $editor.data('isSubmitting', false);
            $input.prop('disabled', false);
            focusEditorInput($td, '.qty-input');
            return;
          }

          var quantityNumber = parseInt(resp.quantity, 10) || 0;
          $el.text(String(quantityNumber)).attr('data-current-qty', String(quantityNumber));
          closeInlineEditor($td);
          loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
        }).fail(function (xhr) {
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorQtySave');
          alert(error);
          $editor.data('isSubmitting', false);
          $input.prop('disabled', false);
          focusEditorInput($td, '.qty-input');
        });
      }

      function submitWeight($input) {
        var $td = $input.closest('td');
        var $editor = $input.closest('.weight-editor');
        var $el = $td.find('.editable-weight');
        var weightVal = $input.val().trim();

        if ($editor.data('isSubmitting')) {
          return;
        }

        if (!weightVal || isNaN(Number(weightVal)) || Number(weightVal) < 0) {
          alert(t('typeWeight'));
          focusEditorInput($td, '.weight-input');
          return;
        }

        $editor.data('isSubmitting', true);
        $input.prop('disabled', true);

        $.post(window.cargoStockManagerConfig.ajaxUrl + '&action=SaveWeight', {
          id_product: $el.data('id-product'),
          id_product_attribute: $el.data('id-attr'),
          weight: weightVal
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorWeightSave'));
            $editor.data('isSubmitting', false);
            $input.prop('disabled', false);
            focusEditorInput($td, '.weight-input');
            return;
          }

          var weightNumber = Number(resp.weight || 0);
          var weightText = weightNumber > 0 ? weightNumber.toFixed(3).replace('.', ',') + ' kg' : '—';
          $el.text(weightText).attr('data-current-weight', weightNumber.toFixed(3)).toggleClass('text-danger', weightNumber <= 0);
          closeInlineEditor($td);
          loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
        }).fail(function (xhr) {
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorWeightSave');
          alert(error);
          $editor.data('isSubmitting', false);
          $input.prop('disabled', false);
          focusEditorInput($td, '.weight-input');
        });
      }

      function formatVolumeLabel(value) {
        var number = Number(value || 0);
        return number > 0 ? number.toFixed(3).replace('.', ',') + ' m³' : '—';
      }

      function formatWeightLabel(value) {
        var number = Number(value || 0);
        return number > 0 ? number.toFixed(3).replace('.', ',') + ' kg' : '—';
      }

      function formatCartonDimensionsLabel(parts) {
        if (!parts || !isFinite(Number(parts.length)) || !isFinite(Number(parts.width)) || !isFinite(Number(parts.height))) {
          return '—';
        }

        var length = Number(parts.length || 0);
        var width = Number(parts.width || 0);
        var height = Number(parts.height || 0);
        if (length <= 0 || width <= 0 || height <= 0) {
          return '—';
        }

        function trimNumber(value) {
          return Number(value).toFixed(3).replace(/\.?0+$/, '').replace('.', ',');
        }

        return trimNumber(length) + ' x ' + trimNumber(width) + ' x ' + trimNumber(height) + ' cm';
      }

      function formatDimensionEditorValue(value) {
        var parsed = Number(String(value || '').replace(',', '.'));
        if (!isFinite(parsed) || parsed <= 0) {
          return '';
        }

        return parsed.toFixed(1);
      }

      function parseVolumeEditorDecimal(value) {
        var normalized = String(value || '').replace(',', '.').trim();
        if (normalized === '') {
          return null;
        }
        var number = Number(normalized);
        return isFinite(number) ? number : NaN;
      }

      function updateVolumeEditorMainFromDimensions($editor) {
        if (!$editor || !$editor.length) {
          return;
        }

        var parsedD = parseVolumeEditorDecimal($editor.find('.volume-d-input').val());
        var parsedS = parseVolumeEditorDecimal($editor.find('.volume-s-input').val());
        var parsedW = parseVolumeEditorDecimal($editor.find('.volume-w-input').val());
        var hasValidDimensions = isFinite(parsedD) && isFinite(parsedS) && isFinite(parsedW) && parsedD > 0 && parsedS > 0 && parsedW > 0;
        if (!hasValidDimensions) {
          return;
        }

        var calculatedVolume = (parsedD * parsedS * parsedW) / 1000000;
        $editor.find('.volume-input-main').val(calculatedVolume.toFixed(6));
      }

      function submitUnitVolume($input) {
        var $td = $input.closest('td');
        var $editor = $input.closest('.volume-editor');
        var $el = $td.find('.editable-unit-volume');
        var volumeVal = $.trim(String($editor.find('.volume-input-main').val() || ''));
        var dimDVal = $.trim(String($editor.find('.volume-d-input').val() || ''));
        var dimSVal = $.trim(String($editor.find('.volume-s-input').val() || ''));
        var dimWVal = $.trim(String($editor.find('.volume-w-input').val() || ''));
        var normalizeDecimal = function (value) {
          return String(value || '').replace(',', '.').trim();
        };
        var parseDecimal = function (value) {
          var normalized = normalizeDecimal(value);
          if (normalized === '') {
            return null;
          }
          if (isNaN(Number(normalized))) {
            return NaN;
          }

          return Number(normalized);
        };

        if ($editor.data('isSubmitting')) {
          return;
        }

        var parsedVolume = parseDecimal(volumeVal);
        if (parsedVolume === null || !isFinite(parsedVolume) || parsedVolume < 0) {
          alert(t('typeUnitVolume'));
          focusEditorInput($td, '.volume-input-main');
          return;
        }

        var parsedD = parseDecimal(dimDVal);
        var parsedS = parseDecimal(dimSVal);
        var parsedW = parseDecimal(dimWVal);
        var hasAnyDimensionValue = dimDVal !== '' || dimSVal !== '' || dimWVal !== '';

        if (!hasAnyDimensionValue) {
          parsedD = parsedS = parsedW = 0;
        } else if (
          !isFinite(parsedD) || !isFinite(parsedS) || !isFinite(parsedW)
          || parsedD <= 0 || parsedS <= 0 || parsedW <= 0
        ) {
          alert(t('typeCartonDimensions'));
          focusEditorInput($td, '.volume-d-input');
          return;
        }

        var dimensionsValue = (parsedD > 0 && parsedS > 0 && parsedW > 0)
          ? [parsedD, parsedS, parsedW].join('x')
          : '';

        $editor.data('isSubmitting', true);
        $editor.find('.volume-input-main, .volume-dimension-input').prop('disabled', true);

        $.post(window.cargoStockManagerConfig.ajaxUrl + '&action=SaveUnitVolume', {
          id_product: $el.data('id-product'),
          id_product_attribute: $el.data('id-attr'),
          volume: normalizeDecimal(volumeVal)
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorSave'));
            $editor.data('isSubmitting', false);
            $editor.find('.volume-input-main, .volume-dimension-input').prop('disabled', false);
            focusEditorInput($td, '.volume-input-main');
            return;
          }

          var volumeNumber = Number(resp.volume || 0);
          $.post(window.cargoStockManagerConfig.ajaxUrl + '&action=SaveCartonDimensions', {
            id_product: $el.data('id-product'),
            id_product_attribute: $el.data('id-attr'),
            carton_dimensions: dimensionsValue
          }, null, 'json').done(function (dimsResp) {
            if (!dimsResp || !dimsResp.ok) {
              alert(dimsResp && dimsResp.error ? dimsResp.error : t('errorSave'));
              $editor.data('isSubmitting', false);
              $editor.find('.volume-input-main, .volume-dimension-input').prop('disabled', false);
              focusEditorInput($td, '.volume-d-input');
              return;
            }

            var dimensions = dimsResp.carton_dimensions || {};
            var hasDimensions = Number(dimensions.length) > 0 && Number(dimensions.width) > 0 && Number(dimensions.height) > 0;

            $el.text(formatVolumeLabel(volumeNumber))
              .attr('data-current-volume', volumeNumber > 0 ? volumeNumber.toFixed(6) : '')
              .attr('data-current-dimension-d', hasDimensions ? Number(dimensions.length).toFixed(3) : '')
              .attr('data-current-dimension-s', hasDimensions ? Number(dimensions.width).toFixed(3) : '')
              .attr('data-current-dimension-w', hasDimensions ? Number(dimensions.height).toFixed(3) : '')
              .toggleClass('text-danger', volumeNumber <= 0);

            var $dimensionEl = $td.closest('tr').find('.editable-carton-dimensions');
            if ($dimensionEl.length) {
              $dimensionEl.text(formatCartonDimensionsLabel(dimensions))
                .attr('data-current-carton-dimensions', hasDimensions ? [dimensions.length || '', dimensions.width || '', dimensions.height || ''].join('x') : '')
                .toggleClass('text-danger', !hasDimensions);
            }

            closeInlineEditor($td);
            loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
          }).fail(function (xhr) {
            var dimsError = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorSave');
            alert(dimsError);
            $editor.data('isSubmitting', false);
            $editor.find('.volume-input-main, .volume-dimension-input').prop('disabled', false);
            focusEditorInput($td, '.volume-d-input');
          });
        }).fail(function (xhr) {
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorSave');
          alert(error);
          $editor.data('isSubmitting', false);
          $editor.find('.volume-input-main, .volume-dimension-input').prop('disabled', false);
          focusEditorInput($td, '.volume-input-main');
        });
      }

      function submitUnitsPerCarton($input) {
        var $td = $input.closest('td');
        var $editor = $input.closest('.carton-qty-editor');
        var $el = $td.find('.editable-units-per-carton');
        var unitsVal = $input.val().trim();

        if ($editor.data('isSubmitting')) {
          return;
        }

        if (!/^\d+$/.test(unitsVal)) {
          alert(t('typeUnitsPerCarton'));
          focusEditorInput($td, '.carton-qty-input');
          return;
        }

        $editor.data('isSubmitting', true);
        $input.prop('disabled', true);

        $.post(window.cargoStockManagerConfig.ajaxUrl + '&action=SaveUnitsPerCarton', {
          id_product: $el.data('id-product'),
          id_product_attribute: $el.data('id-attr'),
          units_per_carton: unitsVal
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorSave'));
            $editor.data('isSubmitting', false);
            $input.prop('disabled', false);
            focusEditorInput($td, '.carton-qty-input');
            return;
          }

          var unitsNumber = parseInt(resp.units_per_carton, 10) || 0;
          $el.text(unitsNumber > 0 ? String(unitsNumber) : t('notAvailable'))
            .attr('data-current-units-per-carton', unitsNumber > 0 ? String(unitsNumber) : '')
            .toggleClass('text-danger', unitsNumber <= 0);
          closeInlineEditor($td);
          loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
        }).fail(function (xhr) {
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorSave');
          alert(error);
          $editor.data('isSubmitting', false);
          $input.prop('disabled', false);
          focusEditorInput($td, '.carton-qty-input');
        });
      }

      function submitMaterial($input) {
        var $td = $input.closest('td');
        var $editor = $input.closest('.material-editor');
        var $el = $td.find('.editable-material');
        var val = $input.val().trim();

        if ($editor.data('isSubmitting')) { return; }

        $editor.data('isSubmitting', true);
        $input.prop('disabled', true);

        $.post(window.cargoStockManagerConfig.ajaxUrl + '&action=SaveMaterial', {
          id_product: $el.data('id-product'),
          id_product_attribute: $el.data('id-attr'),
          material: val
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorSave'));
            $editor.data('isSubmitting', false);
            $input.prop('disabled', false);
            focusEditorInput($td, '.material-input');
            return;
          }
          var saved = resp.material || '';
          $el.text(saved !== '' ? saved : '—')
            .attr('data-current-material', saved)
            .toggleClass('text-muted', saved === '');
          closeInlineEditor($td);
        }).fail(function (xhr) {
          alert(xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorSave'));
          $editor.data('isSubmitting', false);
          $input.prop('disabled', false);
          focusEditorInput($td, '.material-input');
        });
      }

      function submitHsCode($input) {
        var $td = $input.closest('td');
        var $editor = $input.closest('.hs-code-editor');
        var $el = $td.find('.editable-hs-code');
        var val = $input.val().trim();

        if ($editor.data('isSubmitting')) { return; }

        $editor.data('isSubmitting', true);
        $input.prop('disabled', true);

        $.post(window.cargoStockManagerConfig.ajaxUrl + '&action=SaveHsCode', {
          id_product: $el.data('id-product'),
          id_product_attribute: $el.data('id-attr'),
          hs_code: val
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorSave'));
            $editor.data('isSubmitting', false);
            $input.prop('disabled', false);
            focusEditorInput($td, '.hs-code-input');
            return;
          }
          var saved = resp.hs_code || '';
          $el.text(saved !== '' ? saved : '—')
            .attr('data-current-hs-code', saved)
            .toggleClass('text-muted', saved === '');
          closeInlineEditor($td);
        }).fail(function (xhr) {
          alert(xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorSave'));
          $editor.data('isSubmitting', false);
          $input.prop('disabled', false);
          focusEditorInput($td, '.hs-code-input');
        });
      }

      function submitCustomsDutyRate($input) {
        var $td = $input.closest('td');
        var $editor = $input.closest('.customs-duty-rate-editor');
        var $el = $td.find('.editable-customs-duty-rate');
        var val = $input.val().trim();

        if ($editor.data('isSubmitting')) { return; }

        $editor.data('isSubmitting', true);
        $input.prop('disabled', true);

        $.post(window.cargoStockManagerConfig.ajaxUrl + '&action=SaveCustomsDutyRate', {
          id_product: $el.data('id-product'),
          id_product_attribute: $el.data('id-attr'),
          customs_duty_rate: val
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorSave'));
            $editor.data('isSubmitting', false);
            $input.prop('disabled', false);
            focusEditorInput($td, '.customs-duty-rate-input');
            return;
          }
          var rate = parseFloat(resp.customs_duty_rate || 0);
          var label = rate > 0 ? rate.toFixed(2).replace('.', ',') + ' %' : '—';
          $el.text(label)
            .attr('data-current-customs-duty-rate', rate > 0 ? rate.toFixed(4) : '0')
            .toggleClass('text-muted', rate <= 0);
          closeInlineEditor($td);
        }).fail(function (xhr) {
          alert(xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorSave'));
          $editor.data('isSubmitting', false);
          $input.prop('disabled', false);
          focusEditorInput($td, '.customs-duty-rate-input');
        });
      }

      function submitCartonDimensions($input) {
        var $td = $input.closest('td');
        var $editor = $input.closest('.carton-dimensions-editor');
        var $el = $td.find('.editable-carton-dimensions');
        var normalizeDecimal = function (value) {
          return String(value || '').replace(',', '.').trim();
        };
        var parseDecimal = function (value) {
          var normalized = normalizeDecimal(value);
          if (normalized === '') {
            return null;
          }
          if (isNaN(Number(normalized))) {
            return NaN;
          }

          return Number(normalized);
        };
        var sRaw = $editor.find('.carton-s-input').val(); // width
        var wRaw = $editor.find('.carton-w-input').val(); // height
        var gRaw = $editor.find('.carton-g-input').val(); // depth
        var parsedS = parseDecimal(sRaw);
        var parsedW = parseDecimal(wRaw);
        var parsedG = parseDecimal(gRaw);
        var hasAnyDimensionValue = normalizeDecimal(sRaw) !== '' || normalizeDecimal(wRaw) !== '' || normalizeDecimal(gRaw) !== '';
        var dimensionsVal = '';

        if ($editor.data('isSubmitting')) {
          return;
        }

        if (!hasAnyDimensionValue) {
          dimensionsVal = '';
        } else if (
          !isFinite(parsedS) || !isFinite(parsedW) || !isFinite(parsedG)
          || parsedS <= 0 || parsedW <= 0 || parsedG <= 0
        ) {
          alert(t('typeCartonDimensions'));
          focusEditorInput($td, '.carton-s-input');
          return;
        } else {
          // API expects D x S x W (depth x width x height); editor uses PS order S x W x G.
          dimensionsVal = [parsedG, parsedS, parsedW].join('x');
        }

        $editor.data('isSubmitting', true);
        $editor.find('.carton-dimension-input').prop('disabled', true);

        $.post(window.cargoStockManagerConfig.ajaxUrl + '&action=SaveCartonDimensions', {
          id_product: $el.data('id-product'),
          id_product_attribute: $el.data('id-attr'),
          carton_dimensions: dimensionsVal
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorSave'));
            $editor.data('isSubmitting', false);
            $editor.find('.carton-dimension-input').prop('disabled', false);
            focusEditorInput($td, '.carton-s-input');
            return;
          }

          var dimensions = resp.carton_dimensions || {};
          var hasDimensions = Number(dimensions.length) > 0 && Number(dimensions.width) > 0 && Number(dimensions.height) > 0;
          $el.text(formatCartonDimensionsLabel(dimensions))
            .attr('data-current-carton-dimensions', hasDimensions ? [dimensions.length || '', dimensions.width || '', dimensions.height || ''].join('x') : '')
            .toggleClass('text-danger', !hasDimensions);
          closeInlineEditor($td);
          loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
        }).fail(function (xhr) {
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorSave');
          alert(error);
          $editor.data('isSubmitting', false);
          $editor.find('.carton-dimension-input').prop('disabled', false);
          focusEditorInput($td, '.carton-s-input');
        });
      }

      function submitCartonGrossWeight($input) {
        var $td = $input.closest('td');
        var $editor = $input.closest('.carton-weight-editor');
        var $el = $td.find('.editable-carton-gross-weight');
        var weightVal = $input.val().trim();

        if ($editor.data('isSubmitting')) {
          return;
        }

        if (!weightVal || isNaN(Number(weightVal.replace(',', '.'))) || Number(weightVal.replace(',', '.')) < 0) {
          alert(t('typeCartonGrossWeight'));
          focusEditorInput($td, '.carton-weight-input');
          return;
        }

        $editor.data('isSubmitting', true);
        $input.prop('disabled', true);

        $.post(window.cargoStockManagerConfig.ajaxUrl + '&action=SaveCartonGrossWeight', {
          id_product: $el.data('id-product'),
          id_product_attribute: $el.data('id-attr'),
          carton_gross_weight: weightVal
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorSave'));
            $editor.data('isSubmitting', false);
            $input.prop('disabled', false);
            focusEditorInput($td, '.carton-weight-input');
            return;
          }

          var weightNumber = Number(resp.carton_gross_weight || 0);
          $el.text(formatWeightLabel(weightNumber))
            .attr('data-current-carton-gross-weight', weightNumber > 0 ? weightNumber.toFixed(3) : '')
            .toggleClass('text-danger', weightNumber <= 0);
          closeInlineEditor($td);
          loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
        }).fail(function (xhr) {
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorSave');
          alert(error);
          $editor.data('isSubmitting', false);
          $input.prop('disabled', false);
          focusEditorInput($td, '.carton-weight-input');
        });
      }

      function submitInlineEditor($input) {
        if ($input.hasClass('marketplace-setting-input')) {
          submitMarketplaceSetting($input);
          return;
        }

        if ($input.hasClass('qty-input')) {
          submitQuantity($input);
          return;
        }

        if ($input.hasClass('weight-input')) {
          submitWeight($input);
          return;
        }

        if ($input.hasClass('volume-input')) {
          submitUnitVolume($input);
          return;
        }

        if ($input.hasClass('volume-input-main') || $input.hasClass('volume-dimension-input')) {
          submitUnitVolume($input);
          return;
        }

        if ($input.hasClass('carton-qty-input')) {
          submitUnitsPerCarton($input);
          return;
        }

        if ($input.hasClass('carton-dimensions-input') || $input.hasClass('carton-dimension-input')) {
          submitCartonDimensions($input);
          return;
        }

        if ($input.hasClass('carton-weight-input')) {
          submitCartonGrossWeight($input);
          return;
        }

        if ($input.hasClass('material-input')) {
          submitMaterial($input);
          return;
        }

        if ($input.hasClass('hs-code-input')) {
          submitHsCode($input);
          return;
        }

        if ($input.hasClass('customs-duty-rate-input')) {
          submitCustomsDutyRate($input);
          return;
        }

        submitPrice($input, $input.closest('td').find('.editable-retail-price:hidden').length > 0);
      }

      $(document).on('click', '.editable-price', function () {
        if (!window.cargoStockManagerConfig.canEdit) {
          return;
        }

        var $el = $(this);
        startInlineEditor($el, 'price-editor', '<input type="text" class="form-control input-sm price-input inline-editor-input" placeholder="' + t('enterPrice') + '" value="' + (($el.data('current-price') || '').toString()) + '">');
        focusEditorInput($el.closest('td'), '.price-input');
      });

      $(document).on('click', '.editable-retail-price', function () {
        if (!window.cargoStockManagerConfig.canEdit) {
          return;
        }

        var $el = $(this);
        startInlineEditor($el, 'price-editor', '<input type="text" class="form-control input-sm price-input inline-editor-input" placeholder="' + t('enterRetailPrice') + '" value="' + (($el.data('current-price') || '').toString()) + '">');
        focusEditorInput($el.closest('td'), '.price-input');
      });

      $(document).on('click', '.editable-quantity', function () {
        if (!window.cargoStockManagerConfig.canEdit) {
          return;
        }

        var $el = $(this);
        startInlineEditor($el, 'qty-editor', '<input type="number" step="1" class="form-control input-sm qty-input inline-editor-input" placeholder="' + t('enterQty') + '" value="' + (($el.data('current-qty') || '').toString()) + '">');
        focusEditorInput($el.closest('td'), '.qty-input');
      });

      $(document).on('click', '.editable-weight', function () {
        if (!window.cargoStockManagerConfig.canEdit) {
          return;
        }

        var $el = $(this);
        startInlineEditor($el, 'weight-editor', '<input type="number" step="0.001" min="0" class="form-control input-sm weight-input inline-editor-input" placeholder="' + t('enterWeight') + '" value="' + (($el.data('current-weight') || '').toString()) + '">');
        focusEditorInput($el.closest('td'), '.weight-input');
      });

      $(document).on('click', '.editable-unit-volume', function () {
        if (!window.cargoStockManagerConfig.canEdit) {
          return;
        }

        var $el = $(this);
        var currentVolume = (($el.data('current-volume') || '').toString());
        var currentD = formatDimensionEditorValue(($el.data('current-dimension-d') || '').toString());
        var currentS = formatDimensionEditorValue(($el.data('current-dimension-s') || '').toString());
        var currentW = formatDimensionEditorValue(($el.data('current-dimension-w') || '').toString());
        var editorHtml = '' +
          '<div class="volume-editor-grid">' +
            '<input type="number" step="0.000001" min="0" class="form-control input-sm volume-input-main inline-editor-input" placeholder="m³" value="' + currentVolume + '">' +
            '<span class="volume-editor-equals">=</span>' +
            '<input type="number" step="0.1" min="0" class="form-control input-sm volume-dimension-input volume-d-input inline-editor-input" placeholder="D" value="' + currentD + '">' +
            '<span class="volume-editor-separator">x</span>' +
            '<input type="number" step="0.1" min="0" class="form-control input-sm volume-dimension-input volume-s-input inline-editor-input" placeholder="S" value="' + currentS + '">' +
            '<span class="volume-editor-separator">x</span>' +
            '<input type="number" step="0.1" min="0" class="form-control input-sm volume-dimension-input volume-w-input inline-editor-input" placeholder="W" value="' + currentW + '">' +
            '<span class="volume-editor-unit">cm</span>' +
          '</div>';
        startInlineEditor($el, 'volume-editor', editorHtml);
        focusEditorInput($el.closest('td'), '.volume-input-main');
      });

      $(document).on('input', '.volume-d-input, .volume-s-input, .volume-w-input', function () {
        updateVolumeEditorMainFromDimensions($(this).closest('.volume-editor'));
      });

      $(document).on('click', '.editable-units-per-carton', function () {
        if (!window.cargoStockManagerConfig.canEdit) {
          return;
        }

        var $el = $(this);
        startInlineEditor($el, 'carton-qty-editor', '<input type="number" step="1" min="0" class="form-control input-sm carton-qty-input inline-editor-input" placeholder="' + t('enterUnitsPerCarton') + '" value="' + (($el.data('current-units-per-carton') || '').toString()) + '">');
        focusEditorInput($el.closest('td'), '.carton-qty-input');
      });

      $(document).on('click', '.editable-carton-dimensions', function () {
        if (!window.cargoStockManagerConfig.canEdit) {
          return;
        }

        var $el = $(this);
        var dimsRaw = (($el.data('current-carton-dimensions') || '').toString()).trim();
        var dimsParts = dimsRaw ? dimsRaw.split('x') : [];
        var currentS = formatDimensionEditorValue((dimsParts[1] || '').toString()); // width
        var currentW = formatDimensionEditorValue((dimsParts[2] || '').toString()); // height
        var currentG = formatDimensionEditorValue((dimsParts[0] || '').toString()); // depth
        var editorHtml = '' +
          '<div class="volume-editor-grid">' +
            '<input type="number" step="0.1" min="0" class="form-control input-sm carton-dimension-input carton-s-input inline-editor-input" placeholder="S" value="' + currentS + '">' +
            '<span class="volume-editor-separator">x</span>' +
            '<input type="number" step="0.1" min="0" class="form-control input-sm carton-dimension-input carton-w-input inline-editor-input" placeholder="W" value="' + currentW + '">' +
            '<span class="volume-editor-separator">x</span>' +
            '<input type="number" step="0.1" min="0" class="form-control input-sm carton-dimension-input carton-g-input inline-editor-input" placeholder="G" value="' + currentG + '">' +
            '<span class="volume-editor-unit">cm</span>' +
          '</div>';
        startInlineEditor($el, 'carton-dimensions-editor', editorHtml);
        focusEditorInput($el.closest('td'), '.carton-s-input');
      });

      $(document).on('click', '.editable-carton-gross-weight', function () {
        if (!window.cargoStockManagerConfig.canEdit) {
          return;
        }

        var $el = $(this);
        startInlineEditor($el, 'carton-weight-editor', '<input type="number" step="0.001" min="0" class="form-control input-sm carton-weight-input inline-editor-input" placeholder="' + t('enterCartonGrossWeight') + '" value="' + (($el.data('current-carton-gross-weight') || '').toString()) + '">');
        focusEditorInput($el.closest('td'), '.carton-weight-input');
      });

      $(document).on('click', '.editable-material', function () {
        if (!window.cargoStockManagerConfig.canEdit) { return; }
        var $el = $(this);
        startInlineEditor($el, 'material-editor', '<input type="text" class="form-control input-sm material-input inline-editor-input" placeholder="Materiał" value="' + (($el.data('current-material') || '').toString()) + '">');
        focusEditorInput($el.closest('td'), '.material-input');
      });

      $(document).on('click', '.editable-hs-code', function () {
        if (!window.cargoStockManagerConfig.canEdit) { return; }
        var $el = $(this);
        startInlineEditor($el, 'hs-code-editor', '<input type="text" class="form-control input-sm hs-code-input inline-editor-input" placeholder="np. 8517.12" value="' + (($el.data('current-hs-code') || '').toString()) + '">');
        focusEditorInput($el.closest('td'), '.hs-code-input');
      });

      $(document).on('click', '.editable-customs-duty-rate', function () {
        if (!window.cargoStockManagerConfig.canEdit) { return; }
        var $el = $(this);
        startInlineEditor($el, 'customs-duty-rate-editor', '<input type="number" step="0.01" min="0" max="100" class="form-control input-sm customs-duty-rate-input inline-editor-input" placeholder="np. 6.5" value="' + (($el.data('current-customs-duty-rate') || '').toString()) + '">');
        focusEditorInput($el.closest('td'), '.customs-duty-rate-input');
      });

      $(document).on('click', '.editable-marketplace-setting', function () {
        var $el = $(this);
        startMarketplaceSettingEditor($el);
      });

      $(document).on('keydown', '.price-input, .qty-input, .weight-input, .volume-input, .volume-input-main, .volume-dimension-input, .carton-qty-input, .carton-dimensions-input, .carton-dimension-input, .carton-weight-input, .material-input, .hs-code-input, .customs-duty-rate-input, .marketplace-setting-input', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          $(this).data('skipBlurSubmit', true);
          submitInlineEditor($(this));
          return;
        }

        if (e.key === 'Escape') {
          e.preventDefault();
          $(this).data('skipBlurSubmit', true);
          closeInlineEditor($(this).closest('td'));
          closeMarketplaceSettingEditor($(this).closest('.inventory-marketplace-setting'));
        }
      });

      $(document).on('blur', '.price-input, .qty-input, .weight-input, .volume-input, .volume-input-main, .volume-dimension-input, .carton-qty-input, .carton-dimensions-input, .carton-dimension-input, .carton-weight-input, .material-input, .hs-code-input, .customs-duty-rate-input, .marketplace-setting-input', function () {
        var $input = $(this);

        if ($input.data('skipBlurSubmit')) {
          $input.removeData('skipBlurSubmit');
          return;
        }

        window.setTimeout(function () {
          if (!$input.closest('body').length || !$input.is(':visible')) {
            return;
          }

          var $volumeEditor = $input.closest('.volume-editor');
          if ($volumeEditor.length && $volumeEditor.find(':focus').length > 0) {
            return;
          }

          var $cartonDimensionsEditor = $input.closest('.carton-dimensions-editor');
          if ($cartonDimensionsEditor.length && $cartonDimensionsEditor.find(':focus').length > 0) {
            return;
          }

          submitInlineEditor($input);
        }, 0);
      });

      $(document).on('change', '.toggle-product-active', function () {
        var radio = this;
        var $radio = $(radio);
        var switchName = $radio.attr('name');
        var $group = $('input[name="' + switchName + '"]');
        var nextValue = Number($radio.val()) === 1 ? 1 : 0;
        var previousValue = nextValue === 1 ? 0 : 1;

        if (!window.cargoStockManagerConfig.canEdit) {
          $group.filter('[value="' + String(previousValue) + '"]').prop('checked', true);
          return;
        }

        $group.prop('disabled', true);

        $.post(window.cargoStockManagerConfig.ajaxUrl + '&action=ToggleProductActive', {
          id_product: $radio.data('id-product'),
          active: nextValue
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            $group.filter('[value="' + String(previousValue) + '"]').prop('checked', true);
            alert(resp && resp.error ? resp.error : t('errorToggle'));
          } else {
            $group.filter('[value="' + String(Number(resp.active) === 1 ? 1 : 0) + '"]').prop('checked', true);
          }
        }).fail(function (xhr) {
          $group.filter('[value="' + String(previousValue) + '"]').prop('checked', true);
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorToggle');
          alert(error);
        }).always(function () {
          $group.prop('disabled', false);
        });
      });

      $(document).on('click', '.copy-ean-btn', function () {
        var button = this;
        var $button = $(button);
        var ean = String($button.data('ean') || '');
        var originalText = $button.text();

        copyTextToClipboard(ean).then(function () {
          $button.addClass('is-copied').text(t('copied'));
          window.setTimeout(function () {
            $button.removeClass('is-copied').text(originalText);
          }, 900);
        }).catch(function () {
          alert(t('copyError'));
        });
      });

      $(document).on('click', '.inventory-module-edit-trigger', function (e) {
        e.preventDefault();
        e.stopPropagation();

        var $button = $(this);
        var modal = document.getElementById('inventoryScannerModal');
        var dialog = document.querySelector('#inventoryScannerModal .inventory-scanner-modal-dialog');
        var title = document.getElementById('inventoryScannerModalTitle');
        var subtitle = document.getElementById('inventoryScannerModalSubtitle');
        var eanEl = document.getElementById('inventoryScannerModalEan');
        var img = document.getElementById('inventoryScannerModalImage');
        var fallback = document.getElementById('inventoryScannerModalImageFallback');
        var content = document.getElementById('inventoryScannerModalContent');

        if (modal) {
          modal.classList.remove('is-battery-mode');
        }
        if (dialog) {
          dialog.classList.remove('is-battery-mode');
        }
        if (content) {
          content.classList.remove('is-battery');
        }

        var imageSrc = String($button.data('image-src') || '');
        var ean = String($button.data('ean') || '');
        var productName = String($button.data('product-name') || '');
        var combinationName = String($button.data('combination-name') || '');
        var parseIntSafe = function (v) {
          var n = parseInt(v, 10);
          return isNaN(n) ? 0 : n;
        };
        var parseFloatSafe = function (v) {
          var n = parseFloat(v);
          return isNaN(n) ? 0 : n;
        };

        if (title) {
          title.textContent = productName;
        }
        if (subtitle) {
          subtitle.textContent = combinationName;
        }
        if (eanEl) {
          eanEl.style.display = 'block';
          var renderEan = window.cargoStockManagerRenderScannerEan;
          if (typeof renderEan === 'function') {
            renderEan(eanEl, ean);
          } else {
            eanEl.classList.add('is-fallback');
            eanEl.textContent = ean || '';
          }
        }
        if (img && fallback) {
          if (imageSrc) {
            img.src = imageSrc;
            img.classList.remove('is-hidden');
            fallback.style.display = 'none';
          } else {
            img.src = '';
            img.classList.add('is-hidden');
            fallback.style.display = 'block';
          }
        }

        var nextState = {
          product: {
            id_product: parseIntSafe($button.data('id-product')),
            id_product_attribute: parseIntSafe($button.data('id-attr')),
            product_name: productName,
            combination_name: combinationName,
            ean: ean,
            image_url: imageSrc,
            stock_quantity: parseIntSafe($button.data('stock-quantity')),
            product_cost: parseFloatSafe($button.data('cost')),
            product_price_brutto: parseFloatSafe($button.data('retail')),
            product_weight: parseFloatSafe($button.data('weight')),
            unit_volume: parseFloatSafe($button.data('unit-volume')),
            units_per_carton: parseIntSafe($button.data('units-per-carton')),
            carton_length: parseFloatSafe($button.data('carton-length')),
            carton_width: parseFloatSafe($button.data('carton-width')),
            carton_height: parseFloatSafe($button.data('carton-height')),
            carton_gross_weight: parseFloatSafe($button.data('carton-gross-weight')),
            module_model: String($button.data('module-model') || ''),
            material: String($button.data('material') || ''),
            hs_code: String($button.data('hs-code') || ''),
            customs_duty_rate: parseFloatSafe($button.data('customs-duty-rate')),
            logistics_description: String($button.data('logistics-description') || '')
          }
        };
        var setState = window.cargoStockManagerSetScannerState;
        if (typeof setState === 'function') {
          setState(nextState);
        } else {
          window.cargoStockManagerScannerState = nextState;
        }

        var renderState = window.cargoStockManagerRenderScannerState;
        if (typeof renderState === 'function') {
          renderState();
        }

        var openModal = window.cargoStockManagerOpenScannerModal;
        if (typeof openModal === 'function') {
          openModal();
        } else if (modal) {
          modal.classList.add('is-open');
          modal.setAttribute('aria-hidden', 'false');
        }
      });

      $(document).on('click', '.inventory-sales-trigger', function (e) {
        e.preventDefault();
        e.stopPropagation();

        var $button = $(this);
        salesModalState.productId = parseInt($button.data('id-product') || '0', 10);
        salesModalState.productAttributeId = parseInt($button.data('id-attr') || '0', 10);
        salesModalState.productName = String($button.data('product-name') || t('salesStatsTitle'));
        salesModalState.combinationName = String($button.data('combination-name') || '');
        salesModalState.imageSrc = String($button.data('image-src') || '');
        salesModalState.cost = Number($button.data('cost') || 0);
        salesModalState.costGross = Number($button.data('cost-gross') || 0);
        salesModalState.retailNet = Number($button.data('retail-net') || 0);
        salesModalState.retail = Number($button.data('retail') || 0);
        salesModalState.months = 12;
        salesModalState.offsetMonths = 0;

        fetchSalesStats();
      });

      $(document).on('click', '.inventory-profit-trigger', function (e) {
        e.preventDefault();
        e.stopPropagation();

        var $button = $(this);
        profitModalState.productName = String($button.data('product-name') || t('profitability'));
        profitModalState.combinationName = String($button.data('combination-name') || '');
        profitModalState.imageSrc = String($button.data('image-src') || '');
        profitModalState.cost = Number($button.data('cost') || 0);
        profitModalState.costGross = Number($button.data('cost-gross') || 0);
        profitModalState.retailNet = Number($button.data('retail-net') || 0);
        profitModalState.retail = Number($button.data('retail') || 0);
        openProfitModal();
      });

      $(document).on('click', '.inventory-sales-nav-prev', function () {
        salesModalState.offsetMonths += 12;
        fetchSalesStats();
      });

      $(document).on('click', '.inventory-sales-nav-next', function () {
        if (salesModalState.offsetMonths <= 0) {
          return;
        }

        salesModalState.offsetMonths = Math.max(0, salesModalState.offsetMonths - 12);
        fetchSalesStats();
      });

      $(document).on('click', '.inventory-sales-modal-close, .inventory-sales-modal-backdrop', function () {
        if ($(this).closest('#inventoryProfitModal').length) {
          closeProfitModal();
          return;
        }

        closeSalesModal();
      });

      $(document).on('keydown', function (e) {
        if (e.key === 'Escape' && $('#inventorySalesModal').hasClass('is-open')) {
          closeSalesModal();
        }

        if (e.key === 'Escape' && $('#inventoryProfitModal').hasClass('is-open')) {
          closeProfitModal();
        }
      });

      $(document).on('click', '.inventory-actions-toggle', function (e) {
        e.preventDefault();
        e.stopPropagation();

        var $menu = $(this).closest('.inventory-actions-menu');
        $('.inventory-actions-menu').not($menu).removeClass('is-open').find('.inventory-actions-toggle').attr('aria-expanded', 'false');
        $menu.toggleClass('is-open');
        $(this).attr('aria-expanded', $menu.hasClass('is-open') ? 'true' : 'false');
      });

      $(document).on('click', function () {
        $('.inventory-actions-menu').removeClass('is-open').find('.inventory-actions-toggle').attr('aria-expanded', 'false');
      });

      $(document).on('click', '.inventory-actions-dropdown', function (e) {
        e.stopPropagation();
      });

      $(document).on('click', '.inventory-hide-product', function () {
        if (!window.cargoStockManagerConfig.canEdit) {
          return;
        }

        var $btn = $(this);
        var idProduct = parseInt($btn.data('id-product') || '0', 10);
        if (!idProduct) {
          return;
        }

        $btn.prop('disabled', true);

        $.post(window.cargoStockManagerConfig.ajaxUrl + '&action=HideProduct', {
          id_product: idProduct
        }, null, 'json').done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorHide'));
            $btn.prop('disabled', false);
            return;
          }

          loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
        }).fail(function (xhr) {
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorHide');
          alert(error);
          $btn.prop('disabled', false);
        });
      });

      $(document).on('click', '.inventory-page-edge, .inventory-page-nav', function () {
        if (this.disabled) {
          return;
        }

        var page = parseInt($(this).attr('data-page') || '1', 10);
        currentPage = page > 0 ? page : 1;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      });

      $(document).on('change', '.inventory-per-page-select', function () {
        var perPage = parseInt(this.value || '20', 10);
        currentPerPage = [20, 50, 100, 200].indexOf(perPage) !== -1 ? perPage : 20;
        currentPage = 1;
        localStorage.setItem(LS_PER_PAGE, String(currentPerPage));
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      });

      function applyCurrentPageInput(input) {
        var min = parseInt(input.getAttribute('min') || '1', 10);
        var max = parseInt(input.getAttribute('max') || '1', 10);
        var page = parseInt(input.value || String(currentPage), 10);

        if (isNaN(page)) {
          page = currentPage;
        }

        page = Math.max(min, Math.min(max, page));
        input.value = String(page);

        if (page === currentPage) {
          return;
        }

        currentPage = page;
        localStorage.setItem(LS_PAGE, String(currentPage));
        loadTable(getSearchQuery(), $('#activeOnly').is(':checked'), $('#onlyAvailable').is(':checked'), $('#missingPurchasePriceOnly').is(':checked'), $('#missingWeightOnly').is(':checked'));
      }

      $(document).on('keydown', '.inventory-page-current', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          applyCurrentPageInput(this);
        }
      });

      $(document).on('change', '.inventory-page-current', function () {
        applyCurrentPageInput(this);
      });

      if (window.cargoStockManagerConfig.licenseValid) {
        loadTable(getSearchQuery(), savedActiveOnly, savedOnly, savedMissingPurchaseOnly, savedMissingWeightOnly);
      }
    });
  })();

  // ── Barcode scanner ────────────────────────────────────────────────
  (function () {
    var scannerActive = false;
    var scannerState = null;

    function setSharedScannerState(nextState) {
      scannerState = nextState;
      window.cargoStockManagerScannerState = nextState;
    }
    window.cargoStockManagerSetScannerState = setSharedScannerState;

    function getSharedScannerState() {
      if (scannerState && scannerState.product) {
        return scannerState;
      }

      var sharedState = window.cargoStockManagerScannerState;
      if (sharedState && sharedState.product) {
        scannerState = sharedState;
        return sharedState;
      }

      return scannerState;
    }
    window.cargoStockManagerGetScannerState = getSharedScannerState;
    var scannerStorageKey = 'cargostockmanager_scanner_active';

    var scanBuffer = '';
    var scanTimer = null;
    var scanLastTime = 0;

    $(document).on('click', '#btnScanner', function () {
      setScannerMode(!scannerActive);
    });

    $(document).on('click', '.inventory-scanner-badge-close', function () {
      setScannerMode(false);
    });

    function setScannerMode(active) {
      scannerActive = active;
      var btn = document.getElementById('btnScanner');
      var badge = document.getElementById('inventoryScannerBadge');
      if (btn) { btn.classList.toggle('scanner-active', active); }
      if (badge) { badge.classList.toggle('is-active', active); }
      try {
        localStorage.setItem(scannerStorageKey, active ? '1' : '0');
      } catch (ex) {}
      if (!active) {
        scanBuffer = '';
        if (scanTimer) { clearTimeout(scanTimer); scanTimer = null; }
      }
    }

    try {
      if (localStorage.getItem(scannerStorageKey) === '1') {
        setScannerMode(true);
      }
    } catch (ex) {}

    // Capture keydown globally when scanner is active
    document.addEventListener('keydown', function (e) {
      if (!scannerActive) { return; }

      var now = Date.now();
      var interval = now - scanLastTime;
      scanLastTime = now;

      if (e.key === 'Enter' || e.key === 'Tab') {
        var handled = processScanBuffer(scanBuffer);
        scanBuffer = '';
        if (scanTimer) { clearTimeout(scanTimer); scanTimer = null; }
        if (handled) {
          e.preventDefault();
          e.stopPropagation();
        }
        return;
      }

      var digit = '';
      // Prefer the actual character sent by the scanner (e.key),
      // because shifted keys like "%" must not be converted to "5".
      if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
        digit = e.key;
      } else if (/^Digit[0-9]$/.test(e.code)) {
        digit = e.code.substring(5);
      } else if (/^Numpad[0-9]$/.test(e.code)) {
        digit = e.code.substring(6);
      }

      if (digit !== '') {
        if (interval > 1200 && scanBuffer.length > 0) {
          scanBuffer = '';
        }
        scanBuffer += digit;
        if (scanTimer) { clearTimeout(scanTimer); }
        scanTimer = setTimeout(function () {
          var raw = scanBuffer;
          scanBuffer = '';
          processScanBuffer(raw);
        }, 1000);
      }
    }, true);

    function processScanBuffer(rawBuffer) {
      var rawScan = String(rawBuffer || '').trim();
      if (!rawScan) {
        return false;
      }

      var batteryPayload = parseScannerBatteryPayload(rawScan);
      if (batteryPayload) {
        showScannerBatteryStatus(batteryPayload.level);
        return true;
      }

      var ean = rawScan.replace(/\D/g, '').trim();
      if (ean.length === 12) {
        ean = '0' + ean;
      } else if (ean.length === 14 && ean.charAt(0) === '0') {
        ean = ean.substring(1);
      } else if (ean.length > 13) {
        ean = ean.slice(-13);
      }
      if (ean.length >= 6) {
        lookupProductByEan(ean);
        return true;
      }

      return false;
    }

    document.addEventListener('paste', function (e) {
      if (!scannerActive) { return; }
      var text = '';
      try {
        text = (e.clipboardData && e.clipboardData.getData('text')) || '';
      } catch (ex) {}
      var batteryPayload = parseScannerBatteryPayload(text);
      if (!batteryPayload) {
        return;
      }

      scanBuffer = '';
      if (scanTimer) { clearTimeout(scanTimer); scanTimer = null; }
      e.preventDefault();
      e.stopPropagation();
      showScannerBatteryStatus(batteryPayload.level);
    }, true);

    function openScannerModal() {
      var modal = document.getElementById('inventoryScannerModal');
      modal.classList.add('is-open');
      modal.setAttribute('aria-hidden', 'false');
    }
    window.cargoStockManagerOpenScannerModal = openScannerModal;

    function closeScannerModal() {
      var modal = document.getElementById('inventoryScannerModal');
      if (!modal) {
        return;
      }
      var dialog = modal ? modal.querySelector('.inventory-scanner-modal-dialog') : null;
      if (modal) {
        modal.classList.remove('is-battery-mode');
      }
      if (dialog) {
        dialog.classList.remove('is-battery-mode');
      }
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden', 'true');
    }

    function parseScannerBatteryPayload(raw) {
      var normalized = String(raw || '').trim();
      if (!normalized) {
        return null;
      }

      var compact = normalized.replace(/\s+/g, ' ');
      var hasBatteryPrefix = /dump\s*energy/i.test(compact);
      if (!hasBatteryPrefix) {
        return null;
      }

      // When scanner sends multiple "Dump Energy" lines at once,
      // use the last reported percentage.
      var levelText = null;
      var prefixedPattern = /dump\s*energy[^0-9]*(\d\d?\d?)\s*%?/ig;
      var prefixedMatch = null;
      while ((prefixedMatch = prefixedPattern.exec(compact)) !== null) {
        levelText = prefixedMatch[1];
      }

      if (!levelText) {
        var anyPercentPattern = /(\d\d?\d?)\s*%/g;
        var anyPercentMatch = null;
        while ((anyPercentMatch = anyPercentPattern.exec(compact)) !== null) {
          levelText = anyPercentMatch[1];
        }
      }

      if (!levelText) {
        return null;
      }

      var level = parseInt(levelText, 10);
      if (isNaN(level)) {
        return null;
      }

      if (level < 0) { level = 0; }
      if (level > 100) { level = 100; }
      return { level: level };
    }

    function scannerBatteryBars(level) {
      if (level <= 10) { return 0; }
      if (level <= 40) { return 1; }
      if (level <= 75) { return 2; }
      return 3;
    }

    function showScannerBatteryStatus(level) {
      var modal = document.getElementById('inventoryScannerModal');
      var dialog = document.querySelector('#inventoryScannerModal .inventory-scanner-modal-dialog');
      var title = document.getElementById('inventoryScannerModalTitle');
      var subtitle = document.getElementById('inventoryScannerModalSubtitle');
      var eanEl = document.getElementById('inventoryScannerModalEan');
      var img = document.getElementById('inventoryScannerModalImage');
      var fallback = document.getElementById('inventoryScannerModalImageFallback');
      var content = document.getElementById('inventoryScannerModalContent');

      var bars = scannerBatteryBars(level);

      if (modal) {
        modal.classList.add('is-battery-mode');
      }
      if (dialog) {
        dialog.classList.add('is-battery-mode');
      }

      setSharedScannerState(null);
      title.textContent = 'Stan baterii skanera';
      subtitle.textContent = '';
      if (eanEl) {
        eanEl.style.display = 'none';
        eanEl.innerHTML = '';
      }
      if (img) {
        img.src = '';
        img.classList.add('is-hidden');
      }
      if (fallback) {
        fallback.style.display = 'none';
      }

      content.classList.add('is-battery');
      content.innerHTML = '' +
        '<div class="inventory-scanner-battery-card">' +
          '<div class="inventory-scanner-battery-glyph">' +
            '<span class="inventory-scanner-battery-bar' + (bars >= 1 ? ' is-on' : '') + '"></span>' +
            '<span class="inventory-scanner-battery-bar' + (bars >= 2 ? ' is-on' : '') + '"></span>' +
            '<span class="inventory-scanner-battery-bar' + (bars >= 3 ? ' is-on' : '') + '"></span>' +
          '</div>' +
          '<div class="inventory-scanner-battery-level">' + level + '%</div>' +
          '<div class="inventory-scanner-battery-note">Poziom naładowania skanera</div>' +
        '</div>';
      openScannerModal();
    }

    $(document).on('click', '#inventoryScannerModal .inventory-scanner-modal-backdrop, #inventoryScannerModal .inventory-scanner-modal-close', function () {
      closeScannerModal();
    });

    $(document).on('keydown', function (e) {
      if (e.key !== 'Escape') {
        return;
      }

      var modal = document.getElementById('inventoryScannerModal');
      if (modal && modal.classList.contains('is-open')) {
        e.preventDefault();
        closeScannerModal();
      }
    });

    function toFloat(v) {
      var n = parseFloat(v);
      return isNaN(n) ? 0 : n;
    }

    function toInt(v) {
      var n = parseInt(v, 10);
      return isNaN(n) ? 0 : n;
    }

    function scannerDisplayValue(field) {
      var state = getSharedScannerState();
      if (!state || !state.product) {
        return '—';
      }
      var p = state.product;
      if (field === 'qty') { return toInt(p.stock_quantity) + ' szt.'; }
      if (field === 'cost') {
        var c = toFloat(p.product_cost);
        return c > 0 ? c.toFixed(2) : '—';
      }
      if (field === 'price_gross') {
        var pg = toFloat(p.product_price_brutto);
        return pg > 0 ? pg.toFixed(2) : '—';
      }
      if (field === 'weight') {
        var w = toFloat(p.product_weight);
        return w > 0 ? w.toFixed(3) + ' kg' : '—';
      }
      if (field === 'upc') {
        var u = toInt(p.units_per_carton);
        return u > 0 ? String(u) : '—';
      }
      if (field === 'volume') {
        var vol = toFloat(p.unit_volume);
        return vol > 0 ? vol.toFixed(3) + ' m³' : '—';
      }
      if (field === 'carton_dimensions') {
        var length = toFloat(p.carton_length);
        var width = toFloat(p.carton_width);
        var height = toFloat(p.carton_height);
        if (length <= 0 || width <= 0 || height <= 0) {
          return '—';
        }
        return length.toFixed(1) + ' x ' + width.toFixed(1) + ' x ' + height.toFixed(1);
      }
      if (field === 'carton_gross_weight') {
        var gw = toFloat(p.carton_gross_weight);
        return gw > 0 ? gw.toFixed(3) + ' kg' : '—';
      }
      if (field === 'material') {
        return String((p.material || '')).trim() || '—';
      }
      if (field === 'hs_code') {
        return String((p.hs_code || '')).trim() || '—';
      }
      if (field === 'customs_duty_rate') {
        var duty = toFloat(p.customs_duty_rate);
        return duty > 0 ? duty.toFixed(2) + '%' : '—';
      }
      if (field === 'module_model') {
        var mm = String((p.module_model || '')).trim();
        if (mm !== '') { return mm; }
        var fallbackModel = String((p.model || '')).trim();
        return fallbackModel !== '' ? fallbackModel : '—';
      }
      if (field === 'description') {
        var desc = String((p.logistics_description || p.description || '')).trim();
        return desc !== '' ? desc : '—';
      }
      return '—';
    }

    function scannerRawValue(field) {
      var state = getSharedScannerState();
      if (!state || !state.product) {
        return '';
      }
      var p = state.product;
      if (field === 'qty') { return String(toInt(p.stock_quantity)); }
      if (field === 'cost') { return String(toFloat(p.product_cost)); }
      if (field === 'price_gross') { return String(toFloat(p.product_price_brutto)); }
      if (field === 'weight') { return String(toFloat(p.product_weight)); }
      if (field === 'upc') { return String(toInt(p.units_per_carton)); }
      if (field === 'volume') { return String(toFloat(p.unit_volume)); }
      if (field === 'carton_dimensions') {
        var length = toFloat(p.carton_length);
        var width = toFloat(p.carton_width);
        var height = toFloat(p.carton_height);
        if (length <= 0 || width <= 0 || height <= 0) {
          return '';
        }
        return length + 'x' + width + 'x' + height;
      }
      if (field === 'carton_gross_weight') { return String(toFloat(p.carton_gross_weight)); }
      if (field === 'material') { return String(p.material || ''); }
      if (field === 'hs_code') { return String(p.hs_code || ''); }
      if (field === 'customs_duty_rate') { return String(toFloat(p.customs_duty_rate)); }
      if (field === 'module_model') { return String(p.module_model || p.model || ''); }
      if (field === 'description') { return String(p.logistics_description || p.description || ''); }
      return '';
    }

    function scannerEditableRow(label, field, isZero, options) {
      options = options || {};
      var display = scannerDisplayValue(field);
      var allowEmptyEdit = !!options.allowEmptyEdit;
      var valueHtml = (display === '—' && !allowEmptyEdit)
        ? '—'
        : '<button type="button" class="inventory-scanner-edit-value" data-field="' + field + '" data-raw="' + $('<span>').text(scannerRawValue(field)).html() + '">' + $('<span>').text(display).html() + '</button>';
      var rowClass = (field === 'qty' ? ' is-qty' : '');
      if (options.full) {
        rowClass += ' full';
      }
      if (options.rowClass) {
        rowClass += ' ' + options.rowClass;
      }
      var valueClass = options.valueClass ? (' ' + options.valueClass) : '';

      return '<div class="inventory-scanner-modal-row' + rowClass + '">' +
        '<div class="inventory-scanner-modal-label">' + label + '</div>' +
        '<div class="inventory-scanner-modal-value' + valueClass + (isZero ? ' is-zero' : '') + '">' + valueHtml + '</div>' +
        '</div>';
    }

    function scannerEditableLine(label, field, isZero, options) {
      options = options || {};
      var display = scannerDisplayValue(field);
      var raw = scannerRawValue(field);
      var valueClass = isZero ? ' is-zero' : '';
      var lineClass = options.lineClass ? (' ' + options.lineClass) : '';
      var buttonHtml = '<button type="button" class="inventory-scanner-edit-value" data-field="' + field + '" data-raw="' + $('<span>').text(raw).html() + '">' + $('<span>').text(display).html() + '</button>';

      return '<div class="inventory-profit-line inventory-scanner-line' + lineClass + '">' +
        '<span>' + label + '</span>' +
        '<strong class="' + valueClass.trim() + '">' + buttonHtml + '</strong>' +
        '</div>';
    }

    function scannerCard(title, toneClass, headerValue, linesHtml, options) {
      options = options || {};
      var extraClass = options.full ? ' full' : '';
      var headerHtml = headerValue
        ? '<div class="inventory-profit-card-header">' + $('<span>').text(headerValue).html() + '</div>'
        : '';

      return '<div class="inventory-profit-card ' + toneClass + extraClass + '">' +
        '<div class="inventory-profit-card-label">' + $('<span>').text(title).html() + '</div>' +
        headerHtml +
        '<div class="inventory-profit-lines">' + linesHtml + '</div>' +
        '</div>';
    }

    function scannerStaticRow(label, value, isZero, options) {
      options = options || {};
      var rowClass = options.full ? ' full' : '';
      if (options.rowClass) {
        rowClass += ' ' + options.rowClass;
      }
      var valueClass = options.valueClass ? (' ' + options.valueClass) : '';
      return '<div class="inventory-scanner-modal-row' + rowClass + '">' +
        '<div class="inventory-scanner-modal-label">' + label + '</div>' +
        '<div class="inventory-scanner-modal-value' + valueClass + (isZero ? ' is-zero' : '') + '">' + value + '</div>' +
        '</div>';
    }

    function renderScannerState() {
      var content = document.getElementById('inventoryScannerModalContent');
      var state = getSharedScannerState();
      if (!state || !state.product || !content) {
        return;
      }

      var p = state.product;
      var qty = toInt(p.stock_quantity);
      var cost = toFloat(p.product_cost);
      var priceGross = toFloat(p.product_price_brutto);
      var dutyRate = toFloat(p.customs_duty_rate);
      var productHeaderValue = qty > 0 ? qty + ' szt.' : '—';
      var logisticsHeaderValue = scannerDisplayValue('carton_dimensions');
      var additionalHeaderValue = scannerDisplayValue('module_model');

      var productLines = '';
      productLines += scannerEditableLine('Stan magazynowy', 'qty', qty <= 0);
      productLines += scannerEditableLine('Cena zakupu netto', 'cost', cost <= 0);
      productLines += scannerEditableLine('Cena sprzedaży brutto', 'price_gross', priceGross <= 0);
      productLines += scannerEditableLine('Waga', 'weight', toFloat(p.product_weight) <= 0);

      var logisticsLines = '';
      logisticsLines += scannerEditableLine('Ilość w kartonie', 'upc', toInt(p.units_per_carton) <= 0);
      logisticsLines += scannerEditableLine('Objętość jedn.', 'volume', toFloat(p.unit_volume) <= 0);
      logisticsLines += scannerEditableLine('Wymiary', 'carton_dimensions', false);
      logisticsLines += scannerEditableLine('Waga kartonu', 'carton_gross_weight', toFloat(p.carton_gross_weight) <= 0);

      var additionalLines = '';
      additionalLines += scannerEditableLine('Model modułowy', 'module_model', false);
      additionalLines += scannerEditableLine('Materiał', 'material', false);
      additionalLines += scannerEditableLine('HS Code', 'hs_code', false);
      additionalLines += scannerEditableLine('Cło', 'customs_duty_rate', dutyRate <= 0);
      additionalLines += scannerEditableLine('Opis modułowy', 'description', false, { lineClass: 'is-description' });

      var html = '<div class="inventory-profit-grid">' +
        scannerCard('Produkt', 'is-store', productHeaderValue, productLines) +
        scannerCard('Logistyka', 'is-logistics', logisticsHeaderValue, logisticsLines) +
        scannerCard('Dane dodatkowe', 'is-additional', additionalHeaderValue, additionalLines, { full: true }) +
        '</div>';

      content.innerHTML = html;
    }
    window.cargoStockManagerRenderScannerState = renderScannerState;

    function submitScannerField(field, rawValue, $button) {
      var state = getSharedScannerState();
      if (!state || !state.product) {
        return;
      }

      var p = state.product;
      var idProduct = toInt(p.id_product);
      var idAttr = toInt(p.id_product_attribute);
      if (idProduct <= 0) {
        return;
      }

      var action = '';
      var payload = {
        id_product: idProduct,
        id_product_attribute: idAttr
      };

      if (field === 'qty') {
        action = 'SaveQuantity';
        payload.quantity = rawValue;
      } else if (field === 'cost') {
        action = 'SavePrice';
        payload.price = rawValue;
      } else if (field === 'price_gross') {
        action = 'SaveRetailPrice';
        payload.price = rawValue;
      } else if (field === 'weight') {
        action = 'SaveWeight';
        payload.weight = rawValue;
      } else if (field === 'upc') {
        action = 'SaveUnitsPerCarton';
        payload.units_per_carton = rawValue;
      } else if (field === 'volume') {
        action = 'SaveUnitVolume';
        payload.volume = rawValue;
      } else if (field === 'carton_dimensions') {
        action = 'SaveCartonDimensions';
        payload.carton_dimensions = rawValue;
      } else if (field === 'carton_gross_weight') {
        action = 'SaveCartonGrossWeight';
        payload.carton_gross_weight = rawValue;
      } else if (field === 'material') {
        action = 'SaveMaterial';
        payload.material = rawValue;
      } else if (field === 'hs_code') {
        action = 'SaveHsCode';
        payload.hs_code = rawValue;
      } else if (field === 'customs_duty_rate') {
        action = 'SaveCustomsDutyRate';
        payload.customs_duty_rate = rawValue;
      } else if (field === 'module_model') {
        action = 'SaveModuleModel';
        payload.module_model = rawValue;
      } else if (field === 'description') {
        action = 'SaveLogisticsDescription';
        payload.description = rawValue;
      } else {
        return;
      }

      $button.prop('disabled', true);

      $.post(window.cargoStockManagerConfig.ajaxUrl + '&action=' + action, payload, null, 'json')
        .done(function (resp) {
          if (!resp || !resp.ok) {
            alert(resp && resp.error ? resp.error : t('errorSave'));
            return;
          }

          if (field === 'qty') {
            p.stock_quantity = toInt(resp.quantity);
          } else if (field === 'cost') {
            p.product_cost = toFloat(resp.price);
          } else if (field === 'price_gross') {
            p.product_price_brutto = toFloat(resp.price);
          } else if (field === 'weight') {
            p.product_weight = toFloat(resp.weight);
          } else if (field === 'upc') {
            p.units_per_carton = toInt(resp.units_per_carton);
          } else if (field === 'volume') {
            p.unit_volume = toFloat(resp.volume);
          } else if (field === 'carton_dimensions') {
            var dimensions = resp.carton_dimensions || {};
            p.carton_length = toFloat(dimensions.length);
            p.carton_width = toFloat(dimensions.width);
            p.carton_height = toFloat(dimensions.height);
          } else if (field === 'carton_gross_weight') {
            p.carton_gross_weight = toFloat(resp.carton_gross_weight);
          } else if (field === 'material') {
            p.material = String(resp.material || '');
          } else if (field === 'hs_code') {
            p.hs_code = String(resp.hs_code || '');
          } else if (field === 'customs_duty_rate') {
            p.customs_duty_rate = toFloat(resp.customs_duty_rate);
          } else if (field === 'module_model') {
            p.module_model = String(resp.module_model || '');
          } else if (field === 'description') {
            p.logistics_description = String(resp.description || '');
          }

          renderScannerState();
        })
        .fail(function (xhr) {
          var error = xhr.responseJSON && xhr.responseJSON.error ? xhr.responseJSON.error : t('errorSave');
          alert(error);
          renderScannerState();
        });
    }

    $(document).on('click', '#inventoryScannerModal .inventory-scanner-edit-value', function (e) {
      e.preventDefault();
      if (!window.cargoStockManagerConfig.canEdit) {
        return;
      }

      var $button = $(this);
      if ($button.data('editing')) {
        return;
      }
      $button.data('editing', true);

      var field = String($button.data('field') || '');
      var raw = String($button.data('raw') || '');
      var $input = $('<input type="text" class="inventory-scanner-edit-input">').val(raw);
      $button.empty().append($input);
      $input.trigger('focus').trigger('select');

      var done = false;
      function finish(submit) {
        if (done) { return; }
        done = true;
        $button.removeData('editing');

        if (!submit) {
          renderScannerState();
          return;
        }

        var newValue = String($input.val() || '').trim();
        if (newValue === '') {
          renderScannerState();
          return;
        }

        submitScannerField(field, newValue, $button);
      }

      $input.on('keydown', function (evt) {
        if (evt.key === 'Enter') {
          evt.preventDefault();
          finish(true);
          return;
        }
        if (evt.key === 'Escape') {
          evt.preventDefault();
          finish(false);
        }
      });

      $input.on('blur', function () {
        finish(true);
      });
    });

    function lookupProductByEan(ean) {
      var modal = document.getElementById('inventoryScannerModal');
      var dialog = document.querySelector('#inventoryScannerModal .inventory-scanner-modal-dialog');
      var title = document.getElementById('inventoryScannerModalTitle');
      var subtitle = document.getElementById('inventoryScannerModalSubtitle');
      var eanEl = document.getElementById('inventoryScannerModalEan');
      var img = document.getElementById('inventoryScannerModalImage');
      var fallback = document.getElementById('inventoryScannerModalImageFallback');
      var content = document.getElementById('inventoryScannerModalContent');

      if (modal) {
        modal.classList.remove('is-battery-mode');
      }
      if (dialog) {
        dialog.classList.remove('is-battery-mode');
      }
      title.textContent = 'Wyszukiwanie\u2026';
      subtitle.textContent = '';
      eanEl.style.display = 'block';
      renderScannerEan(eanEl, ean);
      img.src = '';
      img.classList.add('is-hidden');
      fallback.style.display = 'block';
      content.classList.remove('is-battery');
      content.innerHTML = '<div class="inventory-scanner-modal-not-found"><span class="material-icons">hourglass_top</span></div>';
      openScannerModal();

      $.post(window.cargoStockManagerConfig.ajaxUrl + '&action=FindProductByEan', {
        ajax: 1,
        ean: ean,
        lang: window.cargoStockManagerConfig.languageIso || 'en'
      }, function (data) {
        if (!data || !data.ok) {
          var isError = data && data.error;
          title.textContent = isError ? 'Błąd PHP' : 'Nie znaleziono';
          subtitle.textContent = '';
          renderScannerEan(eanEl, ean);
          var msg = isError
            ? $('<span>').text(data.error).html()
            : 'Brak produktu z kodem EAN:<br><strong>' + $('<span>').text(ean).html() + '</strong>';
          content.innerHTML = '<div class="inventory-scanner-modal-not-found">' +
            '<span class="material-icons">' + (isError ? 'error_outline' : 'search_off') + '</span>' +
            '<div>' + msg + '</div></div>';
          return;
        }

        var p = data.product;
        title.textContent = p.product_name || '';
        subtitle.textContent = p.combination_name || '';
        renderScannerEan(eanEl, p.ean || ean);

        if (p.image_url) {
          img.src = p.image_url;
          img.classList.remove('is-hidden');
          fallback.style.display = 'none';
        }

        setSharedScannerState({ product: p });
        renderScannerState();
      }, 'json').fail(function (xhr) {
        title.textContent = 'Błąd';
        subtitle.textContent = '';
        var msg = 'Nie udało się wyszukać produktu.';
        try { var d = JSON.parse(xhr.responseText); if (d && d.error) { msg = d.error; } } catch (ex) {}
        content.innerHTML = '<div class="inventory-scanner-modal-not-found">' +
          '<span class="material-icons">error_outline</span>' +
          '<div>' + $('<span>').text(msg).html() + '</div>' +
          '</div>';
      });
    }

    function renderScannerEan(eanEl, value) {
      if (!eanEl) {
        return;
      }

      var raw = String(value || '').trim();
      var digitsOnly = raw.replace(/\D+/g, '');

      eanEl.classList.remove('is-fallback');
      eanEl.innerHTML = '';

      if (!raw) {
        return;
      }

      var canRenderBarcode = digitsOnly.length === 13 && typeof window.JsBarcode === 'function';
      if (canRenderBarcode) {
        var wrapper = document.createElement('div');
        wrapper.className = 'inventory-scanner-modal-ean-wrap';

        var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('class', 'inventory-scanner-modal-ean-barcode');
        wrapper.appendChild(svg);

        var text = document.createElement('div');
        text.className = 'inventory-scanner-modal-ean-text';
        text.textContent = digitsOnly;
        wrapper.appendChild(text);

        eanEl.appendChild(wrapper);

        try {
          var availableWidth = Math.max(120, wrapper.clientWidth - 12);
          var moduleWidth = Math.max(0.9, Math.min(1.8, availableWidth / 95));
          window.JsBarcode(svg, digitsOnly, {
            format: 'EAN13',
            displayValue: false,
            margin: 0,
            width: moduleWidth,
            height: 36,
            lineColor: '#223645',
            background: '#ffffff'
          });
          return;
        } catch (err) {
          eanEl.innerHTML = '';
        }
      }

      eanEl.classList.add('is-fallback');
      eanEl.textContent = raw;
    }
    window.cargoStockManagerRenderScannerEan = renderScannerEan;
  })();

  (function () {
    document.addEventListener('mouseenter', function (e) {
      if (!e.target || typeof e.target.closest !== 'function') { return; }
      var trigger = e.target.closest('.product-preview');
      if (!trigger) { return; }
      var card = trigger.querySelector('.product-preview-card');
      if (!card) { return; }
      var rect = trigger.getBoundingClientRect();
      var cardLeft = rect.right + 12;
      var cardTop = rect.top + rect.height / 2;
      if (cardLeft + 280 > window.innerWidth) {
        cardLeft = rect.left - 280 - 12;
      }
      card.style.left = cardLeft + 'px';
      card.style.top = cardTop + 'px';
      card.style.transform = 'translateY(-50%)';
    }, true);
  })();
</script>
