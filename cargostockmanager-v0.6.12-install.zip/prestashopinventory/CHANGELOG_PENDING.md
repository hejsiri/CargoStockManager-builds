Naprawa kompatybilności z nowszym schematem `ps_access` w PrestaShop podczas synchronizacji uprawnień tabów BO.
