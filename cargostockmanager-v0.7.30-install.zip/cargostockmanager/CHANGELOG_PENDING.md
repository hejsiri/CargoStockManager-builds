# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
- Zamiana $(document).ready(...) na $(...) w JS modułu, żeby usunąć warning JQMIGRATE o deprecated ready event.
