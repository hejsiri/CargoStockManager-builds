Utwardzona instalacja i aktualizacja tabów BO: moduł sprawdza teraz taby także bezpośrednio w bazie, co zapobiega duplikatom i błędom SQL przy częściowo zaktualizowanym stanie menu.
Zachowane podmenu `Produkty`, `Dostawcy`, `Zamówienia`, `Ustawienia`.
