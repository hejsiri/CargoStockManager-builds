# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Usunięcie zduplikowanego przewoźnika UPS z danych demo.
