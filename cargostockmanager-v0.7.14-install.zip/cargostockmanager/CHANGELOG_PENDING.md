# Wpisz tu zmiany do następnego release (jedna linia = jeden bullet)
# Przykład:
# Poprawa walidacji wymiarów w modalu produktu.
# Usunięcie znaku % z nagłówka kolumny Cło.
Ujednolicenie wysokości wierszy na listach dostawców, zamówień i tabelach ustawień.
