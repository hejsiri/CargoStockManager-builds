<?php

require_once __DIR__ . '/AdminCargoStockManagerController.php';

class AdminCargoStockManagerProductsController extends AdminCargoStockManagerController
{
    public function initContent(): void
    {
        if (!Tools::getIsset('ajax') && !Tools::getIsset('exportPdf')) {
            Tools::redirectAdmin($this->context->link->getAdminLink('AdminCargoStockManager', true));
        }

        parent::initContent();
    }
}
