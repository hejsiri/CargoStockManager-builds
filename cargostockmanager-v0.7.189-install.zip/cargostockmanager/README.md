# CargoStock Manager

CargoStock Manager to moduł Back Office dla PrestaShop, który łączy widok magazynowy produktów, obsługę dostawców, zamówienia towaru oraz narzędzia do kontroli kosztów zakupu i rentowności.

## Wymagania

- PrestaShop 8.2 lub nowszy
- PHP zgodny z wymaganiami używanej wersji PrestaShop
- Dostęp administratora do Back Office
- Rozszerzenie ZIP po stronie PHP dla kopii zapasowych i importu backupów

## Główne funkcje

- Widok produktów z ceną zakupu netto, stanem magazynowym, wartością zakupu i akcjami produktowymi.
- Edycja danych modułowych produktu, w tym parametrów logistycznych, celnych i opisowych.
- Historia cen zakupu produktu na podstawie zamówień towaru.
- Wykres sprzedaży z porównaniem rocznym, wartościami netto/brutto i szacowanym zyskiem.
- Modal rentowności dla sklepu i marketplace, z narzutem, marżą i zyskiem netto.
- Lista dostawców z edycją.
- Zamówienia towaru z produktami, statusami, plikami, tłumaczeniami faktur i eksportami PDF.
- Konfigurowalne statusy zamówień, przewoźnicy i rodzaje dokumentów.
- Liczniki zamówień w menu Back Office dla statusów włączonych w ustawieniach.
- Kopie zapasowe danych modułu: tworzenie, pobieranie, przywracanie, usuwanie i import ZIP.
- Aktualizator modułu z kanałami Public i Beta.

## Zakładki

Po instalacji moduł dodaje menu `CargoStock Manager` z zakładkami:

- `Produkty` - tabela produktów, filtry, skaner, eksport PDF, historia ceny, wykres sprzedaży i rentowność.
- `Dostawcy` - lista dostawców oraz formularze dodawania i edycji.
- `Zamówienia` - zamówienia towaru, statusy, pozycje, pliki i dokumenty PDF.
- `Ustawienia` - konfiguracja modułu, backupy, aktualizacje, przewoźnicy, rodzaje dokumentów i statusy zamówień.

## Instalacja

1. Pobierz paczkę instalacyjną `cargostockmanager-vX.Y.Z-install.zip`.
2. W Back Office przejdź do `Moduły > Menedżer modułów`.
3. Wgraj paczkę ZIP i zainstaluj moduł.
4. Otwórz `CargoStock Manager > Ustawienia` i sprawdź konfigurację statusów, przewoźników oraz kanału aktualizacji.

## Aktualizacje

Kanał aktualizacji wybiera się w `CargoStock Manager > Ustawienia > Aktualizacje modułu`.

- `Public` - rzadsze, stabilniejsze wydania.
- `Beta` - częstsze buildy z poprawkami pośrednimi.

Po aktualizacji moduł odświeża runtime i czyści cache PrestaShop/Smarty, aby zmiany w szablonach były widoczne od razu po instalacji nowej wersji.

## Kopie zapasowe

Sekcja `Ustawienia > Kopie zapasowe danych modułu` pozwala:

- utworzyć kopię danych modułu,
- pobrać kopię ZIP,
- przywrócić wybraną kopię,
- usunąć kopię,
- wgrać i przywrócić kopię z pliku ZIP.

Backup obejmuje tabele modułu, ustawienia oraz pliki zamówień zakupowych.

## Budowanie paczki developerskiej

Repozytorium zawiera skrypt budowania paczki release:

```bash
RELEASE_CHANNEL=beta bash scripts/release_build.sh
```

Skrypt tworzy ZIP instalacyjny oraz manifest aktualizacji dla wybranego kanału.

## Struktura techniczna

- `cargostockmanager.php` - główny plik modułu.
- `src/Controller/Admin/` - nowoczesne kontrolery Back Office.
- `classes/` - serwisy modułu, backupy, licencja, aktualizator i tłumaczenia.
- `views/templates/admin-modern/` - widoki Twig dla nowoczesnych zakładek.
- `views/templates/admin/` - starsze szablony administracyjne i widok produktów.
- `views/js/` - biblioteki JS używane w Back Office.
- `upgrade/` - skrypty migracyjne uruchamiane przy aktualizacji modułu.

## Licencja

Moduł jest rozwijany jako prywatny moduł CargoStock Manager.
